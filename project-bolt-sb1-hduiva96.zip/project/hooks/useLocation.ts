import { useState, useCallback } from 'react';
import { Platform } from 'react-native';
import { supabase } from '@/lib/supabase';

export interface Coords {
  latitude: number;
  longitude: number;
}

export interface LocationState {
  coords: Coords | null;
  loading: boolean;
  error: string | null;
}

export function useLocation() {
  const [state, setState] = useState<LocationState>({ coords: null, loading: false, error: null });

  const requestLocation = useCallback((): Promise<Coords | null> => {
    return new Promise((resolve) => {
      if (Platform.OS !== 'web' || !navigator?.geolocation) {
        setState(s => ({ ...s, error: 'Geolocation not supported' }));
        resolve(null);
        return;
      }

      setState({ coords: null, loading: true, error: null });

      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const coords: Coords = {
            latitude: pos.coords.latitude,
            longitude: pos.coords.longitude,
          };
          setState({ coords, loading: false, error: null });
          resolve(coords);
        },
        (err) => {
          const msg = err.code === 1 ? 'Location permission denied' : 'Could not get location';
          setState({ coords: null, loading: false, error: msg });
          resolve(null);
        },
        { timeout: 10000, maximumAge: 60000 }
      );
    });
  }, []);

  const saveLocationToProfile = useCallback(async (userId: string, coords: Coords) => {
    await supabase.from('profiles').update({
      latitude: coords.latitude,
      longitude: coords.longitude,
      location_updated_at: new Date().toISOString(),
    }).eq('id', userId);
  }, []);

  // Haversine distance in miles between two coords
  const distanceMiles = useCallback((a: Coords, b: Coords): number => {
    const R = 3958.8;
    const dLat = ((b.latitude - a.latitude) * Math.PI) / 180;
    const dLng = ((b.longitude - a.longitude) * Math.PI) / 180;
    const sinDLat = Math.sin(dLat / 2);
    const sinDLng = Math.sin(dLng / 2);
    const aa =
      sinDLat * sinDLat +
      Math.cos((a.latitude * Math.PI) / 180) *
        Math.cos((b.latitude * Math.PI) / 180) *
        sinDLng *
        sinDLng;
    return R * 2 * Math.atan2(Math.sqrt(aa), Math.sqrt(1 - aa));
  }, []);

  return { ...state, requestLocation, saveLocationToProfile, distanceMiles };
}
