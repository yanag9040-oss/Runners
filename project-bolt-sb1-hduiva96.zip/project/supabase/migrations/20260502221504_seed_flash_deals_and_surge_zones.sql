/*
  # Seed Flash Deals and Surge Zones

  Populates initial flash deals with countdown timers and surge zone data
  for the RunIt app home screen and runner dashboard.

  1. Flash Deals - 6 active deals with various discounts and expiry times
  2. Surge Zones - 5 zones with different multipliers for the map view
*/

-- Insert flash deals (expires_at set relative to now + hours)
INSERT INTO flash_deals (service_type, title, description, discount_type, discount_value, original_price, deal_price, max_redemptions, expires_at, active)
VALUES
  ('groceries', '30% Off Grocery Runs', 'Fresh groceries delivered fast. Limited time only!', 'percentage', 30, 25.00, 17.50, 50, now() + interval '3 hours', true),
  ('dog_walking', 'Free Dog Walk', 'First dog walk on us. Meet your new favorite runner!', 'fixed', 20, 20.00, 0.00, 20, now() + interval '1 hour 45 minutes', true),
  ('prescriptions', '$5 Off Prescriptions', 'Get your meds delivered, no stress.', 'fixed', 5, 15.00, 10.00, 100, now() + interval '5 hours', true),
  ('laundry', '25% Off Laundry', 'Pickup, wash, fold & deliver. Done right.', 'percentage', 25, 35.00, 26.25, 30, now() + interval '2 hours 20 minutes', true),
  ('flash_errand', 'Flash Errand $8 Flat', 'Any quick errand in your neighborhood.', 'fixed', 7, 15.00, 8.00, 75, now() + interval '4 hours', true),
  ('catering', '20% Off Catering Orders', 'Office lunch or home party sorted.', 'percentage', 20, 80.00, 64.00, 15, now() + interval '6 hours', true)
ON CONFLICT DO NOTHING;

-- Insert surge zones
INSERT INTO surge_zones (area_name, neighborhood, center_lat, center_lng, radius_miles, multiplier, active_requests, available_runners, active, color_hex)
VALUES
  ('Downtown Core', 'Financial District', 40.7128, -74.0060, 1.5, 2.50, 47, 8, true, '#FF4444'),
  ('Midtown Hub', 'Midtown West', 40.7549, -73.9840, 2.0, 1.80, 31, 14, true, '#FF8C00'),
  ('Airport Zone', 'JFK/LaGuardia Area', 40.6413, -73.7781, 3.0, 1.40, 18, 22, true, '#FFD700'),
  ('University District', 'Upper West Side', 40.8075, -73.9626, 1.8, 1.60, 24, 11, true, '#FF6B35'),
  ('Tech Campus', 'Silicon Alley', 40.7282, -74.0776, 1.2, 2.10, 39, 6, true, '#FF4444')
ON CONFLICT DO NOTHING;
