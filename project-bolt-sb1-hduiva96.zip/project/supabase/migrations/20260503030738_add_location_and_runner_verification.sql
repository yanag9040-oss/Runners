/*
  # Add Location Columns + Runner Verification System

  1. Changes to `errands` table
    - `customer_lat` (numeric) - customer's latitude when posting
    - `customer_lng` (numeric) - customer's longitude when posting
    - `pickup_lat` / `pickup_lng` - pickup location coordinates
    - `delivery_lat` / `delivery_lng` - delivery destination coordinates

  2. Changes to `profiles` table
    - `latitude` (numeric) - last known latitude
    - `longitude` (numeric) - last known longitude
    - `location_updated_at` (timestamptz) - when location was last updated

  3. New `runner_verifications` table
    - Tracks runner ID upload, bank setup, and admin approval status
    - approval_status: pending | approved | rejected
    - id_document_url: driver's license upload URL
    - stripe_connect_id: Stripe Connect account ID for payouts
    - rejection_reason: admin note on rejection
    - RLS: runner can view/update own record, admins can view all

  4. Security
    - RLS enabled on runner_verifications
    - Runners can only see their own verification record
*/

-- Add location columns to errands
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'errands' AND column_name = 'customer_lat') THEN
    ALTER TABLE errands ADD COLUMN customer_lat numeric(10,7);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'errands' AND column_name = 'customer_lng') THEN
    ALTER TABLE errands ADD COLUMN customer_lng numeric(10,7);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'errands' AND column_name = 'delivery_lat') THEN
    ALTER TABLE errands ADD COLUMN delivery_lat numeric(10,7);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'errands' AND column_name = 'delivery_lng') THEN
    ALTER TABLE errands ADD COLUMN delivery_lng numeric(10,7);
  END IF;
END $$;

-- Add location columns to profiles
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'latitude') THEN
    ALTER TABLE profiles ADD COLUMN latitude numeric(10,7);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'longitude') THEN
    ALTER TABLE profiles ADD COLUMN longitude numeric(10,7);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'profiles' AND column_name = 'location_updated_at') THEN
    ALTER TABLE profiles ADD COLUMN location_updated_at timestamptz;
  END IF;
END $$;

-- Create runner_verifications table
CREATE TABLE IF NOT EXISTS runner_verifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  runner_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  approval_status text NOT NULL DEFAULT 'pending' CHECK (approval_status IN ('pending', 'approved', 'rejected')),
  id_document_url text DEFAULT '',
  id_document_name text DEFAULT '',
  bank_account_last4 text DEFAULT '',
  bank_routing_number text DEFAULT '',
  stripe_connect_id text DEFAULT '',
  rejection_reason text DEFAULT '',
  submitted_at timestamptz DEFAULT now(),
  reviewed_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(runner_id)
);

ALTER TABLE runner_verifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Runners can view own verification"
  ON runner_verifications FOR SELECT
  TO authenticated
  USING (auth.uid() = runner_id);

CREATE POLICY "Runners can insert own verification"
  ON runner_verifications FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = runner_id);

CREATE POLICY "Runners can update own verification"
  ON runner_verifications FOR UPDATE
  TO authenticated
  USING (auth.uid() = runner_id)
  WITH CHECK (auth.uid() = runner_id);

-- Admins can view all verifications (via profile user_type check)
CREATE POLICY "Admins can view all verifications"
  ON runner_verifications FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.user_type = 'admin'
    )
  );

CREATE POLICY "Admins can update all verifications"
  ON runner_verifications FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.user_type = 'admin'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE profiles.id = auth.uid()
      AND profiles.user_type = 'admin'
    )
  );

-- Index for fast runner lookup
CREATE INDEX IF NOT EXISTS idx_runner_verifications_runner_id ON runner_verifications(runner_id);
CREATE INDEX IF NOT EXISTS idx_runner_verifications_status ON runner_verifications(approval_status);
CREATE INDEX IF NOT EXISTS idx_errands_location ON errands(customer_lat, customer_lng);
