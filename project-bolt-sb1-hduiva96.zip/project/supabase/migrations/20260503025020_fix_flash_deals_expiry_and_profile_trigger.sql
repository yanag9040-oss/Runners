/*
  # Fix Flash Deals Expiry + Auto-Profile Trigger

  1. Flash Deals
    - Updates all flash deal expiry dates to be 24-48 hours in the future
    - Ensures flash deals are visible on the home screen

  2. Auto-Profile Creation Trigger
    - Adds a trigger on auth.users that automatically creates a profile record
    - This ensures profiles are always created even if the client-side insert fails
    - Uses ON CONFLICT DO NOTHING to avoid duplicate errors

  3. Notes
    - The trigger runs as SECURITY DEFINER to bypass RLS
    - Handles both email and other auth providers
*/

-- Refresh flash deal expiry dates to 24-48 hours from now
UPDATE flash_deals
SET expires_at = now() + interval '24 hours'
WHERE title = '30% Off Grocery Runs';

UPDATE flash_deals
SET expires_at = now() + interval '36 hours'
WHERE title = 'Free Dog Walk';

UPDATE flash_deals
SET expires_at = now() + interval '12 hours'
WHERE title = '$5 Off Prescriptions';

UPDATE flash_deals
SET expires_at = now() + interval '18 hours'
WHERE title = '25% Off Laundry';

UPDATE flash_deals
SET expires_at = now() + interval '8 hours'
WHERE title = 'Flash Errand $8 Flat';

UPDATE flash_deals
SET expires_at = now() + interval '48 hours'
WHERE title = '20% Off Catering Orders';

-- Reset redemption counts so deals appear active
UPDATE flash_deals SET current_redemptions = 0;

-- Function to auto-create a profile when a new auth user is created
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, full_name, user_type)
  VALUES (
    NEW.id,
    COALESCE(NEW.email, ''),
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'user_type', 'customer')
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

-- Drop trigger if it exists then recreate
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE handle_new_user();
