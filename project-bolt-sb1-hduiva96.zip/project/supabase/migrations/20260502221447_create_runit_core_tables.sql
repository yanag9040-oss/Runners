/*
  # RunIt Core Tables

  1. New Tables
    - `profiles` - Extended user profiles for all user types (customer/runner/admin)
      - Links to auth.users via id
      - Stores user type, avatar, rating, phone, subscription plan
    - `errands` - Core errand/job records
      - All job details: service type, status, pricing, location, urgency
    - `proof_photos` - Runner-uploaded photos at each errand stage
    - `runner_stats` - Runner performance and earnings tracking
    - `group_errands` - Neighbor group errand splits
    - `flash_deals` - Time-limited discounted errand offers
    - `subscriptions` - User subscription plan records
    - `surge_zones` - Geographic surge pricing zones
    - `messages` - In-errand chat between customer and runner

  2. Security
    - RLS enabled on all tables
    - Policies scoped to authenticated users by ownership or role
*/

-- Profiles table (extends auth.users)
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  phone text DEFAULT '',
  user_type text NOT NULL DEFAULT 'customer' CHECK (user_type IN ('customer', 'runner', 'admin')),
  avatar_url text DEFAULT '',
  rating numeric(3,2) DEFAULT 5.00,
  total_ratings integer DEFAULT 0,
  is_online boolean DEFAULT false,
  bio text DEFAULT '',
  subscription_plan text DEFAULT 'free' CHECK (subscription_plan IN ('free', 'plus', 'elite')),
  accessibility_priority boolean DEFAULT false,
  stripe_customer_id text DEFAULT '',
  stripe_connect_id text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Authenticated users can view all profiles"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

-- Errands table
CREATE TABLE IF NOT EXISTS errands (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  runner_id uuid REFERENCES profiles(id) ON DELETE SET NULL,
  service_type text NOT NULL,
  title text NOT NULL DEFAULT '',
  description text DEFAULT '',
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'accepted', 'pickup', 'en_route', 'arrived', 'completed', 'cancelled')),
  pickup_address text DEFAULT '',
  delivery_address text NOT NULL DEFAULT '',
  price numeric(10,2) NOT NULL DEFAULT 0,
  tip numeric(10,2) DEFAULT 0,
  service_fee numeric(10,2) DEFAULT 0,
  surge_multiplier numeric(4,2) DEFAULT 1.00,
  urgency text DEFAULT 'standard' CHECK (urgency IN ('standard', 'urgent', 'scheduled')),
  scheduled_at timestamptz,
  notes text DEFAULT '',
  is_group_errand boolean DEFAULT false,
  group_errand_id uuid,
  flash_deal_id uuid,
  estimated_duration integer DEFAULT 30,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE errands ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Customers can view own errands"
  ON errands FOR SELECT
  TO authenticated
  USING (auth.uid() = customer_id OR auth.uid() = runner_id);

CREATE POLICY "Customers can insert errands"
  ON errands FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = customer_id);

CREATE POLICY "Runners and customers can update errands"
  ON errands FOR UPDATE
  TO authenticated
  USING (auth.uid() = customer_id OR auth.uid() = runner_id)
  WITH CHECK (auth.uid() = customer_id OR auth.uid() = runner_id);

CREATE POLICY "Runners can view pending errands"
  ON errands FOR SELECT
  TO authenticated
  USING (status = 'pending');

-- Proof photos table
CREATE TABLE IF NOT EXISTS proof_photos (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  errand_id uuid NOT NULL REFERENCES errands(id) ON DELETE CASCADE,
  runner_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  photo_url text NOT NULL,
  stage text NOT NULL CHECK (stage IN ('pickup', 'mid_errand', 'delivery')),
  caption text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE proof_photos ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Errand participants can view proof photos"
  ON proof_photos FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM errands
      WHERE errands.id = proof_photos.errand_id
      AND (errands.customer_id = auth.uid() OR errands.runner_id = auth.uid())
    )
  );

CREATE POLICY "Runners can insert proof photos"
  ON proof_photos FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = runner_id);

-- Runner stats table
CREATE TABLE IF NOT EXISTS runner_stats (
  runner_id uuid PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  earnings_today numeric(10,2) DEFAULT 0,
  earnings_week numeric(10,2) DEFAULT 0,
  earnings_month numeric(10,2) DEFAULT 0,
  earnings_total numeric(10,2) DEFAULT 0,
  streak_days integer DEFAULT 0,
  total_runs integer DEFAULT 0,
  acceptance_rate numeric(5,2) DEFAULT 100.00,
  completion_rate numeric(5,2) DEFAULT 100.00,
  badge_level text DEFAULT 'newcomer' CHECK (badge_level IN ('newcomer', 'reliable', 'pro', 'elite', 'legend')),
  gas_card_balance numeric(10,2) DEFAULT 0,
  last_active_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE runner_stats ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Runners can view own stats"
  ON runner_stats FOR SELECT
  TO authenticated
  USING (auth.uid() = runner_id);

CREATE POLICY "Runners can update own stats"
  ON runner_stats FOR UPDATE
  TO authenticated
  USING (auth.uid() = runner_id)
  WITH CHECK (auth.uid() = runner_id);

CREATE POLICY "Runners can insert own stats"
  ON runner_stats FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = runner_id);

-- Group errands table
CREATE TABLE IF NOT EXISTS group_errands (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  organizer_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  area_description text NOT NULL DEFAULT '',
  max_participants integer DEFAULT 4,
  current_participants integer DEFAULT 1,
  base_fee numeric(10,2) NOT NULL DEFAULT 0,
  split_amount numeric(10,2) DEFAULT 0,
  status text DEFAULT 'open' CHECK (status IN ('open', 'full', 'in_progress', 'completed', 'cancelled')),
  expires_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE group_errands ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view group errands"
  ON group_errands FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can create group errands"
  ON group_errands FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = organizer_id);

CREATE POLICY "Organizer can update group errands"
  ON group_errands FOR UPDATE
  TO authenticated
  USING (auth.uid() = organizer_id)
  WITH CHECK (auth.uid() = organizer_id);

-- Flash deals table
CREATE TABLE IF NOT EXISTS flash_deals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_type text NOT NULL,
  title text NOT NULL DEFAULT '',
  description text DEFAULT '',
  discount_type text NOT NULL DEFAULT 'percentage' CHECK (discount_type IN ('percentage', 'fixed')),
  discount_value numeric(10,2) NOT NULL DEFAULT 0,
  original_price numeric(10,2),
  deal_price numeric(10,2),
  max_redemptions integer DEFAULT 100,
  current_redemptions integer DEFAULT 0,
  expires_at timestamptz NOT NULL,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE flash_deals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "All users can view active flash deals"
  ON flash_deals FOR SELECT
  TO authenticated
  USING (active = true);

-- Subscriptions table
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  plan text NOT NULL DEFAULT 'free' CHECK (plan IN ('free', 'plus', 'elite')),
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'cancelled', 'past_due', 'trialing')),
  stripe_subscription_id text DEFAULT '',
  renews_at timestamptz,
  cancelled_at timestamptz,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own subscription"
  ON subscriptions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own subscription"
  ON subscriptions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own subscription"
  ON subscriptions FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Surge zones table
CREATE TABLE IF NOT EXISTS surge_zones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  area_name text NOT NULL,
  neighborhood text DEFAULT '',
  center_lat numeric(10,7) DEFAULT 0,
  center_lng numeric(10,7) DEFAULT 0,
  radius_miles numeric(5,2) DEFAULT 2.0,
  multiplier numeric(4,2) NOT NULL DEFAULT 1.00,
  active_requests integer DEFAULT 0,
  available_runners integer DEFAULT 0,
  active boolean DEFAULT true,
  color_hex text DEFAULT '#00F5A0',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE surge_zones ENABLE ROW LEVEL SECURITY;

CREATE POLICY "All authenticated users can view surge zones"
  ON surge_zones FOR SELECT
  TO authenticated
  USING (true);

-- Messages table
CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  errand_id uuid NOT NULL REFERENCES errands(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  content text NOT NULL,
  message_type text DEFAULT 'text' CHECK (message_type IN ('text', 'image', 'system')),
  read_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Errand participants can view messages"
  ON messages FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM errands
      WHERE errands.id = messages.errand_id
      AND (errands.customer_id = auth.uid() OR errands.runner_id = auth.uid())
    )
  );

CREATE POLICY "Errand participants can insert messages"
  ON messages FOR INSERT
  TO authenticated
  WITH CHECK (
    auth.uid() = sender_id AND
    EXISTS (
      SELECT 1 FROM errands
      WHERE errands.id = messages.errand_id
      AND (errands.customer_id = auth.uid() OR errands.runner_id = auth.uid())
    )
  );

-- Earnings history table
CREATE TABLE IF NOT EXISTS earnings_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  runner_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  errand_id uuid REFERENCES errands(id) ON DELETE SET NULL,
  amount numeric(10,2) NOT NULL DEFAULT 0,
  tip_amount numeric(10,2) DEFAULT 0,
  bonus_amount numeric(10,2) DEFAULT 0,
  type text DEFAULT 'errand' CHECK (type IN ('errand', 'bonus', 'streak', 'payout')),
  description text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE earnings_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Runners can view own earnings"
  ON earnings_history FOR SELECT
  TO authenticated
  USING (auth.uid() = runner_id);

CREATE POLICY "System can insert earnings"
  ON earnings_history FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = runner_id);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_errands_customer_id ON errands(customer_id);
CREATE INDEX IF NOT EXISTS idx_errands_runner_id ON errands(runner_id);
CREATE INDEX IF NOT EXISTS idx_errands_status ON errands(status);
CREATE INDEX IF NOT EXISTS idx_errands_service_type ON errands(service_type);
CREATE INDEX IF NOT EXISTS idx_proof_photos_errand_id ON proof_photos(errand_id);
CREATE INDEX IF NOT EXISTS idx_messages_errand_id ON messages(errand_id);
CREATE INDEX IF NOT EXISTS idx_earnings_runner_id ON earnings_history(runner_id);
CREATE INDEX IF NOT EXISTS idx_flash_deals_expires_at ON flash_deals(expires_at);
CREATE INDEX IF NOT EXISTS idx_surge_zones_active ON surge_zones(active);
