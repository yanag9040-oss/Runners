export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];

export type VerificationStatus = 'pending' | 'approved' | 'rejected';

export type GenericRelationship = {
  foreignKeyName: string;
  columns: string[];
  isOneToOne?: boolean;
  referencedRelation: string;
  referencedColumns: string[];
};

export type UserType = 'customer' | 'runner' | 'admin';
export type ErrandStatus = 'pending' | 'accepted' | 'pickup' | 'en_route' | 'arrived' | 'completed' | 'cancelled';
export type SubscriptionPlan = 'free' | 'plus' | 'elite';
export type BadgeLevel = 'newcomer' | 'reliable' | 'pro' | 'elite' | 'legend';
export type PhotoStage = 'pickup' | 'mid_errand' | 'delivery';

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          full_name: string;
          email: string;
          phone: string;
          user_type: UserType;
          avatar_url: string;
          rating: number;
          total_ratings: number;
          is_online: boolean;
          bio: string;
          subscription_plan: SubscriptionPlan;
          accessibility_priority: boolean;
          stripe_customer_id: string;
          stripe_connect_id: string;
          latitude: number | null;
          longitude: number | null;
          location_updated_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          full_name?: string;
          email?: string;
          phone?: string;
          user_type?: UserType;
          avatar_url?: string;
          rating?: number;
          total_ratings?: number;
          is_online?: boolean;
          bio?: string;
          subscription_plan?: SubscriptionPlan;
          accessibility_priority?: boolean;
          stripe_customer_id?: string;
          stripe_connect_id?: string;
          latitude?: number | null;
          longitude?: number | null;
          location_updated_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          full_name?: string;
          email?: string;
          phone?: string;
          user_type?: UserType;
          avatar_url?: string;
          rating?: number;
          total_ratings?: number;
          is_online?: boolean;
          bio?: string;
          subscription_plan?: SubscriptionPlan;
          accessibility_priority?: boolean;
          stripe_customer_id?: string;
          stripe_connect_id?: string;
          latitude?: number | null;
          longitude?: number | null;
          location_updated_at?: string | null;
          updated_at?: string;
        };
        Relationships: GenericRelationship[];
      };
      runner_verifications: {
        Row: {
          id: string;
          runner_id: string;
          approval_status: VerificationStatus;
          id_document_url: string;
          id_document_name: string;
          bank_account_last4: string;
          bank_routing_number: string;
          stripe_connect_id: string;
          rejection_reason: string;
          submitted_at: string;
          reviewed_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          runner_id: string;
          approval_status?: VerificationStatus;
          id_document_url?: string;
          id_document_name?: string;
          bank_account_last4?: string;
          bank_routing_number?: string;
          stripe_connect_id?: string;
          rejection_reason?: string;
          submitted_at?: string;
          reviewed_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          runner_id?: string;
          approval_status?: VerificationStatus;
          id_document_url?: string;
          id_document_name?: string;
          bank_account_last4?: string;
          bank_routing_number?: string;
          stripe_connect_id?: string;
          rejection_reason?: string;
          submitted_at?: string;
          reviewed_at?: string | null;
          updated_at?: string;
        };
        Relationships: GenericRelationship[];
      };
      errands: {
        Row: {
          id: string;
          customer_id: string;
          runner_id: string | null;
          service_type: string;
          title: string;
          description: string;
          status: ErrandStatus;
          pickup_address: string;
          delivery_address: string;
          price: number;
          tip: number;
          service_fee: number;
          surge_multiplier: number;
          urgency: string;
          scheduled_at: string | null;
          notes: string;
          is_group_errand: boolean;
          group_errand_id: string | null;
          flash_deal_id: string | null;
          estimated_duration: number;
          customer_lat: number | null;
          customer_lng: number | null;
          delivery_lat: number | null;
          delivery_lng: number | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          customer_id: string;
          runner_id?: string | null;
          service_type: string;
          title?: string;
          description?: string;
          status?: ErrandStatus;
          pickup_address?: string;
          delivery_address: string;
          price: number;
          tip?: number;
          service_fee?: number;
          surge_multiplier?: number;
          urgency?: string;
          scheduled_at?: string | null;
          notes?: string;
          is_group_errand?: boolean;
          group_errand_id?: string | null;
          flash_deal_id?: string | null;
          estimated_duration?: number;
          customer_lat?: number | null;
          customer_lng?: number | null;
          delivery_lat?: number | null;
          delivery_lng?: number | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          customer_id?: string;
          runner_id?: string | null;
          service_type?: string;
          title?: string;
          description?: string;
          status?: ErrandStatus;
          pickup_address?: string;
          delivery_address?: string;
          price?: number;
          tip?: number;
          service_fee?: number;
          surge_multiplier?: number;
          urgency?: string;
          scheduled_at?: string | null;
          notes?: string;
          is_group_errand?: boolean;
          group_errand_id?: string | null;
          flash_deal_id?: string | null;
          estimated_duration?: number;
          customer_lat?: number | null;
          customer_lng?: number | null;
          delivery_lat?: number | null;
          delivery_lng?: number | null;
          updated_at?: string;
        };
        Relationships: GenericRelationship[];
      };
      proof_photos: {
        Row: {
          id: string;
          errand_id: string;
          runner_id: string;
          photo_url: string;
          stage: PhotoStage;
          caption: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          errand_id: string;
          runner_id: string;
          photo_url: string;
          stage: PhotoStage;
          caption?: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          errand_id?: string;
          runner_id?: string;
          photo_url?: string;
          stage?: PhotoStage;
          caption?: string;
        };
        Relationships: GenericRelationship[];
      };
      runner_stats: {
        Row: {
          runner_id: string;
          earnings_today: number;
          earnings_week: number;
          earnings_month: number;
          earnings_total: number;
          streak_days: number;
          total_runs: number;
          acceptance_rate: number;
          completion_rate: number;
          badge_level: BadgeLevel;
          gas_card_balance: number;
          last_active_at: string;
          updated_at: string;
        };
        Insert: {
          runner_id: string;
          earnings_today?: number;
          earnings_week?: number;
          earnings_month?: number;
          earnings_total?: number;
          streak_days?: number;
          total_runs?: number;
          acceptance_rate?: number;
          completion_rate?: number;
          badge_level?: BadgeLevel;
          gas_card_balance?: number;
          last_active_at?: string;
          updated_at?: string;
        };
        Update: {
          runner_id?: string;
          earnings_today?: number;
          earnings_week?: number;
          earnings_month?: number;
          earnings_total?: number;
          streak_days?: number;
          total_runs?: number;
          acceptance_rate?: number;
          completion_rate?: number;
          badge_level?: BadgeLevel;
          gas_card_balance?: number;
          last_active_at?: string;
          updated_at?: string;
        };
        Relationships: GenericRelationship[];
      };
      flash_deals: {
        Row: {
          id: string;
          service_type: string;
          title: string;
          description: string;
          discount_type: 'percentage' | 'fixed';
          discount_value: number;
          original_price: number | null;
          deal_price: number | null;
          max_redemptions: number;
          current_redemptions: number;
          expires_at: string;
          active: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          service_type: string;
          title: string;
          description?: string;
          discount_type: 'percentage' | 'fixed';
          discount_value: number;
          original_price?: number | null;
          deal_price?: number | null;
          max_redemptions?: number;
          current_redemptions?: number;
          expires_at: string;
          active?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          service_type?: string;
          title?: string;
          description?: string;
          discount_type?: 'percentage' | 'fixed';
          discount_value?: number;
          original_price?: number | null;
          deal_price?: number | null;
          max_redemptions?: number;
          current_redemptions?: number;
          expires_at?: string;
          active?: boolean;
        };
        Relationships: GenericRelationship[];
      };
      surge_zones: {
        Row: {
          id: string;
          area_name: string;
          neighborhood: string;
          center_lat: number;
          center_lng: number;
          radius_miles: number;
          multiplier: number;
          active_requests: number;
          available_runners: number;
          active: boolean;
          color_hex: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          area_name: string;
          neighborhood?: string;
          center_lat?: number;
          center_lng?: number;
          radius_miles?: number;
          multiplier: number;
          active_requests?: number;
          available_runners?: number;
          active?: boolean;
          color_hex?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          area_name?: string;
          neighborhood?: string;
          center_lat?: number;
          center_lng?: number;
          radius_miles?: number;
          multiplier?: number;
          active_requests?: number;
          available_runners?: number;
          active?: boolean;
          color_hex?: string;
          updated_at?: string;
        };
        Relationships: GenericRelationship[];
      };
      subscriptions: {
        Row: {
          id: string;
          user_id: string;
          plan: SubscriptionPlan;
          status: string;
          stripe_subscription_id: string;
          renews_at: string | null;
          cancelled_at: string | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          plan: SubscriptionPlan;
          status?: string;
          stripe_subscription_id?: string;
          renews_at?: string | null;
          cancelled_at?: string | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          plan?: SubscriptionPlan;
          status?: string;
          stripe_subscription_id?: string;
          renews_at?: string | null;
          cancelled_at?: string | null;
          updated_at?: string;
        };
        Relationships: GenericRelationship[];
      };
      messages: {
        Row: {
          id: string;
          errand_id: string;
          sender_id: string;
          content: string;
          message_type: string;
          read_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          errand_id: string;
          sender_id: string;
          content: string;
          message_type?: string;
          read_at?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          errand_id?: string;
          sender_id?: string;
          content?: string;
          message_type?: string;
          read_at?: string | null;
        };
        Relationships: GenericRelationship[];
      };
      earnings_history: {
        Row: {
          id: string;
          runner_id: string;
          errand_id: string | null;
          amount: number;
          tip_amount: number;
          bonus_amount: number;
          type: string;
          description: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          runner_id: string;
          errand_id?: string | null;
          amount: number;
          tip_amount?: number;
          bonus_amount?: number;
          type?: string;
          description?: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          runner_id?: string;
          errand_id?: string | null;
          amount?: number;
          tip_amount?: number;
          bonus_amount?: number;
          type?: string;
          description?: string;
        };
        Relationships: GenericRelationship[];
      };
      group_errands: {
        Row: {
          id: string;
          organizer_id: string;
          area_description: string;
          max_participants: number;
          current_participants: number;
          base_fee: number;
          split_amount: number;
          status: string;
          expires_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          organizer_id: string;
          area_description?: string;
          max_participants?: number;
          current_participants?: number;
          base_fee: number;
          split_amount?: number;
          status?: string;
          expires_at?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          organizer_id?: string;
          area_description?: string;
          max_participants?: number;
          current_participants?: number;
          base_fee?: number;
          split_amount?: number;
          status?: string;
          expires_at?: string | null;
        };
        Relationships: GenericRelationship[];
      };
    };
    Views: Record<string, { Row: Record<string, unknown>; Relationships: GenericRelationship[] }>;
    Functions: Record<string, { Args: Record<string, unknown>; Returns: unknown }>;
    Enums: Record<string, string[]>;
    CompositeTypes: Record<string, Record<string, unknown>>;
  };
}
