import { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput,
  KeyboardAvoidingView, Platform, Dimensions, ActivityIndicator,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import {
  ChevronLeft, MapPin, Clock, Zap, Star, CircleCheck as CheckCircle,
  Navigation, Award,
} from 'lucide-react-native';
import { colors } from '@/lib/colors';
import { SERVICES, calculateTotal } from '@/lib/services';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import { useLocation } from '@/hooks/useLocation';
import type { Database } from '@/types/database';

type Profile = Database['public']['Tables']['profiles']['Row'];
type RunnerVerification = Database['public']['Tables']['runner_verifications']['Row'];
type FlashDeal = Database['public']['Tables']['flash_deals']['Row'];

const { width } = Dimensions.get('window');
const STEPS = ['Service', 'Details', 'Runner', 'Confirm'];

type AvailableRunner = Profile & { verification?: RunnerVerification };

export default function PostErrandScreen() {
  const { serviceId, dealId } = useLocalSearchParams<{ serviceId?: string; dealId?: string }>();
  const { profile } = useAuth();
  const { coords, loading: locLoading, requestLocation, saveLocationToProfile } = useLocation();

  const [step, setStep] = useState(0);
  const [selectedService, setSelectedService] = useState(serviceId || '');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [pickupAddress, setPickupAddress] = useState('');
  const [notes, setNotes] = useState('');
  const [urgency, setUrgency] = useState<'standard' | 'urgent'>('standard');
  const [tip, setTip] = useState(0);
  const [selectedRunner, setSelectedRunner] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [flashDeal, setFlashDeal] = useState<FlashDeal | null>(null);
  const [availableRunners, setAvailableRunners] = useState<AvailableRunner[]>([]);
  const [runnersLoading, setRunnersLoading] = useState(false);
  const [locationLabel, setLocationLabel] = useState('');
  const [locationRequested, setLocationRequested] = useState(false);

  useEffect(() => {
    if (serviceId) { setSelectedService(serviceId); setStep(1); }
  }, [serviceId]);

  // Load flash deal if dealId provided
  useEffect(() => {
    if (!dealId) return;
    supabase.from('flash_deals').select('*').eq('id', dealId).maybeSingle()
      .then(({ data }) => { if (data) setFlashDeal(data); });
  }, [dealId]);

  // Load available (approved, online) runners when moving to runner step
  useEffect(() => {
    if (step !== 2) return;
    setRunnersLoading(true);
    supabase
      .from('profiles')
      .select('*, runner_verifications!inner(approval_status)')
      .eq('user_type', 'runner')
      .eq('is_online', true)
      .eq('runner_verifications.approval_status', 'approved')
      .limit(10)
      .then(({ data }) => {
        if (data) setAvailableRunners(data as AvailableRunner[]);
        setRunnersLoading(false);
      });
  }, [step]);

  const handleUseMyLocation = async () => {
    setLocationRequested(true);
    const c = await requestLocation();
    if (c && profile) {
      saveLocationToProfile(profile.id, c);
      // Reverse geocode using browser API isn't standard — use coordinates as label
      setLocationLabel(`${c.latitude.toFixed(4)}, ${c.longitude.toFixed(4)}`);
      if (!deliveryAddress) {
        setDeliveryAddress(`Near ${c.latitude.toFixed(4)}, ${c.longitude.toFixed(4)}`);
      }
    }
  };

  const service = SERVICES.find(s => s.id === selectedService);

  // Apply flash deal discount if applicable
  let basePrice = service?.basePrice ?? 0;
  if (flashDeal && service) {
    if (flashDeal.discount_type === 'percentage') {
      basePrice = basePrice * (1 - flashDeal.discount_value / 100);
    } else if (flashDeal.discount_type === 'fixed') {
      basePrice = Math.max(0, basePrice - flashDeal.discount_value);
    }
    if (flashDeal.deal_price != null) basePrice = flashDeal.deal_price;
  }

  const surgeMultiplier = urgency === 'urgent' ? 1.3 : 1.0;
  const { surgedBase, serviceFee, total } = service
    ? calculateTotal(basePrice, tip, surgeMultiplier)
    : { surgedBase: 0, serviceFee: 0, total: 0 };

  const canNext = () => {
    if (step === 0) return !!selectedService;
    if (step === 1) return !!deliveryAddress.trim();
    if (step === 2) return !!selectedRunner;
    return true;
  };

  const handleSubmit = async () => {
    if (!profile || !service) return;
    setLoading(true);
    try {
      const { data, error } = await supabase.from('errands').insert({
        customer_id: profile.id,
        service_type: selectedService,
        title: service.label,
        description: notes,
        status: 'pending',
        delivery_address: deliveryAddress,
        pickup_address: pickupAddress,
        price: surgedBase,
        tip,
        service_fee: serviceFee,
        surge_multiplier: surgeMultiplier,
        urgency,
        notes,
        flash_deal_id: dealId || null,
        estimated_duration: service.estimatedMinutes,
        customer_lat: coords?.latitude ?? null,
        customer_lng: coords?.longitude ?? null,
      }).select().maybeSingle();

      if (error) throw error;

      // Increment flash deal redemptions
      if (dealId && data) {
        await supabase.from('flash_deals')
          .update({ current_redemptions: (flashDeal?.current_redemptions ?? 0) + 1 })
          .eq('id', dealId);
      }

      // If a specific runner was selected, immediately assign them
      if (data && selectedRunner && selectedRunner !== 'any') {
        await supabase.from('errands')
          .update({ runner_id: selectedRunner, status: 'accepted' })
          .eq('id', data.id);
      }

      setSubmitted(true);
      setTimeout(() => {
        if (data) router.replace({ pathname: '/errand/[id]', params: { id: data.id } });
        else router.replace('/(tabs)/explore');
      }, 1800);
    } catch (e) {
      console.error(e);
      setLoading(false);
    }
  };

  if (submitted) {
    return (
      <View style={[styles.container, styles.successContainer]}>
        <LinearGradient colors={['#080C14', '#001A12']} style={StyleSheet.absoluteFillObject} />
        <CheckCircle color={colors.primary} size={72} />
        <Text style={styles.successTitle}>Errand Posted!</Text>
        <Text style={styles.successDesc}>Finding your runner now...</Text>
        <ActivityIndicator color={colors.primary} style={{ marginTop: 24 }} />
      </View>
    );
  }

  const BADGE_COLORS: Record<string, string> = {
    newcomer: colors.textMuted,
    reliable: colors.cyan,
    pro: colors.primary,
    elite: colors.warning,
    legend: colors.error,
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <LinearGradient colors={['#080C14', '#0A1020']} style={StyleSheet.absoluteFillObject} />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => step > 0 ? setStep(step - 1) : router.back()} style={styles.backBtn}>
          <ChevronLeft color={colors.text} size={24} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Post an Errand</Text>
        <View style={{ width: 40 }} />
      </View>

      {/* Step indicator */}
      <View style={styles.stepRow}>
        {STEPS.map((s, i) => (
          <View key={s} style={styles.stepItem}>
            <View style={[styles.stepDot, i <= step && styles.stepDotActive, i < step && styles.stepDotDone]}>
              {i < step ? (
                <CheckCircle color={colors.background} size={14} />
              ) : (
                <Text style={[styles.stepNum, i <= step && styles.stepNumActive]}>{i + 1}</Text>
              )}
            </View>
            <Text style={[styles.stepLabel, i <= step && styles.stepLabelActive]}>{s}</Text>
            {i < STEPS.length - 1 && <View style={[styles.stepLine, i < step && styles.stepLineActive]} />}
          </View>
        ))}
      </View>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Step 0: Pick service */}
        {step === 0 && (
          <View style={styles.stepContent}>
            <Text style={styles.stepTitle}>What do you need?</Text>
            <Text style={styles.stepSubtitle}>Select the type of errand</Text>
            <View style={styles.serviceList}>
              {SERVICES.map(svc => (
                <TouchableOpacity
                  key={svc.id}
                  style={[styles.serviceRow, selectedService === svc.id && styles.serviceRowActive]}
                  onPress={() => setSelectedService(svc.id)}
                  activeOpacity={0.8}
                >
                  {selectedService === svc.id && (
                    <LinearGradient
                      colors={[colors.primary + '12', colors.cyan + '08']}
                      style={StyleSheet.absoluteFillObject}
                    />
                  )}
                  <Text style={styles.svcEmoji}>{svc.icon}</Text>
                  <View style={styles.svcMid}>
                    <Text style={[styles.svcName, selectedService === svc.id && styles.svcNameActive]}>
                      {svc.label}
                    </Text>
                    <Text style={styles.svcDesc}>{svc.description}</Text>
                  </View>
                  <View style={styles.svcRight}>
                    <Text style={[styles.svcPrice, selectedService === svc.id && styles.svcPriceActive]}>
                      from ${svc.basePrice}
                    </Text>
                    <Text style={styles.svcEta}>~{svc.estimatedMinutes}m</Text>
                  </View>
                  {selectedService === svc.id && (
                    <View style={styles.svcCheck}>
                      <CheckCircle color={colors.primary} size={18} fill={colors.primary} />
                    </View>
                  )}
                </TouchableOpacity>
              ))}
            </View>
          </View>
        )}

        {/* Step 1: Details */}
        {step === 1 && (
          <View style={styles.stepContent}>
            <Text style={styles.stepTitle}>Errand Details</Text>
            <Text style={styles.stepSubtitle}>Tell your runner everything they need</Text>

            {/* Flash deal banner */}
            {flashDeal && (
              <View style={styles.dealBanner}>
                <LinearGradient colors={['#1A0A00', '#0F1623']} style={StyleSheet.absoluteFillObject} />
                <Zap color={colors.warning} size={16} fill={colors.warning} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.dealBannerTitle}>{flashDeal.title}</Text>
                  <Text style={styles.dealBannerDesc}>{flashDeal.description}</Text>
                </View>
              </View>
            )}

            {/* Location button */}
            <TouchableOpacity
              style={styles.locationBtn}
              onPress={handleUseMyLocation}
              disabled={locLoading}
            >
              {locLoading ? (
                <ActivityIndicator color={colors.primary} size="small" />
              ) : (
                <Navigation color={coords ? colors.primary : colors.textMuted} size={16} />
              )}
              <Text style={[styles.locationBtnText, coords && styles.locationBtnTextActive]}>
                {coords ? `Location captured (${locationLabel || 'GPS'})` : 'Use My Location'}
              </Text>
            </TouchableOpacity>

            <View style={styles.fieldGroup}>
              <Text style={styles.fieldLabel}>Delivery Address *</Text>
              <View style={styles.inputWithIcon}>
                <MapPin color={colors.primary} size={16} />
                <TextInput
                  style={styles.input}
                  placeholder="Where should it go?"
                  placeholderTextColor={colors.textMuted}
                  value={deliveryAddress}
                  onChangeText={setDeliveryAddress}
                />
              </View>
            </View>

            <View style={styles.fieldGroup}>
              <Text style={styles.fieldLabel}>Pickup Address (optional)</Text>
              <View style={styles.inputWithIcon}>
                <MapPin color={colors.textMuted} size={16} />
                <TextInput
                  style={styles.input}
                  placeholder="Where to pick up from?"
                  placeholderTextColor={colors.textMuted}
                  value={pickupAddress}
                  onChangeText={setPickupAddress}
                />
              </View>
            </View>

            <View style={styles.fieldGroup}>
              <Text style={styles.fieldLabel}>Notes for your runner</Text>
              <TextInput
                style={[styles.inputFull, { height: 90 }]}
                placeholder="Any special instructions, preferences, or details..."
                placeholderTextColor={colors.textMuted}
                value={notes}
                onChangeText={setNotes}
                multiline
                textAlignVertical="top"
              />
            </View>

            {/* Urgency */}
            <View style={styles.fieldGroup}>
              <Text style={styles.fieldLabel}>Speed</Text>
              <View style={styles.urgencyRow}>
                {([
                  { value: 'standard', label: 'Standard', desc: 'Up to 2 hrs', price: '' },
                  { value: 'urgent', label: 'Urgent', desc: 'Priority match', price: '+30%' },
                ] as const).map(opt => (
                  <TouchableOpacity
                    key={opt.value}
                    style={[styles.urgencyCard, urgency === opt.value && styles.urgencyCardActive]}
                    onPress={() => setUrgency(opt.value)}
                  >
                    {urgency === opt.value && (
                      <LinearGradient
                        colors={[colors.primary + '12', colors.cyan + '08']}
                        style={StyleSheet.absoluteFillObject}
                      />
                    )}
                    <Clock color={urgency === opt.value ? colors.primary : colors.textMuted} size={18} />
                    <Text style={[styles.urgencyLabel, urgency === opt.value && styles.urgencyLabelActive]}>
                      {opt.label}
                    </Text>
                    <Text style={styles.urgencyDesc}>{opt.desc}</Text>
                    {opt.price ? <Text style={styles.urgencyPrice}>{opt.price}</Text> : null}
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            {/* Tip */}
            <View style={styles.fieldGroup}>
              <View style={styles.tipHeader}>
                <Text style={styles.fieldLabel}>Add a Tip</Text>
                <Text style={styles.tipAmount}>${tip}</Text>
              </View>
              <View style={styles.tipButtons}>
                {[0, 3, 5, 8, 10].map(t => (
                  <TouchableOpacity
                    key={t}
                    style={[styles.tipBtn, tip === t && styles.tipBtnActive]}
                    onPress={() => setTip(t)}
                  >
                    <Text style={[styles.tipBtnText, tip === t && styles.tipBtnTextActive]}>
                      {t === 0 ? 'No tip' : `$${t}`}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
              <Text style={styles.tipNote}>100% of your tip goes directly to your runner</Text>
            </View>
          </View>
        )}

        {/* Step 2: Choose runner */}
        {step === 2 && (
          <View style={styles.stepContent}>
            <Text style={styles.stepTitle}>Choose a Runner</Text>
            <Text style={styles.stepSubtitle}>All runners are background-checked & verified</Text>

            {runnersLoading ? (
              <ActivityIndicator color={colors.primary} style={{ marginTop: 32 }} />
            ) : availableRunners.length === 0 ? (
              <View style={styles.noRunners}>
                <Text style={styles.noRunnersEmoji}>🏃</Text>
                <Text style={styles.noRunnersTitle}>No runners online nearby</Text>
                <Text style={styles.noRunnersDesc}>
                  Choose "Best Available" and we'll match you when a runner comes online.
                </Text>
              </View>
            ) : (
              availableRunners.map(runner => {
                const badgeColor = BADGE_COLORS['reliable'];
                return (
                  <TouchableOpacity
                    key={runner.id}
                    style={[styles.runnerCard, selectedRunner === runner.id && styles.runnerCardActive]}
                    onPress={() => setSelectedRunner(runner.id)}
                    activeOpacity={0.85}
                  >
                    {selectedRunner === runner.id && (
                      <LinearGradient
                        colors={[colors.primary + '12', colors.cyan + '08']}
                        style={StyleSheet.absoluteFillObject}
                      />
                    )}
                    <View style={styles.runnerAvatarCircle}>
                      <LinearGradient colors={[colors.primary, colors.cyan]} style={styles.runnerAvatarGrad}>
                        <Text style={styles.runnerAvatarLetter}>
                          {runner.full_name?.charAt(0)?.toUpperCase() || '?'}
                        </Text>
                      </LinearGradient>
                    </View>
                    <View style={styles.runnerInfo}>
                      <View style={styles.runnerNameRow}>
                        <Text style={styles.runnerName}>{runner.full_name}</Text>
                        <View style={[styles.runnerBadge, { backgroundColor: colors.primary + '20' }]}>
                          <Award color={colors.primary} size={10} />
                          <Text style={[styles.runnerBadgeText, { color: colors.primary }]}>VERIFIED</Text>
                        </View>
                      </View>
                      <View style={styles.runnerMeta}>
                        <Star color={colors.warning} size={12} fill={colors.warning} />
                        <Text style={styles.runnerRating}>{runner.rating?.toFixed(1) ?? '5.0'}</Text>
                        <Text style={styles.runnerRuns}>• {runner.total_ratings} reviews</Text>
                      </View>
                    </View>
                    {selectedRunner === runner.id && (
                      <CheckCircle color={colors.primary} size={22} fill={colors.primary} />
                    )}
                  </TouchableOpacity>
                );
              })
            )}

            <TouchableOpacity
              style={[styles.anyRunnerCard, selectedRunner === 'any' && styles.anyRunnerCardActive]}
              onPress={() => setSelectedRunner('any')}
            >
              <Zap color={selectedRunner === 'any' ? colors.primary : colors.textMuted} size={20} />
              <View style={styles.anyRunnerText}>
                <Text style={[styles.anyRunnerTitle, selectedRunner === 'any' && { color: colors.primary }]}>
                  Best Available Runner
                </Text>
                <Text style={styles.anyRunnerDesc}>Auto-matched for fastest pickup</Text>
              </View>
              {selectedRunner === 'any' && <CheckCircle color={colors.primary} size={22} fill={colors.primary} />}
            </TouchableOpacity>
          </View>
        )}

        {/* Step 3: Confirm */}
        {step === 3 && service && (
          <View style={styles.stepContent}>
            <Text style={styles.stepTitle}>Review & Confirm</Text>
            <Text style={styles.stepSubtitle}>Double-check before we find your runner</Text>

            <View style={styles.summaryCard}>
              <View style={styles.summaryHeader}>
                <Text style={styles.summaryEmoji}>{service.icon}</Text>
                <View>
                  <Text style={styles.summaryService}>{service.label}</Text>
                  <Text style={styles.summaryAddr} numberOfLines={1}>{deliveryAddress}</Text>
                </View>
              </View>

              {flashDeal && (
                <View style={styles.dealApplied}>
                  <Zap color={colors.warning} size={12} fill={colors.warning} />
                  <Text style={styles.dealAppliedText}>Flash deal applied: {flashDeal.title}</Text>
                </View>
              )}

              {coords && (
                <View style={styles.locationConfirm}>
                  <Navigation color={colors.primary} size={12} />
                  <Text style={styles.locationConfirmText}>Location captured for runner matching</Text>
                </View>
              )}

              <View style={styles.divider} />

              <View style={styles.priceBreakdown}>
                <View style={styles.priceRow}>
                  <Text style={styles.priceLabel}>Base price</Text>
                  <Text style={styles.priceValue}>${basePrice.toFixed(2)}</Text>
                </View>
                {surgeMultiplier > 1 && (
                  <View style={styles.priceRow}>
                    <Text style={styles.priceLabel}>Urgency ({surgeMultiplier}x)</Text>
                    <Text style={[styles.priceValue, { color: colors.warning }]}>
                      +${(surgedBase - basePrice).toFixed(2)}
                    </Text>
                  </View>
                )}
                <View style={styles.priceRow}>
                  <Text style={styles.priceLabel}>Service fee (15%)</Text>
                  <Text style={styles.priceValue}>${serviceFee.toFixed(2)}</Text>
                </View>
                {tip > 0 && (
                  <View style={styles.priceRow}>
                    <Text style={styles.priceLabel}>Tip for runner</Text>
                    <Text style={[styles.priceValue, { color: colors.primary }]}>${tip.toFixed(2)}</Text>
                  </View>
                )}
                <View style={styles.divider} />
                <View style={styles.priceRow}>
                  <Text style={styles.priceLabelTotal}>Total</Text>
                  <Text style={styles.priceTotalValue}>${total.toFixed(2)}</Text>
                </View>
              </View>
            </View>
          </View>
        )}

        <View style={{ height: 120 }} />
      </ScrollView>

      {/* Bottom action */}
      <View style={styles.bottomBar}>
        {step === 3 && service && (
          <Text style={styles.totalPreview}>Total: ${total.toFixed(2)}</Text>
        )}
        <TouchableOpacity
          style={[styles.nextBtn, !canNext() && styles.nextBtnDisabled]}
          onPress={() => step < 3 ? setStep(step + 1) : handleSubmit()}
          disabled={!canNext() || loading}
          activeOpacity={0.85}
        >
          <LinearGradient
            colors={canNext() ? [colors.primary, colors.cyan] : [colors.surfaceHigh, colors.surfaceHigh]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.nextBtnGrad}
          >
            {loading ? (
              <ActivityIndicator color={canNext() ? colors.background : colors.textMuted} />
            ) : (
              <Text style={[styles.nextBtnText, !canNext() && styles.nextBtnTextDisabled]}>
                {step < 3 ? 'Continue' : 'Confirm & Pay'}
              </Text>
            )}
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  successContainer: { alignItems: 'center', justifyContent: 'center', gap: 16 },
  successTitle: { fontSize: 28, fontWeight: '800', color: colors.text },
  successDesc: { fontSize: 15, color: colors.textSecondary },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingTop: 56, paddingHorizontal: 16, paddingBottom: 12,
  },
  backBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontSize: 17, fontWeight: '700', color: colors.text },
  stepRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 16, paddingBottom: 20,
  },
  stepItem: { alignItems: 'center', flexDirection: 'row' },
  stepDot: {
    width: 28, height: 28, borderRadius: 14,
    backgroundColor: colors.surface, borderWidth: 2, borderColor: colors.border,
    alignItems: 'center', justifyContent: 'center',
  },
  stepDotActive: { borderColor: colors.primary, backgroundColor: colors.primary + '20' },
  stepDotDone: { borderColor: colors.primary, backgroundColor: colors.primary },
  stepNum: { fontSize: 12, fontWeight: '700', color: colors.textMuted },
  stepNumActive: { color: colors.primary },
  stepLabel: { fontSize: 10, color: colors.textMuted, marginLeft: 4, marginRight: 4 },
  stepLabelActive: { color: colors.primary },
  stepLine: { width: 24, height: 2, backgroundColor: colors.border, marginHorizontal: 4 },
  stepLineActive: { backgroundColor: colors.primary },
  scroll: { paddingHorizontal: 16 },
  stepContent: { paddingBottom: 16 },
  stepTitle: { fontSize: 24, fontWeight: '800', color: colors.text, marginBottom: 6 },
  stepSubtitle: { fontSize: 14, color: colors.textSecondary, marginBottom: 24 },
  serviceList: { gap: 10 },
  serviceRow: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: colors.surface, borderRadius: 14, padding: 14,
    borderWidth: 1.5, borderColor: colors.border, overflow: 'hidden',
  },
  serviceRowActive: { borderColor: colors.primary + '80' },
  svcEmoji: { fontSize: 24, width: 36, textAlign: 'center' },
  svcMid: { flex: 1 },
  svcName: { fontSize: 14, fontWeight: '700', color: colors.textSecondary, marginBottom: 2 },
  svcNameActive: { color: colors.text },
  svcDesc: { fontSize: 11, color: colors.textMuted },
  svcRight: { alignItems: 'flex-end' },
  svcPrice: { fontSize: 13, fontWeight: '600', color: colors.textMuted },
  svcPriceActive: { color: colors.primary },
  svcEta: { fontSize: 10, color: colors.textMuted },
  svcCheck: { marginLeft: 4 },
  dealBanner: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    borderRadius: 12, padding: 12, marginBottom: 16,
    borderWidth: 1, borderColor: colors.warning + '40', overflow: 'hidden',
  },
  dealBannerTitle: { fontSize: 13, fontWeight: '700', color: colors.warning, marginBottom: 2 },
  dealBannerDesc: { fontSize: 11, color: colors.textSecondary },
  locationBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: colors.surface, borderWidth: 1.5, borderColor: colors.border,
    borderRadius: 12, padding: 12, marginBottom: 16,
  },
  locationBtnText: { fontSize: 13, fontWeight: '600', color: colors.textMuted },
  locationBtnTextActive: { color: colors.primary },
  fieldGroup: { marginBottom: 20 },
  fieldLabel: { fontSize: 13, fontWeight: '600', color: colors.textSecondary, marginBottom: 8, marginLeft: 2 },
  inputWithIcon: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border,
    borderRadius: 12, paddingHorizontal: 14, paddingVertical: 14,
  },
  input: { flex: 1, fontSize: 14, color: colors.text },
  inputFull: {
    backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border,
    borderRadius: 12, paddingHorizontal: 14, paddingVertical: 12,
    fontSize: 14, color: colors.text,
  },
  urgencyRow: { flexDirection: 'row', gap: 10 },
  urgencyCard: {
    flex: 1, backgroundColor: colors.surface, borderRadius: 12, padding: 14,
    alignItems: 'center', gap: 4, borderWidth: 1.5, borderColor: colors.border, overflow: 'hidden',
  },
  urgencyCardActive: { borderColor: colors.primary + '80' },
  urgencyLabel: { fontSize: 14, fontWeight: '700', color: colors.textSecondary },
  urgencyLabelActive: { color: colors.primary },
  urgencyDesc: { fontSize: 11, color: colors.textMuted },
  urgencyPrice: { fontSize: 11, color: colors.warning, fontWeight: '600' },
  tipHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  tipAmount: { fontSize: 18, fontWeight: '800', color: colors.primary },
  tipButtons: { flexDirection: 'row', gap: 8 },
  tipBtn: {
    flex: 1, paddingVertical: 10, borderRadius: 10,
    backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, alignItems: 'center',
  },
  tipBtnActive: { backgroundColor: colors.primary + '20', borderColor: colors.primary },
  tipBtnText: { fontSize: 12, fontWeight: '600', color: colors.textMuted },
  tipBtnTextActive: { color: colors.primary },
  tipNote: { fontSize: 11, color: colors.textMuted, marginTop: 8, textAlign: 'center' },
  noRunners: { alignItems: 'center', paddingVertical: 32 },
  noRunnersEmoji: { fontSize: 48, marginBottom: 12 },
  noRunnersTitle: { fontSize: 16, fontWeight: '700', color: colors.text, marginBottom: 6 },
  noRunnersDesc: { fontSize: 13, color: colors.textSecondary, textAlign: 'center', lineHeight: 19 },
  runnerCard: {
    flexDirection: 'row', alignItems: 'center', gap: 14,
    backgroundColor: colors.surface, borderRadius: 14, padding: 16,
    marginBottom: 10, borderWidth: 1.5, borderColor: colors.border, overflow: 'hidden',
  },
  runnerCardActive: { borderColor: colors.primary + '80' },
  runnerAvatarCircle: { width: 44, height: 44, borderRadius: 22, overflow: 'hidden' },
  runnerAvatarGrad: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  runnerAvatarLetter: { fontSize: 18, fontWeight: '800', color: colors.background },
  runnerInfo: { flex: 1 },
  runnerNameRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 },
  runnerName: { fontSize: 15, fontWeight: '700', color: colors.text },
  runnerBadge: { borderRadius: 4, paddingHorizontal: 6, paddingVertical: 2, flexDirection: 'row', alignItems: 'center', gap: 3 },
  runnerBadgeText: { fontSize: 9, fontWeight: '800', letterSpacing: 0.5 },
  runnerMeta: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  runnerRating: { fontSize: 13, fontWeight: '600', color: colors.text },
  runnerRuns: { fontSize: 12, color: colors.textSecondary },
  anyRunnerCard: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: colors.surface, borderRadius: 14, padding: 16,
    borderWidth: 1.5, borderColor: colors.border, borderStyle: 'dashed',
  },
  anyRunnerCardActive: { borderColor: colors.primary + '80', borderStyle: 'solid' },
  anyRunnerText: { flex: 1 },
  anyRunnerTitle: { fontSize: 14, fontWeight: '700', color: colors.textSecondary, marginBottom: 2 },
  anyRunnerDesc: { fontSize: 12, color: colors.textMuted },
  summaryCard: {
    backgroundColor: colors.surface, borderRadius: 16,
    borderWidth: 1, borderColor: colors.border, padding: 16, marginBottom: 16,
  },
  summaryHeader: { flexDirection: 'row', gap: 12, alignItems: 'center', marginBottom: 12 },
  summaryEmoji: { fontSize: 36 },
  summaryService: { fontSize: 16, fontWeight: '700', color: colors.text, marginBottom: 3 },
  summaryAddr: { fontSize: 12, color: colors.textSecondary, maxWidth: 220 },
  dealApplied: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: colors.warning + '15', borderRadius: 8, padding: 8, marginBottom: 8,
  },
  dealAppliedText: { fontSize: 12, color: colors.warning, fontWeight: '600' },
  locationConfirm: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: colors.primary + '15', borderRadius: 8, padding: 8, marginBottom: 8,
  },
  locationConfirmText: { fontSize: 12, color: colors.primary, fontWeight: '600' },
  divider: { height: 1, backgroundColor: colors.border, marginVertical: 12 },
  priceBreakdown: { gap: 8 },
  priceRow: { flexDirection: 'row', justifyContent: 'space-between' },
  priceLabel: { fontSize: 14, color: colors.textSecondary },
  priceValue: { fontSize: 14, color: colors.text, fontWeight: '600' },
  priceLabelTotal: { fontSize: 16, fontWeight: '700', color: colors.text },
  priceTotalValue: { fontSize: 20, fontWeight: '800', color: colors.primary },
  bottomBar: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    backgroundColor: colors.surface, borderTopWidth: 1, borderTopColor: colors.border,
    padding: 16, paddingBottom: 32, gap: 8,
  },
  totalPreview: { fontSize: 14, color: colors.textSecondary, textAlign: 'center' },
  nextBtn: { borderRadius: 14, overflow: 'hidden' },
  nextBtnDisabled: { opacity: 0.5 },
  nextBtnGrad: { paddingVertical: 16, alignItems: 'center' },
  nextBtnText: { fontSize: 16, fontWeight: '700', color: colors.background },
  nextBtnTextDisabled: { color: colors.textMuted },
});
