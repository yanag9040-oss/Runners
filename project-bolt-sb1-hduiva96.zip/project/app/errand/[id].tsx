import { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, KeyboardAvoidingView, Platform, Dimensions,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { ChevronLeft, MessageCircle, Phone, Camera, CircleCheck as CheckCircle, Clock, MapPin, Truck, Star } from 'lucide-react-native';
import Animated, {
  useSharedValue, useAnimatedStyle, withRepeat, withSequence,
  withTiming, withDelay, interpolate,
} from 'react-native-reanimated';
import { colors } from '@/lib/colors';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import { SERVICES } from '@/lib/services';
import type { Database } from '@/types/database';

type Errand = Database['public']['Tables']['errands']['Row'];
type Profile = Database['public']['Tables']['profiles']['Row'];
type Message = Database['public']['Tables']['messages']['Row'];

const { width } = Dimensions.get('window');

const STAGES = [
  { key: 'accepted', label: 'Accepted', icon: CheckCircle },
  { key: 'pickup', label: 'Pickup', icon: MapPin },
  { key: 'en_route', label: 'En Route', icon: Truck },
  { key: 'arrived', label: 'Arrived', icon: CheckCircle },
];

const STATUS_ORDER = ['pending', 'accepted', 'pickup', 'en_route', 'arrived', 'completed'];

function AnimatedMapMock({ status }: { status: string }) {
  const runnerX = useSharedValue(0.15);
  const runnerY = useSharedValue(0.7);
  const pulse = useSharedValue(1);

  useEffect(() => {
    const progress = STATUS_ORDER.indexOf(status) / STATUS_ORDER.length;
    runnerX.value = withTiming(0.15 + progress * 0.65, { duration: 2000 });
    runnerY.value = withTiming(0.7 - progress * 0.4, { duration: 2000 });
    pulse.value = withRepeat(
      withSequence(withTiming(1.4, { duration: 800 }), withTiming(1, { duration: 800 })),
      -1, true
    );
  }, [status]);

  const runnerStyle = useAnimatedStyle(() => ({
    left: runnerX.value * (width - 32),
    top: runnerY.value * 180,
  }));
  const pulseStyle = useAnimatedStyle(() => ({
    transform: [{ scale: pulse.value }],
    opacity: interpolate(pulse.value, [1, 1.4], [0.6, 0]),
  }));

  return (
    <View style={mapStyles.container}>
      {/* Grid lines */}
      {[0.25, 0.5, 0.75].map(x => (
        <View key={x} style={[mapStyles.gridLineV, { left: `${x * 100}%` as any }]} />
      ))}
      {[0.33, 0.66].map(y => (
        <View key={y} style={[mapStyles.gridLineH, { top: `${y * 100}%` as any }]} />
      ))}
      {/* Route line */}
      <View style={mapStyles.routeLine} />
      {/* Destination pin */}
      <View style={mapStyles.destPin}>
        <LinearGradient colors={[colors.error, '#CC0000']} style={mapStyles.destPinInner}>
          <MapPin color="#fff" size={14} fill="#fff" />
        </LinearGradient>
        <View style={mapStyles.destPinTail} />
      </View>
      {/* Runner dot */}
      <Animated.View style={[mapStyles.runnerWrap, runnerStyle]}>
        <Animated.View style={[mapStyles.runnerPulse, pulseStyle]} />
        <LinearGradient colors={[colors.primary, colors.cyan]} style={mapStyles.runnerDot}>
          <Text style={mapStyles.runnerEmoji}>🏃</Text>
        </LinearGradient>
      </Animated.View>
      <Text style={mapStyles.mapLabel}>LIVE TRACKING</Text>
    </View>
  );
}

const mapStyles = StyleSheet.create({
  container: {
    height: 200, backgroundColor: '#0A1520', borderRadius: 16,
    overflow: 'hidden', position: 'relative', marginBottom: 16,
  },
  gridLineV: {
    position: 'absolute', top: 0, bottom: 0, width: 1,
    backgroundColor: colors.border + '60',
  },
  gridLineH: {
    position: 'absolute', left: 0, right: 0, height: 1,
    backgroundColor: colors.border + '60',
  },
  routeLine: {
    position: 'absolute', left: '18%', right: '20%', top: '55%',
    height: 2, backgroundColor: colors.primary + '60',
    borderRadius: 2,
  },
  destPin: {
    position: 'absolute', right: 60, top: 36, alignItems: 'center',
  },
  destPinInner: {
    width: 32, height: 32, borderRadius: 10, alignItems: 'center', justifyContent: 'center',
  },
  destPinTail: {
    width: 0, height: 0,
    borderLeftWidth: 6, borderRightWidth: 6, borderTopWidth: 8,
    borderLeftColor: 'transparent', borderRightColor: 'transparent',
    borderTopColor: '#CC0000',
  },
  runnerWrap: {
    position: 'absolute', alignItems: 'center', justifyContent: 'center',
    width: 40, height: 40, marginLeft: -20, marginTop: -20,
  },
  runnerPulse: {
    position: 'absolute', width: 40, height: 40, borderRadius: 20,
    backgroundColor: colors.primary,
  },
  runnerDot: {
    width: 36, height: 36, borderRadius: 18,
    alignItems: 'center', justifyContent: 'center',
  },
  runnerEmoji: { fontSize: 18 },
  mapLabel: {
    position: 'absolute', top: 12, left: 12,
    fontSize: 9, fontWeight: '800', color: colors.primary + '80',
    letterSpacing: 1.5,
  },
});

export default function ErrandDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { profile } = useAuth();
  const [errand, setErrand] = useState<Errand | null>(null);
  const [runnerProfile, setRunnerProfile] = useState<Profile | null>(null);
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [showChat, setShowChat] = useState(false);

  useEffect(() => {
    if (!id) return;
    supabase.from('errands').select('*').eq('id', id).maybeSingle()
      .then(({ data }) => {
        if (data) {
          setErrand(data);
          if (data.runner_id) {
            supabase.from('profiles').select('*').eq('id', data.runner_id).maybeSingle()
              .then(({ data: rp }) => { if (rp) setRunnerProfile(rp); });
          }
        }
      });

    // Load existing messages
    supabase.from('messages').select('*').eq('errand_id', id)
      .order('created_at', { ascending: true })
      .then(({ data }) => { if (data) setMessages(data); });

    const channel = supabase
      .channel(`errand-${id}`)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'errands', filter: `id=eq.${id}` },
        (payload) => {
          const updated = payload.new as Errand;
          setErrand(updated);
          if (updated.runner_id) {
            supabase.from('profiles').select('*').eq('id', updated.runner_id).maybeSingle()
              .then(({ data: rp }) => { if (rp) setRunnerProfile(rp); });
          }
        })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages', filter: `errand_id=eq.${id}` },
        (payload) => setMessages(prev => [...prev, payload.new as Message]))
      .subscribe();

    return () => { supabase.removeChannel(channel); };
  }, [id]);

  const service = errand ? SERVICES.find(s => s.id === errand.service_type) : null;
  const currentStageIdx = errand ? STATUS_ORDER.indexOf(errand.status) : 0;

  const sendMessage = async () => {
    if (!message.trim() || !profile || !id) return;
    const content = message.trim();
    setMessage('');
    await supabase.from('messages').insert({
      errand_id: id,
      sender_id: profile.id,
      content,
      message_type: 'text',
    });
  };

  if (!errand) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={['#080C14', '#0A1020']} style={StyleSheet.absoluteFillObject} />
        <View style={styles.center}>
          <Text style={styles.loadingText}>Loading errand...</Text>
        </View>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <LinearGradient colors={['#080C14', '#0A1020']} style={StyleSheet.absoluteFillObject} />

      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
          <ChevronLeft color={colors.text} size={24} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Live Tracking</Text>
        <View style={styles.headerRight}>
          <View style={styles.liveBadge}>
            <View style={styles.liveDot} />
            <Text style={styles.liveText}>LIVE</Text>
          </View>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* Animated Map */}
        <AnimatedMapMock status={errand.status} />

        {/* Runner info */}
        <View style={styles.runnerCard}>
          <View style={[styles.runnerAvatarCircle]}>
            <LinearGradient colors={[colors.primary, colors.cyan]} style={styles.runnerAvatarGrad}>
              <Text style={styles.runnerAvatarLetter}>
                {runnerProfile?.full_name?.charAt(0)?.toUpperCase() || '?'}
              </Text>
            </LinearGradient>
          </View>
          <View style={styles.runnerInfo}>
            <Text style={styles.runnerName}>
              {runnerProfile ? runnerProfile.full_name : errand.runner_id ? 'Runner assigned' : 'Finding runner...'}
            </Text>
            <View style={styles.ratingRow}>
              <Star color={colors.warning} size={12} fill={colors.warning} />
              <Text style={styles.ratingText}>
                {runnerProfile ? `${runnerProfile.rating?.toFixed(1) ?? '5.0'} • Runner` : 'Matching...'}
              </Text>
            </View>
          </View>
          <TouchableOpacity style={styles.actionBtn} onPress={() => setShowChat(!showChat)}>
            <MessageCircle color={colors.primary} size={20} />
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionBtn}>
            <Phone color={colors.cyan} size={20} />
          </TouchableOpacity>
        </View>

        {/* Progress bar */}
        <View style={styles.progressCard}>
          <Text style={styles.progressTitle}>
            {errand.status === 'completed' ? 'Completed!' : `Status: ${errand.status.replace('_', ' ').toUpperCase()}`}
          </Text>
          <View style={styles.stagesRow}>
            {STAGES.map((stage, i) => {
              const done = STATUS_ORDER.indexOf(errand.status) > STATUS_ORDER.indexOf(stage.key);
              const active = errand.status === stage.key;
              const Icon = stage.icon;
              return (
                <View key={stage.key} style={styles.stageItem}>
                  <View style={[styles.stageCircle,
                    done && styles.stageCircleDone,
                    active && styles.stageCircleActive]}>
                    <Icon
                      color={done ? colors.background : active ? colors.primary : colors.textMuted}
                      size={14}
                    />
                  </View>
                  <Text style={[styles.stageLabel, (done || active) && styles.stageLabelActive]}>
                    {stage.label}
                  </Text>
                  {i < STAGES.length - 1 && (
                    <View style={[styles.stageLine, done && styles.stageLineDone]} />
                  )}
                </View>
              );
            })}
          </View>
        </View>

        {/* Proof photos placeholder */}
        <View style={styles.photosSection}>
          <Text style={styles.photosSectionTitle}>Proof Photos</Text>
          <View style={styles.photosRow}>
            {['pickup', 'mid_errand', 'delivery'].map(stage => (
              <View key={stage} style={styles.photoSlot}>
                <Camera color={colors.textMuted} size={20} />
                <Text style={styles.photoSlotLabel}>
                  {stage === 'mid_errand' ? 'Mid' : stage.charAt(0).toUpperCase() + stage.slice(1)}
                </Text>
              </View>
            ))}
          </View>
        </View>

        {/* Errand details */}
        <View style={styles.detailsCard}>
          <Text style={styles.detailsTitle}>{service?.icon} {service?.label}</Text>
          <Text style={styles.detailsAddr}>{errand.delivery_address}</Text>
          {errand.notes ? <Text style={styles.detailsNotes}>{errand.notes}</Text> : null}
          <View style={styles.detailsRow}>
            <Text style={styles.detailsLabel}>Total paid</Text>
            <Text style={styles.detailsValue}>
              ${(errand.price + errand.service_fee + errand.tip).toFixed(2)}
            </Text>
          </View>
          <View style={styles.detailsRow}>
            <Text style={styles.detailsLabel}>Runner earns</Text>
            <Text style={[styles.detailsValue, { color: colors.primary }]}>
              ${(errand.price * 0.85 + errand.tip).toFixed(2)}
            </Text>
          </View>
        </View>

        {/* Chat */}
        {showChat && (
          <View style={styles.chatSection}>
            <Text style={styles.chatTitle}>Chat with Runner</Text>
            {messages.map(msg => {
              const mine = msg.sender_id === profile?.id;
              return (
                <View key={msg.id} style={[styles.msgRow, mine && styles.msgRowMine]}>
                  <View style={[styles.msgBubble, mine && styles.msgBubbleMine]}>
                    <Text style={[styles.msgText, mine && styles.msgTextMine]}>{msg.content}</Text>
                    <Text style={styles.msgTime}>
                      {new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </Text>
                  </View>
                </View>
              );
            })}
            {messages.length === 0 && (
              <Text style={styles.chatEmpty}>Send a message to your runner</Text>
            )}
          </View>
        )}

        <View style={{ height: showChat ? 80 : 32 }} />
      </ScrollView>

      {/* Chat input */}
      {showChat && (
        <View style={styles.chatInputBar}>
          <TextInput
            style={styles.chatInput}
            placeholder="Message your runner..."
            placeholderTextColor={colors.textMuted}
            value={message}
            onChangeText={setMessage}
          />
          <TouchableOpacity style={styles.sendBtn} onPress={sendMessage}>
            <LinearGradient colors={[colors.primary, colors.cyan]} style={styles.sendBtnGrad}>
              <Text style={styles.sendBtnText}>Send</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      )}
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  loadingText: { color: colors.textSecondary, fontSize: 15 },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingTop: 56, paddingHorizontal: 16, paddingBottom: 12,
  },
  backBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontSize: 17, fontWeight: '700', color: colors.text },
  headerRight: {},
  liveBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 5,
    backgroundColor: colors.error + '20', borderRadius: 8,
    paddingHorizontal: 8, paddingVertical: 5,
  },
  liveDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: colors.error },
  liveText: { fontSize: 10, fontWeight: '800', color: colors.error, letterSpacing: 1 },
  scroll: { paddingHorizontal: 16 },
  runnerCard: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: colors.surface, borderRadius: 14, padding: 14,
    borderWidth: 1, borderColor: colors.border, marginBottom: 12,
  },
  runnerAvatarCircle: { width: 44, height: 44, borderRadius: 22, overflow: 'hidden' },
  runnerAvatarGrad: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  runnerAvatarLetter: { fontSize: 18, fontWeight: '800', color: colors.background },
  runnerInfo: { flex: 1 },
  runnerName: { fontSize: 15, fontWeight: '700', color: colors.text, marginBottom: 3 },
  ratingRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  ratingText: { fontSize: 12, color: colors.textSecondary },
  actionBtn: {
    width: 40, height: 40, borderRadius: 12,
    backgroundColor: colors.surfaceElevated, alignItems: 'center', justifyContent: 'center',
  },
  progressCard: {
    backgroundColor: colors.surface, borderRadius: 14, padding: 16,
    borderWidth: 1, borderColor: colors.border, marginBottom: 12,
  },
  progressTitle: { fontSize: 14, fontWeight: '700', color: colors.text, marginBottom: 16, textAlign: 'center' },
  stagesRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  stageItem: { alignItems: 'center', flex: 1 },
  stageCircle: {
    width: 32, height: 32, borderRadius: 16,
    backgroundColor: colors.surfaceElevated, borderWidth: 2, borderColor: colors.border,
    alignItems: 'center', justifyContent: 'center', marginBottom: 6,
  },
  stageCircleActive: { borderColor: colors.primary, backgroundColor: colors.primary + '20' },
  stageCircleDone: { borderColor: colors.primary, backgroundColor: colors.primary },
  stageLabel: { fontSize: 10, color: colors.textMuted, textAlign: 'center' },
  stageLabelActive: { color: colors.primary },
  stageLine: {
    position: 'absolute', top: 16, left: '60%', right: '-60%',
    height: 2, backgroundColor: colors.border,
  },
  stageLineDone: { backgroundColor: colors.primary },
  photosSection: {
    backgroundColor: colors.surface, borderRadius: 14, padding: 14,
    borderWidth: 1, borderColor: colors.border, marginBottom: 12,
  },
  photosSectionTitle: { fontSize: 14, fontWeight: '700', color: colors.text, marginBottom: 12 },
  photosRow: { flexDirection: 'row', gap: 10 },
  photoSlot: {
    flex: 1, height: 80, borderRadius: 10,
    backgroundColor: colors.surfaceElevated, borderWidth: 1, borderColor: colors.border,
    borderStyle: 'dashed', alignItems: 'center', justifyContent: 'center', gap: 6,
  },
  photoSlotLabel: { fontSize: 11, color: colors.textMuted },
  detailsCard: {
    backgroundColor: colors.surface, borderRadius: 14, padding: 14,
    borderWidth: 1, borderColor: colors.border, marginBottom: 12, gap: 6,
  },
  detailsTitle: { fontSize: 16, fontWeight: '700', color: colors.text },
  detailsAddr: { fontSize: 13, color: colors.textSecondary },
  detailsNotes: { fontSize: 13, color: colors.textSecondary, fontStyle: 'italic' },
  detailsRow: { flexDirection: 'row', justifyContent: 'space-between' },
  detailsLabel: { fontSize: 13, color: colors.textMuted },
  detailsValue: { fontSize: 13, fontWeight: '600', color: colors.text },
  chatSection: {
    backgroundColor: colors.surface, borderRadius: 14, padding: 14,
    borderWidth: 1, borderColor: colors.border,
  },
  chatTitle: { fontSize: 14, fontWeight: '700', color: colors.text, marginBottom: 12 },
  chatEmpty: { fontSize: 13, color: colors.textMuted, textAlign: 'center', paddingVertical: 16 },
  msgRow: { marginBottom: 8 },
  msgRowMine: { alignItems: 'flex-end' },
  msgBubble: {
    maxWidth: '75%', backgroundColor: colors.surfaceElevated,
    borderRadius: 12, padding: 10,
  },
  msgBubbleMine: { backgroundColor: colors.primary + '30' },
  msgText: { fontSize: 13, color: colors.text },
  msgTextMine: { color: colors.primary },
  msgTime: { fontSize: 10, color: colors.textMuted, marginTop: 3 },
  chatInputBar: {
    flexDirection: 'row', gap: 8, padding: 12,
    backgroundColor: colors.surface, borderTopWidth: 1, borderTopColor: colors.border,
  },
  chatInput: {
    flex: 1, backgroundColor: colors.surfaceElevated, borderRadius: 10,
    paddingHorizontal: 12, paddingVertical: 10, fontSize: 14, color: colors.text,
  },
  sendBtn: { borderRadius: 10, overflow: 'hidden' },
  sendBtnGrad: { paddingHorizontal: 16, paddingVertical: 10 },
  sendBtnText: { fontSize: 13, fontWeight: '700', color: colors.background },
});
