import { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, TextInput,
  KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { ChevronLeft, CircleCheck as CheckCircle, Shield, CreditCard, Upload, Clock, CircleAlert as AlertCircle, Award } from 'lucide-react-native';
import { colors } from '@/lib/colors';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import type { Database } from '@/types/database';

type RunnerVerification = Database['public']['Tables']['runner_verifications']['Row'];

const STEPS = ['Identity', 'Banking', 'Review'];

export default function RunnerOnboardingScreen() {
  const { profile } = useAuth();
  const [step, setStep] = useState(0);
  const [verification, setVerification] = useState<RunnerVerification | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  // ID step
  const [idDocName, setIdDocName] = useState('');
  const [idDocUrl, setIdDocUrl] = useState('');
  const [idUploading, setIdUploading] = useState(false);

  // Banking step
  const [bankLast4, setBankLast4] = useState('');
  const [routingNumber, setRoutingNumber] = useState('');

  // Errors
  const [error, setError] = useState('');

  useEffect(() => {
    if (!profile) return;
    supabase.from('runner_verifications')
      .select('*').eq('runner_id', profile.id).maybeSingle()
      .then(({ data }) => {
        if (data) {
          setVerification(data);
          setIdDocUrl(data.id_document_url);
          setIdDocName(data.id_document_name);
          setBankLast4(data.bank_account_last4);
          setRoutingNumber(data.bank_routing_number);
        }
        setLoading(false);
      });
  }, [profile]);

  const handleSimulateIdUpload = async () => {
    if (!profile) return;
    setIdUploading(true);
    // Simulate ID upload - in production, this would open a file picker and upload to Supabase Storage
    await new Promise(r => setTimeout(r, 1200));
    const fakeUrl = `https://storage.example.com/id-docs/${profile.id}/license.jpg`;
    const fakeName = `drivers_license_${profile.full_name?.replace(' ', '_')}.jpg`;
    setIdDocUrl(fakeUrl);
    setIdDocName(fakeName);
    setIdUploading(false);
  };

  const canAdvance = () => {
    if (step === 0) return !!idDocUrl;
    if (step === 1) return bankLast4.length === 4 && routingNumber.length === 9;
    return true;
  };

  const handleSubmit = async () => {
    if (!profile) return;
    setError('');
    setSubmitting(true);

    const record = {
      runner_id: profile.id,
      id_document_url: idDocUrl,
      id_document_name: idDocName,
      bank_account_last4: bankLast4,
      bank_routing_number: routingNumber,
      approval_status: 'pending' as const,
      submitted_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    const { error: upsertError } = await supabase
      .from('runner_verifications')
      .upsert(record, { onConflict: 'runner_id' });

    if (upsertError) {
      setError(upsertError.message);
      setSubmitting(false);
      return;
    }

    // Refetch to get updated state
    const { data } = await supabase
      .from('runner_verifications')
      .select('*').eq('runner_id', profile.id).maybeSingle();
    if (data) setVerification(data);

    setSubmitting(false);
    setStep(3); // completion state
  };

  if (loading) {
    return (
      <View style={[styles.container, styles.center]}>
        <LinearGradient colors={['#080C14', '#0A1020']} style={StyleSheet.absoluteFillObject} />
        <ActivityIndicator color={colors.primary} />
      </View>
    );
  }

  // Already submitted — show status
  if (verification && step !== 3) {
    const statusConfig = {
      pending: {
        icon: Clock,
        color: colors.warning,
        title: 'Verification Pending',
        desc: 'Your application is under review. We\'ll notify you within 24 hours.',
      },
      approved: {
        icon: CheckCircle,
        color: colors.primary,
        title: 'Verification Approved!',
        desc: 'You\'re all set to accept jobs on RunIt.',
      },
      rejected: {
        icon: AlertCircle,
        color: colors.error,
        title: 'Verification Rejected',
        desc: verification.rejection_reason || 'Please resubmit with correct documents.',
      },
    };

    const cfg = statusConfig[verification.approval_status];
    const Icon = cfg.icon;

    return (
      <View style={styles.container}>
        <LinearGradient colors={['#080C14', '#0A1020']} style={StyleSheet.absoluteFillObject} />
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <ChevronLeft color={colors.text} size={24} />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Runner Verification</Text>
          <View style={{ width: 40 }} />
        </View>

        <View style={styles.statusContainer}>
          <View style={[styles.statusIconWrap, { backgroundColor: cfg.color + '20' }]}>
            <Icon color={cfg.color} size={48} />
          </View>
          <Text style={[styles.statusTitle, { color: cfg.color }]}>{cfg.title}</Text>
          <Text style={styles.statusDesc}>{cfg.desc}</Text>

          {verification.approval_status === 'approved' && (
            <TouchableOpacity
              style={styles.ctaBtn}
              onPress={() => router.replace('/(tabs)/runner')}
            >
              <LinearGradient colors={[colors.primary, colors.cyan]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.ctaBtnGrad}>
                <Text style={styles.ctaBtnText}>Start Accepting Jobs</Text>
              </LinearGradient>
            </TouchableOpacity>
          )}

          {verification.approval_status === 'rejected' && (
            <TouchableOpacity
              style={styles.ctaBtn}
              onPress={() => setVerification(null)}
            >
              <LinearGradient colors={[colors.error, '#CC0000']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.ctaBtnGrad}>
                <Text style={styles.ctaBtnText}>Resubmit Application</Text>
              </LinearGradient>
            </TouchableOpacity>
          )}

          {verification.approval_status === 'pending' && (
            <View style={styles.pendingInfo}>
              <Text style={styles.pendingInfoText}>Submitted: {new Date(verification.submitted_at).toLocaleDateString()}</Text>
            </View>
          )}
        </View>
      </View>
    );
  }

  // Completion state after submit
  if (step === 3) {
    return (
      <View style={[styles.container, styles.center]}>
        <LinearGradient colors={['#080C14', '#001A12']} style={StyleSheet.absoluteFillObject} />
        <View style={[styles.statusIconWrap, { backgroundColor: colors.primary + '20' }]}>
          <CheckCircle color={colors.primary} size={64} />
        </View>
        <Text style={styles.statusTitle}>Application Submitted!</Text>
        <Text style={styles.statusDesc}>
          We'll review your documents and notify you within 24 hours. You'll receive an email once approved.
        </Text>
        <TouchableOpacity style={[styles.ctaBtn, { marginTop: 32 }]} onPress={() => router.replace('/(tabs)/runner')}>
          <LinearGradient colors={[colors.primary, colors.cyan]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.ctaBtnGrad}>
            <Text style={styles.ctaBtnText}>Back to Dashboard</Text>
          </LinearGradient>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <LinearGradient colors={['#080C14', '#0A1020']} style={StyleSheet.absoluteFillObject} />

      <View style={styles.header}>
        <TouchableOpacity onPress={() => step > 0 ? setStep(step - 1) : router.back()} style={styles.backBtn}>
          <ChevronLeft color={colors.text} size={24} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Runner Verification</Text>
        <View style={{ width: 40 }} />
      </View>

      {/* Step indicator */}
      <View style={styles.stepRow}>
        {STEPS.map((s, i) => (
          <View key={s} style={styles.stepItem}>
            <View style={[styles.stepDot, i <= step && styles.stepDotActive, i < step && styles.stepDotDone]}>
              {i < step ? (
                <CheckCircle color={colors.background} size={14} />
              ) : (
                <Text style={[styles.stepNum, i <= step && styles.stepNumActive]}>{i + 1}</Text>
              )}
            </View>
            <Text style={[styles.stepLabel, i <= step && styles.stepLabelActive]}>{s}</Text>
            {i < STEPS.length - 1 && <View style={[styles.stepLine, i < step && styles.stepLineActive]} />}
          </View>
        ))}
      </View>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Step 0: ID Upload */}
        {step === 0 && (
          <View style={styles.stepContent}>
            <View style={styles.stepIconRow}>
              <Shield color={colors.primary} size={32} />
            </View>
            <Text style={styles.stepTitle}>Verify Your Identity</Text>
            <Text style={styles.stepSubtitle}>
              We need a government-issued ID to keep our community safe.
              All documents are encrypted and securely stored.
            </Text>

            <View style={styles.infoCard}>
              <Text style={styles.infoCardTitle}>Accepted Documents</Text>
              {["Driver's License", "State ID Card", "Passport"].map(doc => (
                <View key={doc} style={styles.infoRow}>
                  <CheckCircle color={colors.primary} size={14} />
                  <Text style={styles.infoText}>{doc}</Text>
                </View>
              ))}
            </View>

            {idDocUrl ? (
              <View style={styles.uploadSuccess}>
                <LinearGradient colors={[colors.primary + '15', colors.cyan + '08']} style={StyleSheet.absoluteFillObject} />
                <CheckCircle color={colors.primary} size={24} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.uploadSuccessTitle}>Document Uploaded</Text>
                  <Text style={styles.uploadSuccessName} numberOfLines={1}>{idDocName}</Text>
                </View>
                <TouchableOpacity onPress={() => { setIdDocUrl(''); setIdDocName(''); }}>
                  <Text style={styles.reuploadText}>Change</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <TouchableOpacity style={styles.uploadBtn} onPress={handleSimulateIdUpload} disabled={idUploading}>
                <LinearGradient
                  colors={[colors.surfaceElevated, colors.surface]}
                  style={StyleSheet.absoluteFillObject}
                />
                {idUploading ? (
                  <ActivityIndicator color={colors.primary} />
                ) : (
                  <Upload color={colors.primary} size={28} />
                )}
                <Text style={styles.uploadBtnTitle}>
                  {idUploading ? 'Uploading...' : 'Upload ID Document'}
                </Text>
                <Text style={styles.uploadBtnSubtitle}>
                  {idUploading ? 'Please wait' : 'JPG, PNG, or PDF — max 10MB'}
                </Text>
              </TouchableOpacity>
            )}

            <View style={styles.privacyNote}>
              <Shield color={colors.textMuted} size={14} />
              <Text style={styles.privacyNoteText}>
                Your ID is only used for verification and is never shared with customers or runners.
              </Text>
            </View>
          </View>
        )}

        {/* Step 1: Banking */}
        {step === 1 && (
          <View style={styles.stepContent}>
            <View style={styles.stepIconRow}>
              <CreditCard color={colors.primary} size={32} />
            </View>
            <Text style={styles.stepTitle}>Bank Account Setup</Text>
            <Text style={styles.stepSubtitle}>
              Add your bank account to receive instant payouts after each completed errand.
            </Text>

            <View style={styles.infoCard}>
              <Text style={styles.infoCardTitle}>Payout Schedule</Text>
              {["Instant transfer available (standard fee)", "Free next-day ACH deposits", "Weekly automatic payouts"].map(item => (
                <View key={item} style={styles.infoRow}>
                  <CheckCircle color={colors.primary} size={14} />
                  <Text style={styles.infoText}>{item}</Text>
                </View>
              ))}
            </View>

            <View style={styles.fieldGroup}>
              <Text style={styles.fieldLabel}>Account Last 4 Digits</Text>
              <View style={styles.inputWithIcon}>
                <CreditCard color={colors.textMuted} size={16} />
                <TextInput
                  style={styles.input}
                  placeholder="1234"
                  placeholderTextColor={colors.textMuted}
                  value={bankLast4}
                  onChangeText={v => setBankLast4(v.replace(/\D/g, '').slice(0, 4))}
                  keyboardType="numeric"
                  maxLength={4}
                />
              </View>
            </View>

            <View style={styles.fieldGroup}>
              <Text style={styles.fieldLabel}>Routing Number</Text>
              <View style={styles.inputWithIcon}>
                <CreditCard color={colors.textMuted} size={16} />
                <TextInput
                  style={styles.input}
                  placeholder="021000021"
                  placeholderTextColor={colors.textMuted}
                  value={routingNumber}
                  onChangeText={v => setRoutingNumber(v.replace(/\D/g, '').slice(0, 9))}
                  keyboardType="numeric"
                  maxLength={9}
                />
              </View>
            </View>

            <View style={styles.privacyNote}>
              <Shield color={colors.textMuted} size={14} />
              <Text style={styles.privacyNoteText}>
                Banking info is encrypted using bank-grade security. We use Stripe for all payouts.
              </Text>
            </View>
          </View>
        )}

        {/* Step 2: Review */}
        {step === 2 && (
          <View style={styles.stepContent}>
            <View style={styles.stepIconRow}>
              <Award color={colors.primary} size={32} />
            </View>
            <Text style={styles.stepTitle}>Review & Submit</Text>
            <Text style={styles.stepSubtitle}>
              Check your details before submitting for review.
            </Text>

            <View style={styles.reviewCard}>
              <Text style={styles.reviewCardTitle}>Identity</Text>
              <View style={styles.reviewRow}>
                <Shield color={colors.primary} size={16} />
                <Text style={styles.reviewLabel}>Document:</Text>
                <Text style={styles.reviewValue} numberOfLines={1}>{idDocName}</Text>
              </View>
            </View>

            <View style={styles.reviewCard}>
              <Text style={styles.reviewCardTitle}>Banking</Text>
              <View style={styles.reviewRow}>
                <CreditCard color={colors.cyan} size={16} />
                <Text style={styles.reviewLabel}>Account:</Text>
                <Text style={styles.reviewValue}>••••{bankLast4}</Text>
              </View>
              <View style={styles.reviewRow}>
                <CreditCard color={colors.cyan} size={16} />
                <Text style={styles.reviewLabel}>Routing:</Text>
                <Text style={styles.reviewValue}>•••{routingNumber.slice(-4)}</Text>
              </View>
            </View>

            <View style={styles.timelineCard}>
              <Text style={styles.timelineTitle}>What happens next?</Text>
              {[
                { step: '1', text: 'Application submitted & encrypted' },
                { step: '2', text: 'ID verified within 24 hours' },
                { step: '3', text: 'Background check (2–3 days)' },
                { step: '4', text: 'Account approved — start earning!' },
              ].map(item => (
                <View key={item.step} style={styles.timelineRow}>
                  <View style={styles.timelineStep}>
                    <Text style={styles.timelineStepText}>{item.step}</Text>
                  </View>
                  <Text style={styles.timelineText}>{item.text}</Text>
                </View>
              ))}
            </View>

            {error ? <Text style={styles.errorText}>{error}</Text> : null}
          </View>
        )}

        <View style={{ height: 120 }} />
      </ScrollView>

      <View style={styles.bottomBar}>
        <TouchableOpacity
          style={[styles.nextBtn, !canAdvance() && styles.nextBtnDisabled]}
          onPress={() => step < 2 ? setStep(step + 1) : handleSubmit()}
          disabled={!canAdvance() || submitting}
        >
          <LinearGradient
            colors={canAdvance() ? [colors.primary, colors.cyan] : [colors.surfaceHigh, colors.surfaceHigh]}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            style={styles.nextBtnGrad}
          >
            {submitting ? (
              <ActivityIndicator color={colors.background} />
            ) : (
              <Text style={[styles.nextBtnText, !canAdvance() && styles.nextBtnTextDisabled]}>
                {step < 2 ? 'Continue' : 'Submit Application'}
              </Text>
            )}
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  center: { alignItems: 'center', justifyContent: 'center', padding: 32 },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingTop: 56, paddingHorizontal: 16, paddingBottom: 12,
  },
  backBtn: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  headerTitle: { fontSize: 17, fontWeight: '700', color: colors.text },
  stepRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 16, paddingBottom: 20,
  },
  stepItem: { alignItems: 'center', flexDirection: 'row' },
  stepDot: {
    width: 28, height: 28, borderRadius: 14,
    backgroundColor: colors.surface, borderWidth: 2, borderColor: colors.border,
    alignItems: 'center', justifyContent: 'center',
  },
  stepDotActive: { borderColor: colors.primary, backgroundColor: colors.primary + '20' },
  stepDotDone: { borderColor: colors.primary, backgroundColor: colors.primary },
  stepNum: { fontSize: 12, fontWeight: '700', color: colors.textMuted },
  stepNumActive: { color: colors.primary },
  stepLabel: { fontSize: 10, color: colors.textMuted, marginLeft: 4, marginRight: 4 },
  stepLabelActive: { color: colors.primary },
  stepLine: { width: 24, height: 2, backgroundColor: colors.border, marginHorizontal: 4 },
  stepLineActive: { backgroundColor: colors.primary },
  scroll: { paddingHorizontal: 16 },
  stepContent: { paddingBottom: 16 },
  stepIconRow: { alignItems: 'center', marginBottom: 16, marginTop: 8 },
  stepTitle: { fontSize: 24, fontWeight: '800', color: colors.text, marginBottom: 8, textAlign: 'center' },
  stepSubtitle: { fontSize: 14, color: colors.textSecondary, marginBottom: 24, textAlign: 'center', lineHeight: 21 },
  infoCard: {
    backgroundColor: colors.surface, borderRadius: 14, padding: 16,
    borderWidth: 1, borderColor: colors.border, marginBottom: 20, gap: 10,
  },
  infoCardTitle: { fontSize: 13, fontWeight: '700', color: colors.text, marginBottom: 4 },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  infoText: { fontSize: 13, color: colors.textSecondary },
  uploadBtn: {
    borderRadius: 16, padding: 32, alignItems: 'center', gap: 8,
    borderWidth: 2, borderColor: colors.border, borderStyle: 'dashed',
    overflow: 'hidden', marginBottom: 16,
  },
  uploadBtnTitle: { fontSize: 15, fontWeight: '700', color: colors.text },
  uploadBtnSubtitle: { fontSize: 12, color: colors.textMuted },
  uploadSuccess: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    borderRadius: 14, padding: 14, marginBottom: 16,
    borderWidth: 1.5, borderColor: colors.primary + '60', overflow: 'hidden',
  },
  uploadSuccessTitle: { fontSize: 14, fontWeight: '700', color: colors.primary },
  uploadSuccessName: { fontSize: 12, color: colors.textSecondary },
  reuploadText: { fontSize: 13, color: colors.primary, fontWeight: '600' },
  privacyNote: {
    flexDirection: 'row', alignItems: 'flex-start', gap: 8,
    backgroundColor: colors.surface, borderRadius: 10, padding: 12,
  },
  privacyNoteText: { flex: 1, fontSize: 12, color: colors.textMuted, lineHeight: 18 },
  fieldGroup: { marginBottom: 20 },
  fieldLabel: { fontSize: 13, fontWeight: '600', color: colors.textSecondary, marginBottom: 8 },
  inputWithIcon: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border,
    borderRadius: 12, paddingHorizontal: 14, paddingVertical: 14,
  },
  input: { flex: 1, fontSize: 14, color: colors.text },
  reviewCard: {
    backgroundColor: colors.surface, borderRadius: 14, padding: 16,
    borderWidth: 1, borderColor: colors.border, marginBottom: 14, gap: 10,
  },
  reviewCardTitle: { fontSize: 12, fontWeight: '700', color: colors.textMuted, textTransform: 'uppercase', letterSpacing: 0.5 },
  reviewRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  reviewLabel: { fontSize: 13, color: colors.textSecondary, width: 70 },
  reviewValue: { flex: 1, fontSize: 13, fontWeight: '600', color: colors.text },
  timelineCard: {
    backgroundColor: colors.surface, borderRadius: 14, padding: 16,
    borderWidth: 1, borderColor: colors.border, gap: 12,
  },
  timelineTitle: { fontSize: 14, fontWeight: '700', color: colors.text, marginBottom: 4 },
  timelineRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  timelineStep: {
    width: 24, height: 24, borderRadius: 12,
    backgroundColor: colors.primary + '20', borderWidth: 1, borderColor: colors.primary,
    alignItems: 'center', justifyContent: 'center',
  },
  timelineStepText: { fontSize: 11, fontWeight: '800', color: colors.primary },
  timelineText: { flex: 1, fontSize: 13, color: colors.textSecondary },
  errorText: { fontSize: 13, color: colors.error, textAlign: 'center', marginTop: 12 },
  bottomBar: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    backgroundColor: colors.surface, borderTopWidth: 1, borderTopColor: colors.border,
    padding: 16, paddingBottom: 32,
  },
  nextBtn: { borderRadius: 14, overflow: 'hidden' },
  nextBtnDisabled: { opacity: 0.5 },
  nextBtnGrad: { paddingVertical: 16, alignItems: 'center' },
  nextBtnText: { fontSize: 16, fontWeight: '700', color: colors.background },
  nextBtnTextDisabled: { color: colors.textMuted },
  statusContainer: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 32 },
  statusIconWrap: { width: 96, height: 96, borderRadius: 48, alignItems: 'center', justifyContent: 'center', marginBottom: 24 },
  statusTitle: { fontSize: 24, fontWeight: '800', textAlign: 'center', marginBottom: 12 },
  statusDesc: { fontSize: 15, color: colors.textSecondary, textAlign: 'center', lineHeight: 22 },
  ctaBtn: { borderRadius: 14, overflow: 'hidden', marginTop: 32, width: '100%' },
  ctaBtnGrad: { paddingVertical: 16, alignItems: 'center' },
  ctaBtnText: { fontSize: 16, fontWeight: '700', color: colors.background },
  pendingInfo: { marginTop: 20 },
  pendingInfoText: { fontSize: 13, color: colors.textMuted },
});
