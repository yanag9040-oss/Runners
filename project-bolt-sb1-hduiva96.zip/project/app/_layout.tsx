import { useEffect } from 'react';
import { View, ActivityIndicator } from 'react-native';
import { Stack, router } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useFrameworkReady } from '@/hooks/useFrameworkReady';
import { useAuth } from '@/hooks/useAuth';

export default function RootLayout() {
  useFrameworkReady();
  const { session, profile, loading } = useAuth();

  useEffect(() => {
    if (loading) return;
    if (!session) {
      router.replace('/(auth)/welcome');
    } else if (profile) {
      if (profile.user_type === 'runner') {
        router.replace('/(tabs)/runner');
      } else if (profile.user_type === 'admin') {
        router.replace('/(tabs)/admin');
      } else {
        router.replace('/(tabs)/home');
      }
    }
  }, [session, profile, loading]);

  if (loading) {
    return (
      <View style={{ flex: 1, backgroundColor: '#080C14', alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator size="large" color="#00F5A0" />
        <StatusBar style="light" />
      </View>
    );
  }

  return (
    <>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(auth)" />
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="errand/[id]" options={{ presentation: 'card' }} />
        <Stack.Screen name="errand/post" options={{ presentation: 'card' }} />
        <Stack.Screen name="runner/onboarding" options={{ presentation: 'card' }} />
        <Stack.Screen name="+not-found" />
      </Stack>
      <StatusBar style="light" />
    </>
  );
}
