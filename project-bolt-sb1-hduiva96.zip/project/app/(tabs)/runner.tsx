import { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Dimensions, ActivityIndicator,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Zap, MapPin, TrendingUp, Award, Flame, Clock, Shield, ChevronRight } from 'lucide-react-native';
import Animated, {
  useSharedValue, useAnimatedStyle, withTiming, withRepeat,
  withSequence, withSpring,
} from 'react-native-reanimated';
import { colors } from '@/lib/colors';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import { useLocation } from '@/hooks/useLocation';
import { SERVICES } from '@/lib/services';
import type { Database } from '@/types/database';

type RunnerStats = Database['public']['Tables']['runner_stats']['Row'];
type SurgeZone = Database['public']['Tables']['surge_zones']['Row'];
type Errand = Database['public']['Tables']['errands']['Row'];
type RunnerVerification = Database['public']['Tables']['runner_verifications']['Row'];

const { width } = Dimensions.get('window');

function SurgeMapMock({ zones }: { zones: SurgeZone[] }) {
  const positions = [
    { x: 0.2, y: 0.3 },
    { x: 0.55, y: 0.55 },
    { x: 0.75, y: 0.2 },
    { x: 0.35, y: 0.7 },
    { x: 0.85, y: 0.65 },
  ];

  const getColor = (multiplier: number) => {
    if (multiplier >= 2) return colors.error;
    if (multiplier >= 1.6) return colors.surge2;
    return colors.surge1;
  };

  return (
    <View style={surgeStyles.map}>
      {[0.25, 0.5, 0.75].map(x => (
        <View key={`v${x}`} style={[surgeStyles.gridV, { left: `${x * 100}%` as any }]} />
      ))}
      {[0.33, 0.66].map(y => (
        <View key={`h${y}`} style={[surgeStyles.gridH, { top: `${y * 100}%` as any }]} />
      ))}
      {zones.slice(0, 5).map((zone, i) => {
        const pos = positions[i] || { x: 0.5, y: 0.5 };
        const c = getColor(zone.multiplier);
        const r = 30 + zone.active_requests * 0.4;
        return (
          <View key={zone.id} style={[
            surgeStyles.zone,
            {
              left: pos.x * (width - 48) - r,
              top: pos.y * 160 - r,
              width: r * 2,
              height: r * 2,
              borderRadius: r,
              backgroundColor: c + '30',
              borderColor: c + '80',
            }
          ]}>
            <Text style={[surgeStyles.zoneMultiplier, { color: c }]}>
              {zone.multiplier}x
            </Text>
          </View>
        );
      })}
      {/* Runner dot */}
      <View style={surgeStyles.youDot}>
        <LinearGradient colors={[colors.primary, colors.cyan]} style={surgeStyles.youInner}>
          <Text style={{ fontSize: 10 }}>YOU</Text>
        </LinearGradient>
      </View>
      <Text style={surgeStyles.mapLabel}>SURGE ZONE MAP</Text>
    </View>
  );
}

const surgeStyles = StyleSheet.create({
  map: {
    height: 180, backgroundColor: '#0A1520', borderRadius: 14,
    overflow: 'hidden', position: 'relative', marginBottom: 8,
  },
  gridV: { position: 'absolute', top: 0, bottom: 0, width: 1, backgroundColor: colors.border + '40' },
  gridH: { position: 'absolute', left: 0, right: 0, height: 1, backgroundColor: colors.border + '40' },
  zone: {
    position: 'absolute', alignItems: 'center', justifyContent: 'center',
    borderWidth: 1,
  },
  zoneMultiplier: { fontSize: 12, fontWeight: '800' },
  youDot: {
    position: 'absolute', left: '45%', top: '48%',
    width: 32, height: 32, borderRadius: 16,
    shadowColor: colors.primary, shadowOpacity: 0.8, shadowRadius: 8,
  },
  youInner: {
    width: 32, height: 32, borderRadius: 16,
    alignItems: 'center', justifyContent: 'center',
  },
  mapLabel: {
    position: 'absolute', top: 10, left: 12,
    fontSize: 9, fontWeight: '800', color: colors.primary + '80', letterSpacing: 1.5,
  },
});

const NEARBY_RADIUS_MILES = 15;

export default function RunnerDashboard() {
  const { profile } = useAuth();
  const { coords, requestLocation, saveLocationToProfile, distanceMiles } = useLocation();
  const [isOnline, setIsOnline] = useState(false);
  const [stats, setStats] = useState<RunnerStats | null>(null);
  const [surgeZones, setSurgeZones] = useState<SurgeZone[]>([]);
  const [availableJobs, setAvailableJobs] = useState<Errand[]>([]);
  const [loadingJob, setLoadingJob] = useState<string | null>(null);
  const [verification, setVerification] = useState<RunnerVerification | null>(null);
  const [verificationLoading, setVerificationLoading] = useState(true);
  const earningsTicker = useSharedValue(0);
  const onlineScale = useSharedValue(1);

  useEffect(() => {
    if (!profile) return;

    // Load verification status
    supabase.from('runner_verifications').select('*').eq('runner_id', profile.id).maybeSingle()
      .then(({ data }) => { setVerification(data); setVerificationLoading(false); });

    supabase.from('runner_stats').select('*').eq('runner_id', profile.id).maybeSingle()
      .then(({ data }) => {
        if (data) {
          setStats(data);
          earningsTicker.value = withTiming(data.earnings_today, { duration: 1500 });
        }
      });
    supabase.from('profiles').select('is_online, latitude, longitude').eq('id', profile.id).maybeSingle()
      .then(({ data }) => { if (data) setIsOnline(data.is_online ?? false); });
    supabase.from('surge_zones').select('*').eq('active', true)
      .then(({ data }) => { if (data) setSurgeZones(data); });
    loadNearbyJobs();
  }, [profile]);

  const loadNearbyJobs = async () => {
    const allJobs = await supabase
      .from('errands').select('*').eq('status', 'pending')
      .order('created_at', { ascending: false }).limit(20);

    if (!allJobs.data) return;

    // Filter by distance if runner has location and errands have coordinates
    if (coords) {
      const nearby = allJobs.data.filter(e => {
        if (!e.customer_lat || !e.customer_lng) return true; // include if no coords set
        return distanceMiles(coords, { latitude: e.customer_lat, longitude: e.customer_lng }) <= NEARBY_RADIUS_MILES;
      });
      setAvailableJobs(nearby.slice(0, 8));
    } else {
      setAvailableJobs(allJobs.data.slice(0, 8));
    }
  };

  // Get location and save it
  const handleGetLocation = async () => {
    const c = await requestLocation();
    if (c && profile) {
      saveLocationToProfile(profile.id, c);
      loadNearbyJobs();
    }
  };

  const toggleOnline = async () => {
    if (!profile) return;
    if (verification?.approval_status !== 'approved') {
      router.push('/runner/onboarding');
      return;
    }
    const next = !isOnline;
    setIsOnline(next);
    onlineScale.value = withSequence(withSpring(1.15), withSpring(1));
    await supabase.from('profiles').update({ is_online: next }).eq('id', profile.id);
    if (next && !coords) handleGetLocation();
  };

  const acceptJob = async (errand: Errand) => {
    if (!profile) return;
    setLoadingJob(errand.id);

    // Accept the errand
    const { error } = await supabase.from('errands')
      .update({ runner_id: profile.id, status: 'accepted' })
      .eq('id', errand.id);

    if (!error) {
      const runnerEarnings = parseFloat((errand.price * 0.85 + errand.tip).toFixed(2));
      const serviceName = errand.title || errand.service_type;

      // Write earnings_history record
      await supabase.from('earnings_history').insert({
        runner_id: profile.id,
        errand_id: errand.id,
        amount: runnerEarnings,
        tip_amount: errand.tip,
        bonus_amount: 0,
        type: 'errand',
        description: serviceName,
      });

      // Update runner_stats
      await supabase.from('runner_stats').upsert({
        runner_id: profile.id,
        earnings_today: (stats?.earnings_today ?? 0) + runnerEarnings,
        earnings_week: (stats?.earnings_week ?? 0) + runnerEarnings,
        earnings_month: (stats?.earnings_month ?? 0) + runnerEarnings,
        earnings_total: (stats?.earnings_total ?? 0) + runnerEarnings,
        total_runs: (stats?.total_runs ?? 0) + 1,
        last_active_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }, { onConflict: 'runner_id' });
    }

    setAvailableJobs(prev => prev.filter(e => e.id !== errand.id));
    setLoadingJob(null);
    router.push({ pathname: '/errand/[id]', params: { id: errand.id } });
  };

  const onlineStyle = useAnimatedStyle(() => ({
    transform: [{ scale: onlineScale.value }],
  }));

  const BADGE_COLORS: Record<string, string> = {
    newcomer: colors.textMuted,
    reliable: colors.cyan,
    pro: colors.primary,
    elite: colors.warning,
    legend: colors.error,
  };

  const badgeColor = stats ? BADGE_COLORS[stats.badge_level] || colors.primary : colors.primary;

  const isApproved = verification?.approval_status === 'approved';
  const isPending = verification?.approval_status === 'pending';

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#080C14', '#0A1020']} style={StyleSheet.absoluteFillObject} />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Runner Dashboard</Text>
            <Text style={styles.subGreeting}>{profile?.full_name}</Text>
          </View>
          <View style={styles.headerRight}>
            {stats && (
              <View style={[styles.badgePill, { borderColor: badgeColor + '60', backgroundColor: badgeColor + '15' }]}>
                <Award color={badgeColor} size={12} />
                <Text style={[styles.badgeText, { color: badgeColor }]}>
                  {stats.badge_level.toUpperCase()}
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Verification banner */}
        {!verificationLoading && !isApproved && (
          <TouchableOpacity
            style={[styles.verificationBanner, isPending && styles.verificationBannerPending]}
            onPress={() => router.push('/runner/onboarding')}
            activeOpacity={0.85}
          >
            <Shield color={isPending ? colors.warning : colors.error} size={20} />
            <View style={{ flex: 1 }}>
              <Text style={[styles.verificationTitle, { color: isPending ? colors.warning : colors.error }]}>
                {isPending ? 'Verification Pending' : 'Complete Verification to Accept Jobs'}
              </Text>
              <Text style={styles.verificationDesc}>
                {isPending
                  ? 'Under review — check back in 24 hours'
                  : 'Upload your ID and bank info to start earning'}
              </Text>
            </View>
            <ChevronRight color={isPending ? colors.warning : colors.error} size={16} />
          </TouchableOpacity>
        )}

        {/* Online toggle */}
        <Animated.View style={onlineStyle}>
          <TouchableOpacity
            style={[styles.onlineToggle, isOnline && styles.onlineToggleActive]}
            onPress={toggleOnline}
            activeOpacity={0.85}
          >
            {isOnline && (
              <LinearGradient
                colors={[colors.primary + '20', colors.cyan + '10']}
                style={StyleSheet.absoluteFillObject}
              />
            )}
            <View style={styles.onlineLeft}>
              <View style={[styles.onlineIndicator, isOnline && styles.onlineIndicatorOn]} />
              <View>
                <Text style={[styles.onlineTitle, isOnline && styles.onlineTitleOn]}>
                  {isOnline ? 'You are ONLINE' : 'You are OFFLINE'}
                </Text>
                <Text style={styles.onlineDesc}>
                  {isOnline ? 'Receiving job requests' : 'Tap to start accepting jobs'}
                </Text>
              </View>
            </View>
            <View style={[styles.toggleSwitch, isOnline && styles.toggleSwitchOn]}>
              <View style={[styles.toggleThumb, isOnline && styles.toggleThumbOn]} />
            </View>
          </TouchableOpacity>
        </Animated.View>

        {/* Earnings cards */}
        <View style={styles.earningsRow}>
          <View style={styles.earningsCard}>
            <LinearGradient colors={['#001A12', '#0F1623']} style={StyleSheet.absoluteFillObject} />
            <Text style={styles.earningsLabel}>Today</Text>
            <Text style={styles.earningsAmount}>
              ${(stats?.earnings_today ?? 0).toFixed(2)}
            </Text>
            <TrendingUp color={colors.primary} size={16} />
          </View>
          <View style={styles.earningsCard}>
            <LinearGradient colors={['#001A20', '#0F1623']} style={StyleSheet.absoluteFillObject} />
            <Text style={styles.earningsLabel}>This Week</Text>
            <Text style={styles.earningsAmount}>
              ${(stats?.earnings_week ?? 0).toFixed(2)}
            </Text>
            <TrendingUp color={colors.cyan} size={16} />
          </View>
        </View>

        {/* Streak */}
        <View style={styles.streakCard}>
          <LinearGradient colors={['#1A0800', '#0F1623']} style={StyleSheet.absoluteFillObject} />
          <Flame color={colors.warning} size={24} />
          <View style={styles.streakMid}>
            <Text style={styles.streakTitle}>
              {stats?.streak_days ?? 0} day streak
            </Text>
            <Text style={styles.streakDesc}>
              {stats ? `${stats.total_runs} total runs • ${stats.completion_rate.toFixed(0)}% completion` : 'Start your streak today'}
            </Text>
          </View>
          <View style={styles.streakBars}>
            {Array.from({ length: 7 }).map((_, i) => (
              <View
                key={i}
                style={[styles.streakBar, i < (stats?.streak_days ?? 0) % 7 && styles.streakBarActive]}
              />
            ))}
          </View>
        </View>

        {/* Surge zone map */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Surge Zones</Text>
            <Text style={styles.sectionSub}>Higher pay nearby</Text>
          </View>
          <SurgeMapMock zones={surgeZones} />
          <View style={styles.surgeLegend}>
            {[
              { label: '2x+', color: colors.error },
              { label: '1.5–2x', color: colors.surge2 },
              { label: '1.2–1.5x', color: colors.surge1 },
            ].map(l => (
              <View key={l.label} style={styles.legendItem}>
                <View style={[styles.legendDot, { backgroundColor: l.color }]} />
                <Text style={styles.legendLabel}>{l.label}</Text>
              </View>
            ))}
          </View>
          {surgeZones.slice(0, 3).map(zone => (
            <View key={zone.id} style={styles.zoneRow}>
              <View style={[styles.zoneMultBadge, { backgroundColor: zone.multiplier >= 2 ? colors.error + '20' : colors.warning + '20' }]}>
                <Text style={[styles.zoneMultText, { color: zone.multiplier >= 2 ? colors.error : colors.warning }]}>
                  {zone.multiplier}x
                </Text>
              </View>
              <View style={styles.zoneMid}>
                <Text style={styles.zoneName}>{zone.area_name}</Text>
                <Text style={styles.zoneDesc}>{zone.active_requests} requests • {zone.available_runners} runners</Text>
              </View>
              <MapPin color={colors.textMuted} size={14} />
            </View>
          ))}
        </View>

        {/* Available jobs */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Available Jobs</Text>
            <Text style={styles.sectionSub}>{availableJobs.length} near you</Text>
          </View>
          {availableJobs.length === 0 ? (
            <View style={styles.emptyJobs}>
              <Text style={styles.emptyJobsText}>No jobs right now. Stay online!</Text>
            </View>
          ) : (
            availableJobs.map(errand => {
              const service = SERVICES.find(s => s.id === errand.service_type);
              const runnerPay = (errand.price * 0.85 + errand.tip) * errand.surge_multiplier;
              return (
                <View key={errand.id} style={styles.jobCard}>
                  <View style={styles.jobLeft}>
                    <Text style={styles.jobEmoji}>{service?.icon || '⚡'}</Text>
                  </View>
                  <View style={styles.jobMid}>
                    <Text style={styles.jobTitle}>{errand.title || service?.label}</Text>
                    <Text style={styles.jobAddr} numberOfLines={1}>{errand.delivery_address}</Text>
                    <View style={styles.jobMeta}>
                      <Clock color={colors.textMuted} size={11} />
                      <Text style={styles.jobMetaText}>~{service?.estimatedMinutes ?? 30}m</Text>
                      {errand.surge_multiplier > 1 && (
                        <View style={styles.surgeTag}>
                          <Zap color={colors.warning} size={10} fill={colors.warning} />
                          <Text style={styles.surgeTagText}>{errand.surge_multiplier}x</Text>
                        </View>
                      )}
                    </View>
                  </View>
                  <View style={styles.jobRight}>
                    <Text style={styles.jobPay}>${runnerPay.toFixed(2)}</Text>
                    <TouchableOpacity
                      style={styles.acceptBtn}
                      onPress={() => isApproved ? acceptJob(errand) : router.push('/runner/onboarding')}
                      disabled={!!loadingJob}
                    >
                      <LinearGradient
                        colors={isApproved && isOnline ? [colors.primary, colors.cyan] : [colors.surfaceHigh, colors.surfaceHigh]}
                        start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                        style={styles.acceptBtnGrad}
                      >
                        {loadingJob === errand.id ? (
                          <ActivityIndicator color={colors.background} size="small" />
                        ) : (
                          <Text style={[styles.acceptBtnText, (!isApproved || !isOnline) && { color: colors.textMuted }]}>
                            {!isApproved ? 'Verify' : isOnline ? 'Accept' : 'Go Online'}
                          </Text>
                        )}
                      </LinearGradient>
                    </TouchableOpacity>
                  </View>
                </View>
              );
            })
          )}
        </View>

        {/* Perks progress */}
        <View style={styles.perksCard}>
          <LinearGradient colors={['#001A12', '#0F1623']} style={StyleSheet.absoluteFillObject} />
          <Text style={styles.perksTitle}>Runner Perks Progress</Text>
          {[
            { label: 'Gas Card ($25)', goal: 50, current: stats?.total_runs ?? 0, icon: '⛽' },
            { label: 'Elite Badge', goal: 100, current: stats?.total_runs ?? 0, icon: '🏆' },
            { label: 'Health Plan Access', goal: 200, current: stats?.total_runs ?? 0, icon: '🏥' },
          ].map(perk => {
            const pct = Math.min(100, (perk.current / perk.goal) * 100);
            return (
              <View key={perk.label} style={styles.perkRow}>
                <Text style={styles.perkIcon}>{perk.icon}</Text>
                <View style={styles.perkMid}>
                  <View style={styles.perkNameRow}>
                    <Text style={styles.perkLabel}>{perk.label}</Text>
                    <Text style={styles.perkProgress}>{perk.current}/{perk.goal} runs</Text>
                  </View>
                  <View style={styles.perkBar}>
                    <View style={[styles.perkBarFill, { width: `${pct}%` as any }]} />
                  </View>
                </View>
              </View>
            );
          })}
        </View>

        <View style={{ height: 24 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { paddingTop: 56, paddingHorizontal: 16 },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16,
  },
  greeting: { fontSize: 22, fontWeight: '800', color: colors.text, marginBottom: 2 },
  subGreeting: { fontSize: 13, color: colors.textSecondary },
  headerRight: { alignItems: 'flex-end', gap: 6 },
  badgePill: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    borderRadius: 8, borderWidth: 1, paddingHorizontal: 8, paddingVertical: 4,
  },
  badgeText: { fontSize: 10, fontWeight: '800', letterSpacing: 0.5 },
  verificationBanner: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: colors.error + '15', borderWidth: 1.5, borderColor: colors.error + '50',
    borderRadius: 14, padding: 14, marginBottom: 14,
  },
  verificationBannerPending: {
    backgroundColor: colors.warning + '15', borderColor: colors.warning + '50',
  },
  verificationTitle: { fontSize: 13, fontWeight: '700', marginBottom: 2 },
  verificationDesc: { fontSize: 11, color: colors.textSecondary },
  onlineToggle: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: colors.surface, borderWidth: 1.5, borderColor: colors.border,
    borderRadius: 16, padding: 16, marginBottom: 16, overflow: 'hidden',
  },
  onlineToggleActive: { borderColor: colors.primary + '80' },
  onlineLeft: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  onlineIndicator: { width: 12, height: 12, borderRadius: 6, backgroundColor: colors.error },
  onlineIndicatorOn: { backgroundColor: colors.primary },
  onlineTitle: { fontSize: 15, fontWeight: '700', color: colors.textSecondary, marginBottom: 2 },
  onlineTitleOn: { color: colors.primary },
  onlineDesc: { fontSize: 12, color: colors.textMuted },
  toggleSwitch: {
    width: 48, height: 28, borderRadius: 14,
    backgroundColor: colors.surfaceHigh, justifyContent: 'center', padding: 3,
  },
  toggleSwitchOn: { backgroundColor: colors.primary },
  toggleThumb: { width: 22, height: 22, borderRadius: 11, backgroundColor: colors.textMuted },
  toggleThumbOn: { backgroundColor: colors.background, transform: [{ translateX: 20 }] },
  earningsRow: { flexDirection: 'row', gap: 12, marginBottom: 12 },
  earningsCard: {
    flex: 1, borderRadius: 14, padding: 16, gap: 4,
    borderWidth: 1, borderColor: colors.border, overflow: 'hidden',
  },
  earningsLabel: { fontSize: 12, color: colors.textSecondary },
  earningsAmount: { fontSize: 24, fontWeight: '800', color: colors.text },
  streakCard: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    borderRadius: 14, padding: 14, marginBottom: 16,
    borderWidth: 1, borderColor: colors.warning + '30', overflow: 'hidden',
  },
  streakMid: { flex: 1 },
  streakTitle: { fontSize: 15, fontWeight: '700', color: colors.text, marginBottom: 2 },
  streakDesc: { fontSize: 11, color: colors.textSecondary },
  streakBars: { flexDirection: 'row', gap: 3 },
  streakBar: { width: 8, height: 24, borderRadius: 4, backgroundColor: colors.surfaceHigh },
  streakBarActive: { backgroundColor: colors.warning },
  section: { marginBottom: 24 },
  sectionHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12,
  },
  sectionTitle: { fontSize: 17, fontWeight: '800', color: colors.text },
  sectionSub: { fontSize: 12, color: colors.textMuted },
  surgeLegend: { flexDirection: 'row', gap: 16, marginBottom: 12 },
  legendItem: { flexDirection: 'row', alignItems: 'center', gap: 5 },
  legendDot: { width: 8, height: 8, borderRadius: 4 },
  legendLabel: { fontSize: 11, color: colors.textSecondary },
  zoneRow: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: colors.surface, borderRadius: 10, padding: 10,
    borderWidth: 1, borderColor: colors.border, marginBottom: 6,
  },
  zoneMultBadge: { borderRadius: 6, paddingHorizontal: 8, paddingVertical: 4 },
  zoneMultText: { fontSize: 12, fontWeight: '800' },
  zoneMid: { flex: 1 },
  zoneName: { fontSize: 13, fontWeight: '600', color: colors.text },
  zoneDesc: { fontSize: 11, color: colors.textMuted },
  emptyJobs: {
    backgroundColor: colors.surface, borderRadius: 12, padding: 24, alignItems: 'center',
    borderWidth: 1, borderColor: colors.border,
  },
  emptyJobsText: { color: colors.textSecondary, fontSize: 14 },
  jobCard: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: colors.surface, borderRadius: 14, padding: 12,
    marginBottom: 8, borderWidth: 1, borderColor: colors.border,
  },
  jobLeft: {
    width: 44, height: 44, borderRadius: 12,
    backgroundColor: colors.surfaceElevated, alignItems: 'center', justifyContent: 'center',
  },
  jobEmoji: { fontSize: 20 },
  jobMid: { flex: 1 },
  jobTitle: { fontSize: 13, fontWeight: '700', color: colors.text, marginBottom: 2 },
  jobAddr: { fontSize: 11, color: colors.textSecondary, marginBottom: 4 },
  jobMeta: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  jobMetaText: { fontSize: 11, color: colors.textMuted },
  surgeTag: {
    flexDirection: 'row', alignItems: 'center', gap: 2,
    backgroundColor: colors.warning + '20', borderRadius: 4, paddingHorizontal: 4, paddingVertical: 2,
  },
  surgeTagText: { fontSize: 10, color: colors.warning, fontWeight: '700' },
  jobRight: { alignItems: 'flex-end', gap: 6 },
  jobPay: { fontSize: 15, fontWeight: '800', color: colors.primary },
  acceptBtn: { borderRadius: 8, overflow: 'hidden' },
  acceptBtnGrad: { paddingHorizontal: 12, paddingVertical: 6 },
  acceptBtnText: { fontSize: 12, fontWeight: '700', color: colors.background },
  perksCard: {
    borderRadius: 14, padding: 16, gap: 12,
    borderWidth: 1, borderColor: colors.primary + '20', overflow: 'hidden',
  },
  perksTitle: { fontSize: 15, fontWeight: '700', color: colors.text, marginBottom: 4 },
  perkRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  perkIcon: { fontSize: 20, width: 28 },
  perkMid: { flex: 1, gap: 4 },
  perkNameRow: { flexDirection: 'row', justifyContent: 'space-between' },
  perkLabel: { fontSize: 13, color: colors.text, fontWeight: '600' },
  perkProgress: { fontSize: 11, color: colors.textMuted },
  perkBar: {
    height: 6, backgroundColor: colors.surfaceHigh, borderRadius: 3, overflow: 'hidden',
  },
  perkBarFill: { height: '100%', backgroundColor: colors.primary, borderRadius: 3 },
});
