import { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Dimensions, ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { TrendingUp, Download, DollarSign, Zap, Clock } from 'lucide-react-native';
import Animated, {
  useSharedValue, useAnimatedStyle, withTiming, withDelay,
} from 'react-native-reanimated';
import { colors } from '@/lib/colors';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import type { Database } from '@/types/database';

type RunnerStats = Database['public']['Tables']['runner_stats']['Row'];
type EarningsRecord = Database['public']['Tables']['earnings_history']['Row'];

const { width } = Dimensions.get('window');

const MOCK_WEEKLY = [42, 78, 55, 91, 63, 110, 85];
const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
const maxVal = Math.max(...MOCK_WEEKLY);

function BarItem({ val, max, label, delay }: { val: number; max: number; label: string; delay: number }) {
  const h = (val / max) * 120;
  const barAnim = useSharedValue(0);
  useEffect(() => {
    barAnim.value = 0;
    barAnim.value = withDelay(delay, withTiming(1, { duration: 600 }));
  }, [val]);
  const barStyle = useAnimatedStyle(() => ({ height: barAnim.value * h }));
  return (
    <View style={chartStyles.barWrap}>
      <Animated.View style={[chartStyles.bar, barStyle]}>
        <LinearGradient colors={[colors.primary, colors.cyan]} style={StyleSheet.absoluteFillObject} />
      </Animated.View>
      <Text style={chartStyles.barLabel}>{label}</Text>
    </View>
  );
}

function BarChart({ period }: { period: string }) {
  const data = period === 'daily'
    ? [12, 8, 15, 0, 22, 18, 30, 12]
    : period === 'weekly'
    ? MOCK_WEEKLY
    : [320, 280, 410, 380, 520, 460, 390, 540, 480, 610, 570, 490];

  const labels = period === 'daily'
    ? ['6am', '8am', '10am', '12pm', '2pm', '4pm', '6pm', '8pm']
    : period === 'weekly'
    ? DAYS
    : ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  const max = Math.max(...data, 1);

  return (
    <View style={chartStyles.container}>
      <View style={chartStyles.bars}>
        {data.map((val, i) => (
          <BarItem key={`${period}-${i}`} val={val} max={max} label={labels[i]} delay={i * 60} />
        ))}
      </View>
    </View>
  );
}

const chartStyles = StyleSheet.create({
  container: { marginVertical: 8 },
  bars: { flexDirection: 'row', alignItems: 'flex-end', height: 130, gap: 4 },
  barWrap: { flex: 1, alignItems: 'center', gap: 6 },
  bar: { width: '100%', borderRadius: 4, minHeight: 4, overflow: 'hidden' },
  barLabel: { fontSize: 8, color: colors.textMuted },
});

export default function EarningsScreen() {
  const { profile } = useAuth();
  const [stats, setStats] = useState<RunnerStats | null>(null);
  const [history, setHistory] = useState<EarningsRecord[]>([]);
  const [period, setPeriod] = useState<'daily' | 'weekly' | 'monthly'>('weekly');
  const [cashingOut, setCashingOut] = useState(false);
  const [cashedOut, setCashedOut] = useState(false);

  useEffect(() => {
    if (!profile) return;
    supabase.from('runner_stats').select('*').eq('runner_id', profile.id).maybeSingle()
      .then(({ data }) => { if (data) setStats(data); });
    supabase.from('earnings_history').select('*').eq('runner_id', profile.id)
      .order('created_at', { ascending: false }).limit(20)
      .then(({ data }) => { if (data) setHistory(data); });
  }, [profile]);

  const handleCashOut = async () => {
    setCashingOut(true);
    await new Promise(r => setTimeout(r, 2000));
    setCashingOut(false);
    setCashedOut(true);
    setTimeout(() => setCashedOut(false), 3000);
  };

  const earningsForPeriod =
    period === 'daily' ? stats?.earnings_today ?? 0
    : period === 'weekly' ? stats?.earnings_week ?? 0
    : stats?.earnings_month ?? 0;

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#080C14', '#0A1020']} style={StyleSheet.absoluteFillObject} />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        <Text style={styles.title}>Earnings</Text>

        {/* Period selector */}
        <View style={styles.periodRow}>
          {(['daily', 'weekly', 'monthly'] as const).map(p => (
            <TouchableOpacity
              key={p}
              style={[styles.periodBtn, period === p && styles.periodBtnActive]}
              onPress={() => setPeriod(p)}
            >
              <Text style={[styles.periodText, period === p && styles.periodTextActive]}>
                {p.charAt(0).toUpperCase() + p.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Earnings total */}
        <View style={styles.earningsHero}>
          <LinearGradient colors={['#001A12', '#0F1623']} style={StyleSheet.absoluteFillObject} />
          <Text style={styles.earningsPeriodLabel}>
            {period === 'daily' ? "Today's" : period === 'weekly' ? "This Week's" : "This Month's"} Earnings
          </Text>
          <Text style={styles.earningsBig}>${earningsForPeriod.toFixed(2)}</Text>
          <View style={styles.earningsMiniRow}>
            <View style={styles.earningsMini}>
              <Text style={styles.earningsMiniLabel}>Total Runs</Text>
              <Text style={styles.earningsMiniValue}>{stats?.total_runs ?? 0}</Text>
            </View>
            <View style={styles.earningsMiniDivider} />
            <View style={styles.earningsMini}>
              <Text style={styles.earningsMiniLabel}>Completion</Text>
              <Text style={styles.earningsMiniValue}>{stats?.completion_rate.toFixed(0) ?? 100}%</Text>
            </View>
            <View style={styles.earningsMiniDivider} />
            <View style={styles.earningsMini}>
              <Text style={styles.earningsMiniLabel}>All Time</Text>
              <Text style={styles.earningsMiniValue}>${stats?.earnings_total.toFixed(0) ?? 0}</Text>
            </View>
          </View>
        </View>

        {/* Chart */}
        <View style={styles.chartCard}>
          <Text style={styles.chartTitle}>Earnings Breakdown</Text>
          <BarChart period={period} />
        </View>

        {/* Instant cashout */}
        <TouchableOpacity
          style={styles.cashOutBtn}
          onPress={handleCashOut}
          disabled={cashingOut || cashedOut}
          activeOpacity={0.85}
        >
          <LinearGradient
            colors={cashedOut ? [colors.success + '30', colors.success + '20'] : [colors.primary, colors.cyan]}
            start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
            style={styles.cashOutGrad}
          >
            {cashingOut ? (
              <ActivityIndicator color={colors.background} />
            ) : cashedOut ? (
              <>
                <Text style={[styles.cashOutText, { color: colors.success }]}>Payout Initiated!</Text>
                <Text style={[styles.cashOutSub, { color: colors.success }]}>Arrives in 1–2 business days</Text>
              </>
            ) : (
              <>
                <Download color={colors.background} size={20} />
                <View>
                  <Text style={styles.cashOutText}>Instant Cash Out</Text>
                  <Text style={styles.cashOutSub}>Transfer to bank • $0.50 fee</Text>
                </View>
              </>
            )}
          </LinearGradient>
        </TouchableOpacity>

        {/* Payout history */}
        <View style={styles.historySection}>
          <Text style={styles.historyTitle}>Payout History</Text>
          {history.length === 0 ? (
            <View style={styles.emptyHistory}>
              <DollarSign color={colors.textMuted} size={32} />
              <Text style={styles.emptyHistoryText}>Complete your first errand to see earnings</Text>
            </View>
          ) : (
            history.map(record => (
              <View key={record.id} style={styles.historyRow}>
                <View style={styles.historyIcon}>
                  {record.type === 'errand' ? (
                    <Zap color={colors.primary} size={16} />
                  ) : (
                    <TrendingUp color={colors.cyan} size={16} />
                  )}
                </View>
                <View style={styles.historyMid}>
                  <Text style={styles.historyDesc}>{record.description || 'Errand completed'}</Text>
                  <Text style={styles.historyTime}>
                    {new Date(record.created_at).toLocaleDateString()}
                  </Text>
                </View>
                <Text style={styles.historyAmt}>+${record.amount.toFixed(2)}</Text>
              </View>
            ))
          )}
        </View>

        <View style={{ height: 32 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { paddingTop: 56, paddingHorizontal: 16 },
  title: { fontSize: 26, fontWeight: '800', color: colors.text, marginBottom: 16 },
  periodRow: {
    flexDirection: 'row', backgroundColor: colors.surface,
    borderRadius: 12, padding: 4, marginBottom: 16,
    borderWidth: 1, borderColor: colors.border,
  },
  periodBtn: { flex: 1, paddingVertical: 8, borderRadius: 10, alignItems: 'center' },
  periodBtnActive: { backgroundColor: colors.primary + '20' },
  periodText: { fontSize: 13, fontWeight: '600', color: colors.textMuted },
  periodTextActive: { color: colors.primary },
  earningsHero: {
    borderRadius: 16, padding: 20, marginBottom: 14,
    borderWidth: 1, borderColor: colors.primary + '20', overflow: 'hidden', gap: 6,
  },
  earningsPeriodLabel: { fontSize: 13, color: colors.textSecondary },
  earningsBig: { fontSize: 44, fontWeight: '800', color: colors.text, letterSpacing: -1 },
  earningsMiniRow: {
    flexDirection: 'row', alignItems: 'center', marginTop: 8,
  },
  earningsMini: { flex: 1, alignItems: 'center' },
  earningsMiniLabel: { fontSize: 11, color: colors.textMuted, marginBottom: 2 },
  earningsMiniValue: { fontSize: 16, fontWeight: '700', color: colors.text },
  earningsMiniDivider: { width: 1, height: 32, backgroundColor: colors.border },
  chartCard: {
    backgroundColor: colors.surface, borderRadius: 16, padding: 16,
    borderWidth: 1, borderColor: colors.border, marginBottom: 14,
  },
  chartTitle: { fontSize: 14, fontWeight: '700', color: colors.text, marginBottom: 4 },
  cashOutBtn: { borderRadius: 16, overflow: 'hidden', marginBottom: 24 },
  cashOutGrad: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 18, paddingHorizontal: 20 },
  cashOutText: { fontSize: 16, fontWeight: '700', color: colors.background },
  cashOutSub: { fontSize: 12, color: colors.background + 'CC' },
  historySection: {},
  historyTitle: { fontSize: 17, fontWeight: '800', color: colors.text, marginBottom: 12 },
  emptyHistory: {
    backgroundColor: colors.surface, borderRadius: 12, padding: 32,
    alignItems: 'center', gap: 12, borderWidth: 1, borderColor: colors.border,
  },
  emptyHistoryText: { fontSize: 14, color: colors.textSecondary, textAlign: 'center' },
  historyRow: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: colors.surface, borderRadius: 12, padding: 12,
    marginBottom: 8, borderWidth: 1, borderColor: colors.border,
  },
  historyIcon: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: colors.surfaceElevated, alignItems: 'center', justifyContent: 'center',
  },
  historyMid: { flex: 1 },
  historyDesc: { fontSize: 13, fontWeight: '600', color: colors.text, marginBottom: 2 },
  historyTime: { fontSize: 11, color: colors.textMuted },
  historyAmt: { fontSize: 15, fontWeight: '700', color: colors.primary },
});
