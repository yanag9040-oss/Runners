import { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Switch,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { MapPin, CreditCard, Star, Settings, Bell, Shield, ChevronRight, LogOut, Award, Accessibility, Circle as HelpCircle } from 'lucide-react-native';
import { colors } from '@/lib/colors';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import type { Database } from '@/types/database';

type RunnerStats = Database['public']['Tables']['runner_stats']['Row'];

export default function ProfileScreen() {
  const { profile } = useAuth();
  const [accessibilityMode, setAccessibilityMode] = useState(profile?.accessibility_priority ?? false);
  const [runnerStats, setRunnerStats] = useState<RunnerStats | null>(null);

  useEffect(() => {
    if (profile?.user_type === 'runner') {
      supabase.from('runner_stats').select('*').eq('runner_id', profile.id).maybeSingle()
        .then(({ data }) => { if (data) setRunnerStats(data); });
    }
  }, [profile]);
  const [notifications, setNotifications] = useState(true);

  const handleLogout = async () => {
    await supabase.auth.signOut();
    router.replace('/(auth)/welcome');
  };

  const PLAN_COLORS: Record<string, string> = {
    free: colors.textMuted,
    plus: colors.cyan,
    elite: colors.warning,
  };
  const planColor = PLAN_COLORS[profile?.subscription_plan || 'free'] || colors.textMuted;

  const BADGE_COLORS: Record<string, string> = {
    newcomer: colors.textMuted,
    reliable: colors.cyan,
    pro: colors.primary,
    elite: colors.warning,
    legend: colors.error,
  };

  const menuSections = [
    {
      title: 'Account',
      items: [
        { icon: MapPin, label: 'Saved Addresses', onPress: () => {} },
        { icon: CreditCard, label: 'Payment Methods', onPress: () => {} },
        { icon: Star, label: 'Order History', onPress: () => router.push('/(tabs)/explore') },
        { icon: Award, label: 'My Ratings & Reviews', onPress: () => {} },
      ],
    },
    {
      title: 'Preferences',
      items: [
        {
          icon: Accessibility,
          label: 'Accessibility Priority Mode',
          onPress: () => {},
          toggle: true,
          value: accessibilityMode,
          onToggle: (v: boolean) => {
            setAccessibilityMode(v);
            if (profile) {
              supabase.from('profiles').update({ accessibility_priority: v }).eq('id', profile.id);
            }
          },
        },
        {
          icon: Bell,
          label: 'Push Notifications',
          onPress: () => {},
          toggle: true,
          value: notifications,
          onToggle: (v: boolean) => setNotifications(v),
        },
      ],
    },
    {
      title: 'Support',
      items: [
        { icon: HelpCircle, label: 'Help Center', onPress: () => {} },
        { icon: Shield, label: 'Privacy & Security', onPress: () => {} },
        { icon: Settings, label: 'App Settings', onPress: () => {} },
      ],
    },
  ];

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#080C14', '#0A1020']} style={StyleSheet.absoluteFillObject} />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* Profile card */}
        <View style={styles.profileCard}>
          <LinearGradient colors={['#001A12', '#0F1623']} style={StyleSheet.absoluteFillObject} />
          <View style={styles.avatarWrap}>
            <LinearGradient colors={[colors.primary, colors.cyan]} style={styles.avatar}>
              <Text style={styles.avatarText}>
                {profile?.full_name?.charAt(0)?.toUpperCase() || '?'}
              </Text>
            </LinearGradient>
          </View>
          <Text style={styles.profileName}>{profile?.full_name || 'User'}</Text>
          <Text style={styles.profileEmail}>{profile?.email}</Text>

          <View style={styles.profileMeta}>
            <View style={[styles.planBadge, { borderColor: planColor + '50', backgroundColor: planColor + '15' }]}>
              <Text style={[styles.planBadgeText, { color: planColor }]}>
                {(profile?.subscription_plan || 'free').toUpperCase()} PLAN
              </Text>
            </View>

            {profile?.user_type === 'runner' && (
              <View style={styles.ratingRow}>
                <Star color={colors.warning} size={14} fill={colors.warning} />
                <Text style={styles.ratingText}>{profile.rating.toFixed(1)}</Text>
                <Text style={styles.ratingCount}>({profile.total_ratings} reviews)</Text>
              </View>
            )}

            {profile?.user_type !== 'runner' && (
              <View style={styles.userTypeBadge}>
                <Text style={styles.userTypeText}>
                  {profile?.user_type === 'admin' ? '⚙️ Admin' : '🛒 Customer'}
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Stats row for runners */}
        {profile?.user_type === 'runner' && (
          <TouchableOpacity
            style={styles.runnerStatsCard}
            onPress={() => router.push('/(tabs)/earnings')}
          >
            <LinearGradient colors={['#001A12', '#0F1623']} style={StyleSheet.absoluteFillObject} />
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{profile.rating?.toFixed(1) ?? '5.0'}</Text>
              <Text style={styles.statLabel}>Rating</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={styles.statValue}>{runnerStats?.total_runs ?? 0}</Text>
              <Text style={styles.statLabel}>Total Runs</Text>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <Text style={[styles.statValue, { color: colors.primary }]}>
                ${runnerStats?.earnings_total?.toFixed(0) ?? '0'}
              </Text>
              <Text style={styles.statLabel}>Lifetime Earned</Text>
            </View>
          </TouchableOpacity>
        )}

        {/* Menu sections */}
        {menuSections.map(section => (
          <View key={section.title} style={styles.menuSection}>
            <Text style={styles.menuSectionTitle}>{section.title}</Text>
            <View style={styles.menuGroup}>
              {section.items.map((item, idx) => (
                <TouchableOpacity
                  key={item.label}
                  style={[
                    styles.menuItem,
                    idx < section.items.length - 1 && styles.menuItemBorder,
                  ]}
                  onPress={item.onPress}
                  activeOpacity={0.75}
                >
                  <View style={styles.menuItemLeft}>
                    <View style={styles.menuIcon}>
                      <item.icon color={colors.textSecondary} size={16} />
                    </View>
                    <Text style={styles.menuLabel}>{item.label}</Text>
                  </View>
                  {'toggle' in item && item.toggle ? (
                    <Switch
                      value={item.value}
                      onValueChange={item.onToggle}
                      trackColor={{ false: colors.surfaceHigh, true: colors.primary + '60' }}
                      thumbColor={item.value ? colors.primary : colors.textMuted}
                    />
                  ) : (
                    <ChevronRight color={colors.textMuted} size={16} />
                  )}
                </TouchableOpacity>
              ))}
            </View>
          </View>
        ))}

        {/* Logout */}
        <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout} activeOpacity={0.85}>
          <LogOut color={colors.error} size={18} />
          <Text style={styles.logoutText}>Sign Out</Text>
        </TouchableOpacity>

        <Text style={styles.version}>RunIt v1.0.0</Text>

        <View style={{ height: 32 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { paddingTop: 56, paddingHorizontal: 16 },
  profileCard: {
    borderRadius: 20, padding: 24, alignItems: 'center', marginBottom: 14,
    borderWidth: 1, borderColor: colors.primary + '20', overflow: 'hidden', gap: 8,
  },
  avatarWrap: { marginBottom: 4 },
  avatar: {
    width: 72, height: 72, borderRadius: 36,
    alignItems: 'center', justifyContent: 'center',
  },
  avatarText: { fontSize: 28, fontWeight: '800', color: colors.background },
  profileName: { fontSize: 22, fontWeight: '800', color: colors.text },
  profileEmail: { fontSize: 13, color: colors.textSecondary },
  profileMeta: { flexDirection: 'row', gap: 10, flexWrap: 'wrap', justifyContent: 'center', marginTop: 4 },
  planBadge: {
    borderRadius: 8, borderWidth: 1, paddingHorizontal: 10, paddingVertical: 4,
  },
  planBadgeText: { fontSize: 10, fontWeight: '800', letterSpacing: 0.5 },
  ratingRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  ratingText: { fontSize: 13, fontWeight: '700', color: colors.text },
  ratingCount: { fontSize: 12, color: colors.textSecondary },
  userTypeBadge: {
    backgroundColor: colors.surface, borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4,
    borderWidth: 1, borderColor: colors.border,
  },
  userTypeText: { fontSize: 12, color: colors.textSecondary },
  runnerStatsCard: {
    flexDirection: 'row', borderRadius: 14, padding: 16, marginBottom: 14,
    borderWidth: 1, borderColor: colors.primary + '20', overflow: 'hidden',
  },
  statItem: { flex: 1, alignItems: 'center' },
  statValue: { fontSize: 20, fontWeight: '800', color: colors.text, marginBottom: 2 },
  statLabel: { fontSize: 11, color: colors.textSecondary },
  statDivider: { width: 1, backgroundColor: colors.border, marginVertical: 4 },
  menuSection: { marginBottom: 20 },
  menuSectionTitle: { fontSize: 12, fontWeight: '700', color: colors.textMuted, marginBottom: 8, marginLeft: 4, letterSpacing: 0.5, textTransform: 'uppercase' },
  menuGroup: {
    backgroundColor: colors.surface, borderRadius: 14,
    borderWidth: 1, borderColor: colors.border, overflow: 'hidden',
  },
  menuItem: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 14, paddingVertical: 14,
  },
  menuItemBorder: { borderBottomWidth: 1, borderBottomColor: colors.border },
  menuItemLeft: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  menuIcon: {
    width: 32, height: 32, borderRadius: 8,
    backgroundColor: colors.surfaceElevated, alignItems: 'center', justifyContent: 'center',
  },
  menuLabel: { fontSize: 14, color: colors.text, fontWeight: '500' },
  logoutBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
    backgroundColor: colors.error + '15', borderWidth: 1, borderColor: colors.error + '30',
    borderRadius: 14, paddingVertical: 16, marginBottom: 16,
  },
  logoutText: { fontSize: 15, fontWeight: '700', color: colors.error },
  version: { fontSize: 11, color: colors.textMuted, textAlign: 'center' },
});
