import { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Check, Star, Zap, Shield, Users, Headphones } from 'lucide-react-native';
import { colors } from '@/lib/colors';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';

const PLANS = [
  {
    id: 'free',
    name: 'Free',
    price: 0,
    period: '',
    tagline: 'Get started',
    color: colors.textMuted,
    features: [
      'Up to 5 errands/month',
      'Standard matching',
      'Basic support',
      'Order history',
    ],
    missing: ['Priority matching', 'Free cancellations', 'Family sharing', 'Concierge service'],
  },
  {
    id: 'plus',
    name: 'Plus',
    price: 9.99,
    period: '/mo',
    tagline: 'Most popular',
    color: colors.cyan,
    popular: true,
    features: [
      'Unlimited errands',
      'Priority matching',
      'Free cancellations (3/mo)',
      '5% discount on all errands',
      'Dedicated support',
      'Order history & analytics',
    ],
    missing: ['Family sharing (up to 4)', 'Concierge service'],
  },
  {
    id: 'elite',
    name: 'Elite',
    price: 19.99,
    period: '/mo',
    tagline: 'Best value',
    color: colors.warning,
    features: [
      'Unlimited errands',
      'Priority matching + concierge',
      'Free cancellations (unlimited)',
      '10% discount on all errands',
      'Family sharing (up to 4)',
      '24/7 dedicated concierge',
      'Early access to new features',
      'Price match guarantee',
    ],
    missing: [],
  },
];

export default function SubscriptionsScreen() {
  const { profile, refetchProfile } = useAuth();
  const [loading, setLoading] = useState<string | null>(null);
  const [success, setSuccess] = useState('');

  const currentPlan = profile?.subscription_plan || 'free';

  const handleSubscribe = async (planId: string) => {
    if (!profile) return;
    if (planId === currentPlan) return;
    setLoading(planId);
    try {
      const { data: existing } = await supabase
        .from('subscriptions')
        .select('id')
        .eq('user_id', profile.id)
        .maybeSingle();

      if (existing) {
        await supabase.from('subscriptions').update({
          plan: planId as any,
          status: 'active',
          renews_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        }).eq('user_id', profile.id);
      } else {
        await supabase.from('subscriptions').insert({
          user_id: profile.id,
          plan: planId as any,
          status: 'active',
          renews_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        });
      }

      await supabase.from('profiles').update({ subscription_plan: planId as any }).eq('id', profile.id);
      await refetchProfile?.();
      setSuccess(`Upgraded to ${planId.charAt(0).toUpperCase() + planId.slice(1)}!`);
      setTimeout(() => setSuccess(''), 3000);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(null);
    }
  };

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#080C14', '#0A1020']} style={StyleSheet.absoluteFillObject} />

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        <Text style={styles.title}>Subscription Plans</Text>
        <Text style={styles.subtitle}>
          Upgrade for priority service, discounts & more
        </Text>

        {success ? (
          <View style={styles.successBanner}>
            <Text style={styles.successText}>🎉 {success}</Text>
          </View>
        ) : null}

        {PLANS.map(plan => {
          const isActive = currentPlan === plan.id;
          const isLoading = loading === plan.id;

          return (
            <View
              key={plan.id}
              style={[
                styles.planCard,
                isActive && styles.planCardActive,
                plan.id === 'elite' && styles.planCardElite,
                { borderColor: isActive ? plan.color : plan.popular ? plan.color + '40' : colors.border },
              ]}
            >
              {plan.id === 'elite' && (
                <LinearGradient
                  colors={['#1A1000', '#0F1623']}
                  style={StyleSheet.absoluteFillObject}
                />
              )}
              {plan.id === 'plus' && (
                <LinearGradient
                  colors={['#001218', '#0F1623']}
                  style={StyleSheet.absoluteFillObject}
                />
              )}

              {/* Popular badge */}
              {plan.popular && (
                <View style={[styles.popularBadge, { backgroundColor: plan.color + '20', borderColor: plan.color + '40' }]}>
                  <Star color={plan.color} size={10} fill={plan.color} />
                  <Text style={[styles.popularText, { color: plan.color }]}>MOST POPULAR</Text>
                </View>
              )}

              {/* Plan header */}
              <View style={styles.planHeader}>
                <View>
                  <Text style={[styles.planName, { color: plan.color }]}>{plan.name}</Text>
                  <Text style={styles.planTagline}>{plan.tagline}</Text>
                </View>
                <View style={styles.priceWrap}>
                  <Text style={styles.planPrice}>
                    {plan.price === 0 ? 'Free' : `$${plan.price}`}
                  </Text>
                  {plan.period ? <Text style={styles.planPeriod}>{plan.period}</Text> : null}
                </View>
              </View>

              {/* Features */}
              <View style={styles.featureList}>
                {plan.features.map(f => (
                  <View key={f} style={styles.featureRow}>
                    <Check color={plan.color} size={14} />
                    <Text style={styles.featureText}>{f}</Text>
                  </View>
                ))}
                {plan.missing?.map(f => (
                  <View key={f} style={styles.featureRow}>
                    <View style={styles.missingDash} />
                    <Text style={styles.missingText}>{f}</Text>
                  </View>
                ))}
              </View>

              {/* CTA */}
              <TouchableOpacity
                style={styles.ctaBtn}
                onPress={() => handleSubscribe(plan.id)}
                disabled={isActive || !!loading}
                activeOpacity={0.85}
              >
                <LinearGradient
                  colors={isActive
                    ? [plan.color + '30', plan.color + '20']
                    : plan.price === 0
                    ? [colors.surfaceHigh, colors.surfaceHigh]
                    : [plan.color, plan.id === 'plus' ? '#0094CC' : '#CC8800']}
                  start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }}
                  style={styles.ctaBtnGrad}
                >
                  {isLoading ? (
                    <ActivityIndicator color={isActive ? plan.color : colors.background} size="small" />
                  ) : (
                    <Text style={[styles.ctaText, { color: isActive ? plan.color : plan.price === 0 ? colors.textMuted : colors.background }]}>
                      {isActive ? '✓ Current Plan' : plan.price === 0 ? 'Downgrade to Free' : `Get ${plan.name}`}
                    </Text>
                  )}
                </LinearGradient>
              </TouchableOpacity>
            </View>
          );
        })}

        {/* Feature comparison */}
        <View style={styles.compareSection}>
          <Text style={styles.compareTitle}>Why upgrade?</Text>
          {[
            { icon: Zap, title: 'Priority Matching', desc: 'Get a runner 2x faster than free users' },
            { icon: Shield, title: 'Price Match Guarantee', desc: 'Find it cheaper? We match + 10% back' },
            { icon: Users, title: 'Family Sharing', desc: 'Share Elite plan with up to 4 family members' },
            { icon: Headphones, title: '24/7 Concierge', desc: 'Dedicated agent for complex requests' },
          ].map(f => (
            <View key={f.title} style={styles.compareRow}>
              <View style={styles.compareIcon}>
                <f.icon color={colors.primary} size={18} />
              </View>
              <View style={styles.compareMid}>
                <Text style={styles.compareFeatureTitle}>{f.title}</Text>
                <Text style={styles.compareFeatureDesc}>{f.desc}</Text>
              </View>
            </View>
          ))}
        </View>

        <View style={{ height: 32 }} />
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { paddingTop: 56, paddingHorizontal: 16 },
  title: { fontSize: 26, fontWeight: '800', color: colors.text, marginBottom: 8 },
  subtitle: { fontSize: 14, color: colors.textSecondary, marginBottom: 24 },
  successBanner: {
    backgroundColor: colors.primary + '20', borderRadius: 12, padding: 14,
    alignItems: 'center', marginBottom: 16,
    borderWidth: 1, borderColor: colors.primary + '40',
  },
  successText: { fontSize: 15, fontWeight: '700', color: colors.primary },
  planCard: {
    borderRadius: 20, padding: 20, marginBottom: 14,
    borderWidth: 1.5, overflow: 'hidden',
    backgroundColor: colors.surface,
  },
  planCardActive: {},
  planCardElite: {},
  popularBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    alignSelf: 'flex-start', borderRadius: 6, borderWidth: 1,
    paddingHorizontal: 8, paddingVertical: 3, marginBottom: 12,
  },
  popularText: { fontSize: 9, fontWeight: '800', letterSpacing: 0.5 },
  planHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16,
  },
  planName: { fontSize: 22, fontWeight: '800', marginBottom: 2 },
  planTagline: { fontSize: 12, color: colors.textSecondary },
  priceWrap: { alignItems: 'flex-end' },
  planPrice: { fontSize: 28, fontWeight: '800', color: colors.text },
  planPeriod: { fontSize: 13, color: colors.textSecondary },
  featureList: { gap: 8, marginBottom: 20 },
  featureRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  featureText: { fontSize: 13, color: colors.text, flex: 1 },
  missingDash: { width: 14, height: 2, backgroundColor: colors.border, marginLeft: 0 },
  missingText: { fontSize: 13, color: colors.textMuted, flex: 1 },
  ctaBtn: { borderRadius: 12, overflow: 'hidden' },
  ctaBtnGrad: { paddingVertical: 14, alignItems: 'center' },
  ctaText: { fontSize: 15, fontWeight: '700' },
  compareSection: { marginTop: 8 },
  compareTitle: { fontSize: 17, fontWeight: '800', color: colors.text, marginBottom: 14 },
  compareRow: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: colors.surface, borderRadius: 12, padding: 14,
    marginBottom: 8, borderWidth: 1, borderColor: colors.border,
  },
  compareIcon: {
    width: 40, height: 40, borderRadius: 12,
    backgroundColor: colors.primary + '15', alignItems: 'center', justifyContent: 'center',
  },
  compareMid: { flex: 1 },
  compareFeatureTitle: { fontSize: 14, fontWeight: '700', color: colors.text, marginBottom: 2 },
  compareFeatureDesc: { fontSize: 12, color: colors.textSecondary },
});
