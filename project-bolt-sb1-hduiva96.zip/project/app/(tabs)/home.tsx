import { useState, useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, Dimensions, Image,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Bell, Search, ChevronRight, Zap, Users, Star, Shield } from 'lucide-react-native';
import Animated, {
  useSharedValue, useAnimatedStyle, withTiming, withRepeat,
  withSequence, interpolateColor,
} from 'react-native-reanimated';
import { colors } from '@/lib/colors';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import { SERVICES } from '@/lib/services';
import type { Database } from '@/types/database';

type FlashDeal = Database['public']['Tables']['flash_deals']['Row'];

const { width } = Dimensions.get('window');

function useCountdown(expiresAt: string) {
  const [timeLeft, setTimeLeft] = useState('');
  useEffect(() => {
    const calc = () => {
      const diff = new Date(expiresAt).getTime() - Date.now();
      if (diff <= 0) { setTimeLeft('Expired'); return; }
      const h = Math.floor(diff / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      setTimeLeft(h > 0 ? `${h}h ${m}m` : `${m}m ${s}s`);
    };
    calc();
    const t = setInterval(calc, 1000);
    return () => clearInterval(t);
  }, [expiresAt]);
  return timeLeft;
}

function FlashDealCard({ deal }: { deal: FlashDeal }) {
  const countdown = useCountdown(deal.expires_at);
  const pulse = useSharedValue(1);
  const service = SERVICES.find(s => s.id === deal.service_type);

  useEffect(() => {
    pulse.value = withRepeat(withSequence(
      withTiming(1.03, { duration: 1200 }),
      withTiming(1, { duration: 1200 })
    ), -1, true);
  }, []);

  const pulseStyle = useAnimatedStyle(() => ({ transform: [{ scale: pulse.value }] }));

  return (
    <Animated.View style={[styles.flashCard, pulseStyle]}>
      <LinearGradient
        colors={['#1A0A00', '#0F1623']}
        style={StyleSheet.absoluteFillObject}
      />
      <View style={styles.flashCardInner}>
        <View style={styles.flashBadge}>
          <Zap color={colors.warning} size={10} fill={colors.warning} />
          <Text style={styles.flashBadgeText}>FLASH DEAL</Text>
        </View>
        <Text style={styles.flashEmoji}>{service?.icon || '⚡'}</Text>
        <Text style={styles.flashTitle}>{deal.title}</Text>
        <Text style={styles.flashDesc} numberOfLines={2}>{deal.description}</Text>
        <View style={styles.flashPriceRow}>
          {deal.original_price != null && (
            <Text style={styles.flashOriginal}>${deal.original_price.toFixed(0)}</Text>
          )}
          {deal.deal_price != null && (
            <Text style={styles.flashPrice}>
              {deal.deal_price === 0 ? 'FREE' : `$${deal.deal_price.toFixed(0)}`}
            </Text>
          )}
        </View>
        <View style={styles.flashCountdownRow}>
          <View style={styles.flashCountdownBadge}>
            <Text style={styles.flashCountdownText}>⏱ {countdown}</Text>
          </View>
          <Text style={styles.flashSpotsLeft}>
            {deal.max_redemptions - deal.current_redemptions} left
          </Text>
        </View>
      </View>
    </Animated.View>
  );
}

export default function HomeScreen() {
  const { profile } = useAuth();
  const [flashDeals, setFlashDeals] = useState<FlashDeal[]>([]);
  const [runnerCount, setRunnerCount] = useState(0);
  const [groupErrandOn, setGroupErrandOn] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const runnerCountAnim = useSharedValue(0);

  useEffect(() => {
    const now = new Date().toISOString();
    supabase
      .from('flash_deals')
      .select('*')
      .eq('active', true)
      .gt('expires_at', now)
      .order('expires_at', { ascending: true })
      .then(({ data }) => {
        if (data) {
          setFlashDeals(data.filter(d => d.current_redemptions < d.max_redemptions));
        }
      });

    // Count approved, online runners
    supabase
      .from('profiles')
      .select('id', { count: 'exact', head: true })
      .eq('user_type', 'runner')
      .eq('is_online', true)
      .then(({ count }) => {
        setRunnerCount(count ?? 0);
        runnerCountAnim.value = withTiming(1, { duration: 1500 });
      });
  }, []);

  const filteredServices = searchQuery
    ? SERVICES.filter(s =>
        s.label.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.description.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : SERVICES;

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#080C14', '#0A1020', '#080C14']}
        style={StyleSheet.absoluteFillObject}
      />
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
        {/* Header */}
        <View style={styles.header}>
          <View style={styles.headerLeft}>
            <Text style={styles.greeting}>
              Hey, {profile?.full_name?.split(' ')[0] || 'there'} 👋
            </Text>
            <View style={styles.locationRow}>
              <View style={styles.onlineDot} />
              <Text style={styles.locationText}>
                {runnerCount > 0 ? `${runnerCount} runner${runnerCount === 1 ? '' : 's'} online` : 'Finding runners...'}
              </Text>
            </View>
          </View>
          <View style={styles.headerRight}>
            <TouchableOpacity style={styles.iconBtn}>
              <Bell color={colors.textSecondary} size={22} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Search bar */}
        <View style={styles.searchBar}>
          <Search color={colors.textMuted} size={18} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search errands..."
            placeholderTextColor={colors.textMuted}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>

        {/* Group Errand Toggle */}
        <TouchableOpacity
          style={[styles.groupToggle, groupErrandOn && styles.groupToggleActive]}
          onPress={() => setGroupErrandOn(!groupErrandOn)}
          activeOpacity={0.85}
        >
          {groupErrandOn && (
            <LinearGradient
              colors={[colors.primary + '18', colors.cyan + '10']}
              style={StyleSheet.absoluteFillObject}
            />
          )}
          <View style={styles.groupToggleLeft}>
            <View style={[styles.groupIconWrap, groupErrandOn && styles.groupIconWrapActive]}>
              <Users color={groupErrandOn ? colors.primary : colors.textMuted} size={20} />
            </View>
            <View>
              <Text style={[styles.groupToggleTitle, groupErrandOn && styles.groupToggleTitleActive]}>
                Group Errand Mode
              </Text>
              <Text style={styles.groupToggleDesc}>
                Split delivery fee with neighbors going the same way
              </Text>
            </View>
          </View>
          <View style={[styles.toggleSwitch, groupErrandOn && styles.toggleSwitchActive]}>
            <View style={[styles.toggleThumb, groupErrandOn && styles.toggleThumbActive]} />
          </View>
        </TouchableOpacity>

        {/* Flash Deals */}
        {flashDeals.length > 0 && (
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <View style={styles.sectionTitleRow}>
                <Zap color={colors.warning} size={16} fill={colors.warning} />
                <Text style={styles.sectionTitle}>Flash Deals</Text>
              </View>
              <Text style={styles.sectionSubtitle}>Limited time only</Text>
            </View>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.flashRow}
            >
              {flashDeals.map(deal => (
                <TouchableOpacity
                  key={deal.id}
                  onPress={() => router.push({ pathname: '/errand/post', params: { serviceId: deal.service_type, dealId: deal.id } })}
                >
                  <FlashDealCard deal={deal} />
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        )}

        {/* Services Grid */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>What do you need?</Text>
            <Text style={styles.sectionSubtitle}>All services</Text>
          </View>
          <View style={styles.servicesGrid}>
            {filteredServices.map(service => (
              <TouchableOpacity
                key={service.id}
                style={styles.serviceCard}
                onPress={() => router.push({ pathname: '/errand/post', params: { serviceId: service.id } })}
                activeOpacity={0.75}
              >
                <LinearGradient
                  colors={[colors.surfaceElevated, colors.surface]}
                  style={styles.serviceGradient}
                >
                  <Text style={styles.serviceEmoji}>{service.icon}</Text>
                  <Text style={styles.serviceLabel}>{service.label}</Text>
                  <Text style={styles.servicePrice}>from ${service.basePrice}</Text>
                </LinearGradient>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Subscription upsell */}
        {profile?.subscription_plan === 'free' && (
          <TouchableOpacity
            style={styles.upsellBanner}
            onPress={() => router.push('/(tabs)/subscriptions')}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={['#001A12', '#001C1A']}
              style={StyleSheet.absoluteFillObject}
            />
            <View style={styles.upsellLeft}>
              <View style={styles.upsellBadge}>
                <Star color={colors.warning} size={12} fill={colors.warning} />
                <Text style={styles.upsellBadgeText}>PLUS</Text>
              </View>
              <Text style={styles.upsellTitle}>Unlock Priority Service</Text>
              <Text style={styles.upsellDesc}>
                Skip the queue, free cancellations & more. From $9.99/mo.
              </Text>
            </View>
            <ChevronRight color={colors.primary} size={20} />
          </TouchableOpacity>
        )}

        {/* Accessibility Mode */}
        <TouchableOpacity style={styles.accessBanner} activeOpacity={0.85}>
          <Shield color={colors.cyan} size={20} />
          <View style={styles.accessText}>
            <Text style={styles.accessTitle}>Accessibility Priority Mode</Text>
            <Text style={styles.accessDesc}>Seniors & disabled users get priority matching</Text>
          </View>
          <ChevronRight color={colors.textMuted} size={16} />
        </TouchableOpacity>

        <View style={styles.bottomPad} />
      </ScrollView>

      {/* FAB */}
      <TouchableOpacity
        style={styles.fab}
        onPress={() => router.push('/errand/post')}
        activeOpacity={0.85}
      >
        <LinearGradient
          colors={[colors.primary, colors.cyan]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.fabGradient}
        >
          <Text style={styles.fabText}>+ Post Errand</Text>
        </LinearGradient>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { paddingTop: 56, paddingHorizontal: 16 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 },
  headerLeft: { flex: 1 },
  headerRight: { flexDirection: 'row', gap: 8 },
  greeting: { fontSize: 22, fontWeight: '800', color: colors.text, marginBottom: 4 },
  locationRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  onlineDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: colors.primary },
  locationText: { fontSize: 13, color: colors.textSecondary },
  iconBtn: {
    width: 40, height: 40, borderRadius: 12,
    backgroundColor: colors.surface, borderWidth: 1,
    borderColor: colors.border, alignItems: 'center', justifyContent: 'center',
  },
  searchBar: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border,
    borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12, marginBottom: 12,
  },
  searchInput: { flex: 1, fontSize: 14, color: colors.text },
  groupToggle: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: colors.surface, borderWidth: 1.5, borderColor: colors.border,
    borderRadius: 16, padding: 14, marginBottom: 24, overflow: 'hidden',
  },
  groupToggleActive: { borderColor: colors.primary + '80' },
  groupToggleLeft: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 },
  groupIconWrap: {
    width: 40, height: 40, borderRadius: 12,
    backgroundColor: colors.surfaceElevated, alignItems: 'center', justifyContent: 'center',
  },
  groupIconWrapActive: { backgroundColor: colors.primary + '20' },
  groupToggleTitle: { fontSize: 14, fontWeight: '700', color: colors.textSecondary, marginBottom: 2 },
  groupToggleTitleActive: { color: colors.primary },
  groupToggleDesc: { fontSize: 11, color: colors.textMuted, maxWidth: 200 },
  toggleSwitch: {
    width: 44, height: 26, borderRadius: 13,
    backgroundColor: colors.surfaceHigh, justifyContent: 'center', padding: 3,
  },
  toggleSwitchActive: { backgroundColor: colors.primary },
  toggleThumb: {
    width: 20, height: 20, borderRadius: 10, backgroundColor: colors.textMuted,
  },
  toggleThumbActive: { backgroundColor: colors.background, transform: [{ translateX: 18 }] },
  section: { marginBottom: 28 },
  sectionHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14,
  },
  sectionTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  sectionTitle: { fontSize: 18, fontWeight: '800', color: colors.text },
  sectionSubtitle: { fontSize: 12, color: colors.textMuted },
  flashRow: { paddingRight: 16, gap: 12 },
  flashCard: {
    width: 180, borderRadius: 16, overflow: 'hidden',
    borderWidth: 1, borderColor: colors.border,
  },
  flashCardInner: { padding: 14 },
  flashBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: colors.warning + '20', borderRadius: 6,
    paddingHorizontal: 6, paddingVertical: 3, alignSelf: 'flex-start', marginBottom: 8,
  },
  flashBadgeText: { fontSize: 9, fontWeight: '800', color: colors.warning, letterSpacing: 0.5 },
  flashEmoji: { fontSize: 28, marginBottom: 6 },
  flashTitle: { fontSize: 13, fontWeight: '700', color: colors.text, marginBottom: 4 },
  flashDesc: { fontSize: 11, color: colors.textSecondary, lineHeight: 16, marginBottom: 8 },
  flashPriceRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 8 },
  flashOriginal: { fontSize: 12, color: colors.textMuted, textDecorationLine: 'line-through' },
  flashPrice: { fontSize: 16, fontWeight: '800', color: colors.primary },
  flashCountdownRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  flashCountdownBadge: {
    backgroundColor: colors.error + '20', borderRadius: 6, paddingHorizontal: 6, paddingVertical: 3,
  },
  flashCountdownText: { fontSize: 10, color: colors.error, fontWeight: '700' },
  flashSpotsLeft: { fontSize: 10, color: colors.textMuted },
  servicesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  serviceCard: {
    width: (width - 52) / 3,
    borderRadius: 14, overflow: 'hidden',
    borderWidth: 1, borderColor: colors.border,
  },
  serviceGradient: { padding: 14, alignItems: 'center', gap: 6 },
  serviceEmoji: { fontSize: 26 },
  serviceLabel: { fontSize: 11, fontWeight: '700', color: colors.text, textAlign: 'center' },
  servicePrice: { fontSize: 10, color: colors.textMuted },
  upsellBanner: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    borderRadius: 16, overflow: 'hidden', borderWidth: 1.5, borderColor: colors.primary + '40',
    padding: 16, marginBottom: 12,
  },
  upsellLeft: { flex: 1 },
  upsellBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: colors.warning + '20', borderRadius: 6,
    paddingHorizontal: 6, paddingVertical: 3, alignSelf: 'flex-start', marginBottom: 6,
  },
  upsellBadgeText: { fontSize: 9, fontWeight: '800', color: colors.warning },
  upsellTitle: { fontSize: 15, fontWeight: '700', color: colors.text, marginBottom: 3 },
  upsellDesc: { fontSize: 12, color: colors.textSecondary },
  accessBanner: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border,
    borderRadius: 14, padding: 14, marginBottom: 12,
  },
  accessText: { flex: 1 },
  accessTitle: { fontSize: 13, fontWeight: '700', color: colors.text, marginBottom: 2 },
  accessDesc: { fontSize: 11, color: colors.textSecondary },
  bottomPad: { height: 100 },
  fab: {
    position: 'absolute', bottom: 80, right: 16, left: 16,
    borderRadius: 16, overflow: 'hidden',
    shadowColor: colors.primary, shadowOpacity: 0.4, shadowRadius: 16, elevation: 8,
  },
  fabGradient: { paddingVertical: 16, alignItems: 'center' },
  fabText: { fontSize: 16, fontWeight: '700', color: colors.background },
});
