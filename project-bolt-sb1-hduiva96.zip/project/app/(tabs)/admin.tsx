import { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Users, Zap, DollarSign, TriangleAlert as AlertTriangle, CircleCheck as CheckCircle, Circle as XCircle, ChevronRight, TrendingUp, Shield } from 'lucide-react-native';
import { colors } from '@/lib/colors';
import { supabase } from '@/lib/supabase';
import type { Database } from '@/types/database';

type Profile = Database['public']['Tables']['profiles']['Row'];
type Errand = Database['public']['Tables']['errands']['Row'];

export default function AdminPanel() {
  const [users, setUsers] = useState<Profile[]>([]);
  const [errands, setErrands] = useState<Errand[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'errands' | 'disputes'>('overview');

  useEffect(() => {
    Promise.all([
      supabase.from('profiles').select('*').order('created_at', { ascending: false }).limit(20),
      supabase.from('errands').select('*').order('created_at', { ascending: false }).limit(20),
    ]).then(([usersRes, errandsRes]) => {
      if (usersRes.data) setUsers(usersRes.data);
      if (errandsRes.data) setErrands(errandsRes.data);
      setLoading(false);
    });
  }, []);

  const customers = users.filter(u => u.user_type === 'customer');
  const runners = users.filter(u => u.user_type === 'runner');
  const activeErrands = errands.filter(e => ['pending', 'accepted', 'pickup', 'en_route'].includes(e.status));
  const completedErrands = errands.filter(e => e.status === 'completed');
  const revenue = completedErrands.reduce((sum, e) => sum + e.service_fee, 0);

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#080C14', '#0A1020']} style={StyleSheet.absoluteFillObject} />

      <View style={styles.header}>
        <View style={styles.headerTitle}>
          <Shield color={colors.primary} size={20} />
          <Text style={styles.title}>Admin Panel</Text>
        </View>
        <View style={styles.adminBadge}>
          <Text style={styles.adminBadgeText}>ADMIN</Text>
        </View>
      </View>

      {/* Tab selector */}
      <ScrollView
        horizontal showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.tabRow}
      >
        {(['overview', 'users', 'errands', 'disputes'] as const).map(tab => (
          <TouchableOpacity
            key={tab}
            style={[styles.tabBtn, activeTab === tab && styles.tabBtnActive]}
            onPress={() => setActiveTab(tab)}
          >
            <Text style={[styles.tabText, activeTab === tab && styles.tabTextActive]}>
              {tab.charAt(0).toUpperCase() + tab.slice(1)}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator color={colors.primary} />
        </View>
      ) : (
        <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scroll}>
          {activeTab === 'overview' && (
            <>
              {/* Stat cards */}
              <View style={styles.statsGrid}>
                {[
                  { label: 'Total Users', value: users.length, icon: Users, color: colors.cyan },
                  { label: 'Active Errands', value: activeErrands.length, icon: Zap, color: colors.primary },
                  { label: 'Revenue', value: `$${revenue.toFixed(0)}`, icon: DollarSign, color: colors.success },
                  { label: 'Runners', value: runners.length, icon: TrendingUp, color: colors.warning },
                ].map(stat => (
                  <View key={stat.label} style={styles.statCard}>
                    <LinearGradient colors={['#0F1623', '#162030']} style={StyleSheet.absoluteFillObject} />
                    <stat.icon color={stat.color} size={20} />
                    <Text style={[styles.statValue, { color: stat.color }]}>{stat.value}</Text>
                    <Text style={styles.statLabel}>{stat.label}</Text>
                  </View>
                ))}
              </View>

              {/* Recent activity */}
              <Text style={styles.sectionTitle}>Recent Activity</Text>
              {errands.slice(0, 5).map(errand => (
                <View key={errand.id} style={styles.activityRow}>
                  <View style={[styles.activityDot, {
                    backgroundColor: errand.status === 'completed' ? colors.success :
                      errand.status === 'cancelled' ? colors.error : colors.warning,
                  }]} />
                  <Text style={styles.activityText} numberOfLines={1}>
                    {errand.service_type} errand — {errand.status}
                  </Text>
                  <Text style={styles.activityTime}>
                    {new Date(errand.created_at).toLocaleDateString()}
                  </Text>
                </View>
              ))}

              {/* Revenue breakdown */}
              <View style={styles.revenueCard}>
                <LinearGradient colors={['#001A12', '#0F1623']} style={StyleSheet.absoluteFillObject} />
                <Text style={styles.revTitle}>Revenue Breakdown</Text>
                <View style={styles.revRow}>
                  <Text style={styles.revLabel}>Service fees (15%)</Text>
                  <Text style={styles.revValue}>${revenue.toFixed(2)}</Text>
                </View>
                <View style={styles.revRow}>
                  <Text style={styles.revLabel}>Subscriptions</Text>
                  <Text style={styles.revValue}>$0.00</Text>
                </View>
                <View style={styles.revDivider} />
                <View style={styles.revRow}>
                  <Text style={[styles.revLabel, { color: colors.text, fontWeight: '700' }]}>Total</Text>
                  <Text style={[styles.revValue, { color: colors.primary, fontSize: 18 }]}>${revenue.toFixed(2)}</Text>
                </View>
              </View>
            </>
          )}

          {activeTab === 'users' && (
            <>
              <Text style={styles.sectionTitle}>All Users ({users.length})</Text>
              {users.map(user => (
                <View key={user.id} style={styles.userRow}>
                  <View style={[styles.userAvatar, {
                    backgroundColor: user.user_type === 'runner' ? colors.primary + '20'
                      : user.user_type === 'admin' ? colors.error + '20' : colors.cyan + '20',
                  }]}>
                    <Text style={styles.userAvatarText}>
                      {user.full_name?.charAt(0)?.toUpperCase() || '?'}
                    </Text>
                  </View>
                  <View style={styles.userMid}>
                    <Text style={styles.userName}>{user.full_name}</Text>
                    <Text style={styles.userEmail}>{user.email}</Text>
                    <View style={styles.userMeta}>
                      <View style={[styles.userTypePill, {
                        backgroundColor: user.user_type === 'runner' ? colors.primary + '15' : colors.cyan + '15',
                      }]}>
                        <Text style={[styles.userTypeText, {
                          color: user.user_type === 'runner' ? colors.primary : colors.cyan,
                        }]}>
                          {user.user_type.toUpperCase()}
                        </Text>
                      </View>
                      {user.is_online && (
                        <View style={styles.onlinePill}>
                          <View style={styles.onlineDot} />
                          <Text style={styles.onlineText}>Online</Text>
                        </View>
                      )}
                    </View>
                  </View>
                  <ChevronRight color={colors.textMuted} size={16} />
                </View>
              ))}
            </>
          )}

          {activeTab === 'errands' && (
            <>
              <Text style={styles.sectionTitle}>All Errands ({errands.length})</Text>
              {errands.map(errand => (
                <View key={errand.id} style={styles.errandAdminRow}>
                  <View style={styles.errandAdminLeft}>
                    <Text style={styles.errandType}>{errand.service_type}</Text>
                    <Text style={styles.errandAddr} numberOfLines={1}>{errand.delivery_address}</Text>
                    <Text style={styles.errandDate}>
                      {new Date(errand.created_at).toLocaleDateString()}
                    </Text>
                  </View>
                  <View style={styles.errandAdminRight}>
                    <Text style={styles.errandPrice}>${errand.price.toFixed(2)}</Text>
                    <View style={[styles.statusPill, {
                      backgroundColor: errand.status === 'completed' ? colors.success + '20'
                        : errand.status === 'cancelled' ? colors.error + '20' : colors.warning + '20',
                    }]}>
                      <Text style={[styles.statusPillText, {
                        color: errand.status === 'completed' ? colors.success
                          : errand.status === 'cancelled' ? colors.error : colors.warning,
                      }]}>
                        {errand.status}
                      </Text>
                    </View>
                  </View>
                </View>
              ))}
            </>
          )}

          {activeTab === 'disputes' && (
            <View style={styles.disputesEmpty}>
              <AlertTriangle color={colors.warning} size={40} />
              <Text style={styles.disputesTitle}>No Active Disputes</Text>
              <Text style={styles.disputesDesc}>All disputes will appear here for review and resolution.</Text>
            </View>
          )}

          <View style={{ height: 32 }} />
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingTop: 56, paddingHorizontal: 16, paddingBottom: 12,
  },
  headerTitle: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  title: { fontSize: 22, fontWeight: '800', color: colors.text },
  adminBadge: {
    backgroundColor: colors.error + '20', borderRadius: 6,
    paddingHorizontal: 8, paddingVertical: 3, borderWidth: 1, borderColor: colors.error + '40',
  },
  adminBadgeText: { fontSize: 9, fontWeight: '800', color: colors.error, letterSpacing: 0.5 },
  tabRow: { paddingHorizontal: 16, gap: 8, paddingBottom: 12 },
  tabBtn: {
    paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20,
    backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border,
  },
  tabBtnActive: { backgroundColor: colors.primary + '20', borderColor: colors.primary },
  tabText: { fontSize: 13, fontWeight: '600', color: colors.textMuted },
  tabTextActive: { color: colors.primary },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  scroll: { paddingHorizontal: 16 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 20 },
  statCard: {
    width: '47%', borderRadius: 14, padding: 14, gap: 4,
    borderWidth: 1, borderColor: colors.border, overflow: 'hidden',
  },
  statValue: { fontSize: 26, fontWeight: '800' },
  statLabel: { fontSize: 11, color: colors.textSecondary },
  sectionTitle: { fontSize: 17, fontWeight: '800', color: colors.text, marginBottom: 12 },
  activityRow: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    backgroundColor: colors.surface, borderRadius: 10, padding: 10,
    marginBottom: 6, borderWidth: 1, borderColor: colors.border,
  },
  activityDot: { width: 8, height: 8, borderRadius: 4 },
  activityText: { flex: 1, fontSize: 13, color: colors.text },
  activityTime: { fontSize: 11, color: colors.textMuted },
  revenueCard: {
    borderRadius: 14, padding: 16, marginTop: 16,
    borderWidth: 1, borderColor: colors.primary + '20', overflow: 'hidden', gap: 8,
  },
  revTitle: { fontSize: 15, fontWeight: '700', color: colors.text, marginBottom: 4 },
  revRow: { flexDirection: 'row', justifyContent: 'space-between' },
  revLabel: { fontSize: 13, color: colors.textSecondary },
  revValue: { fontSize: 13, fontWeight: '600', color: colors.text },
  revDivider: { height: 1, backgroundColor: colors.border },
  userRow: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: colors.surface, borderRadius: 12, padding: 12,
    marginBottom: 8, borderWidth: 1, borderColor: colors.border,
  },
  userAvatar: {
    width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center',
  },
  userAvatarText: { fontSize: 16, fontWeight: '700', color: colors.text },
  userMid: { flex: 1 },
  userName: { fontSize: 14, fontWeight: '700', color: colors.text, marginBottom: 2 },
  userEmail: { fontSize: 11, color: colors.textSecondary, marginBottom: 4 },
  userMeta: { flexDirection: 'row', gap: 6 },
  userTypePill: { borderRadius: 4, paddingHorizontal: 6, paddingVertical: 2 },
  userTypeText: { fontSize: 9, fontWeight: '800', letterSpacing: 0.5 },
  onlinePill: { flexDirection: 'row', alignItems: 'center', gap: 3 },
  onlineDot: { width: 5, height: 5, borderRadius: 2.5, backgroundColor: colors.primary },
  onlineText: { fontSize: 10, color: colors.primary },
  errandAdminRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    backgroundColor: colors.surface, borderRadius: 12, padding: 12,
    marginBottom: 8, borderWidth: 1, borderColor: colors.border,
  },
  errandAdminLeft: { flex: 1 },
  errandType: { fontSize: 13, fontWeight: '700', color: colors.text, marginBottom: 2, textTransform: 'capitalize' },
  errandAddr: { fontSize: 11, color: colors.textSecondary, marginBottom: 3 },
  errandDate: { fontSize: 10, color: colors.textMuted },
  errandAdminRight: { alignItems: 'flex-end', gap: 4 },
  errandPrice: { fontSize: 14, fontWeight: '700', color: colors.text },
  statusPill: { borderRadius: 4, paddingHorizontal: 6, paddingVertical: 2 },
  statusPillText: { fontSize: 9, fontWeight: '700', textTransform: 'capitalize' },
  disputesEmpty: {
    flex: 1, alignItems: 'center', justifyContent: 'center',
    paddingTop: 80, gap: 12,
  },
  disputesTitle: { fontSize: 18, fontWeight: '700', color: colors.text },
  disputesDesc: { fontSize: 13, color: colors.textSecondary, textAlign: 'center', maxWidth: 280 },
});
