import { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { ChevronRight, Clock, CircleCheck as CheckCircle, Circle as XCircle, Loader } from 'lucide-react-native';
import { colors } from '@/lib/colors';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/useAuth';
import { SERVICES } from '@/lib/services';
import type { Database } from '@/types/database';

type Errand = Database['public']['Tables']['errands']['Row'];

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: any }> = {
  pending: { label: 'Finding Runner', color: colors.warning, icon: Loader },
  accepted: { label: 'Accepted', color: colors.cyan, icon: Clock },
  pickup: { label: 'Pickup', color: colors.cyan, icon: Clock },
  en_route: { label: 'On the way', color: colors.primary, icon: Clock },
  arrived: { label: 'Arrived', color: colors.primary, icon: CheckCircle },
  completed: { label: 'Completed', color: colors.success, icon: CheckCircle },
  cancelled: { label: 'Cancelled', color: colors.error, icon: XCircle },
};

export default function ExploreScreen() {
  const { profile } = useAuth();
  const [errands, setErrands] = useState<Errand[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'active' | 'past'>('active');

  useEffect(() => {
    if (!profile) return;
    setLoading(true);
    const q = supabase
      .from('errands')
      .select('*')
      .eq('customer_id', profile.id)
      .order('created_at', { ascending: false });

    if (filter === 'active') {
      q.in('status', ['pending', 'accepted', 'pickup', 'en_route', 'arrived']);
    } else {
      q.in('status', ['completed', 'cancelled']);
    }

    q.then(({ data }) => {
      if (data) setErrands(data);
      setLoading(false);
    });
  }, [profile, filter]);

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#080C14', '#0A1020']} style={StyleSheet.absoluteFillObject} />
      <View style={styles.headerArea}>
        <Text style={styles.title}>My Errands</Text>
        <View style={styles.filterRow}>
          {(['active', 'past'] as const).map(f => (
            <TouchableOpacity
              key={f}
              style={[styles.filterBtn, filter === f && styles.filterBtnActive]}
              onPress={() => setFilter(f)}
            >
              <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>
                {f === 'active' ? 'Active' : 'Past'}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {loading ? (
        <View style={styles.center}>
          <ActivityIndicator color={colors.primary} />
        </View>
      ) : errands.length === 0 ? (
        <View style={styles.center}>
          <Text style={styles.emptyEmoji}>📭</Text>
          <Text style={styles.emptyTitle}>No errands {filter === 'active' ? 'active' : 'yet'}</Text>
          <Text style={styles.emptyDesc}>Post your first errand and get it done fast.</Text>
          <TouchableOpacity
            style={styles.emptyBtn}
            onPress={() => router.push('/errand/post')}
          >
            <LinearGradient colors={[colors.primary, colors.cyan]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.emptyBtnGrad}>
              <Text style={styles.emptyBtnText}>Post an Errand</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView contentContainerStyle={styles.list} showsVerticalScrollIndicator={false}>
          {errands.map(errand => {
            const service = SERVICES.find(s => s.id === errand.service_type);
            const statusCfg = STATUS_CONFIG[errand.status] || STATUS_CONFIG.pending;
            const StatusIcon = statusCfg.icon;
            return (
              <TouchableOpacity
                key={errand.id}
                style={styles.errandCard}
                onPress={() => router.push({ pathname: '/errand/[id]', params: { id: errand.id } })}
                activeOpacity={0.85}
              >
                <View style={styles.cardLeft}>
                  <Text style={styles.cardEmoji}>{service?.icon || '⚡'}</Text>
                </View>
                <View style={styles.cardMid}>
                  <Text style={styles.cardTitle}>{errand.title || service?.label}</Text>
                  <Text style={styles.cardAddr} numberOfLines={1}>{errand.delivery_address}</Text>
                  <View style={styles.statusRow}>
                    <StatusIcon color={statusCfg.color} size={12} />
                    <Text style={[styles.statusText, { color: statusCfg.color }]}>{statusCfg.label}</Text>
                  </View>
                </View>
                <View style={styles.cardRight}>
                  <Text style={styles.cardPrice}>${errand.price.toFixed(2)}</Text>
                  <ChevronRight color={colors.textMuted} size={16} />
                </View>
              </TouchableOpacity>
            );
          })}
          <View style={{ height: 24 }} />
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  headerArea: { paddingTop: 56, paddingHorizontal: 16, paddingBottom: 12 },
  title: { fontSize: 26, fontWeight: '800', color: colors.text, marginBottom: 14 },
  filterRow: { flexDirection: 'row', gap: 8 },
  filterBtn: {
    paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20,
    backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border,
  },
  filterBtnActive: { backgroundColor: colors.primary + '20', borderColor: colors.primary },
  filterText: { fontSize: 13, fontWeight: '600', color: colors.textMuted },
  filterTextActive: { color: colors.primary },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32 },
  emptyEmoji: { fontSize: 48, marginBottom: 16 },
  emptyTitle: { fontSize: 20, fontWeight: '700', color: colors.text, marginBottom: 8 },
  emptyDesc: { fontSize: 14, color: colors.textSecondary, textAlign: 'center', marginBottom: 24 },
  emptyBtn: { borderRadius: 12, overflow: 'hidden' },
  emptyBtnGrad: { paddingHorizontal: 24, paddingVertical: 14 },
  emptyBtnText: { fontSize: 15, fontWeight: '700', color: colors.background },
  list: { paddingHorizontal: 16, paddingTop: 8 },
  errandCard: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    backgroundColor: colors.surface, borderRadius: 14, padding: 14,
    marginBottom: 10, borderWidth: 1, borderColor: colors.border,
  },
  cardLeft: {
    width: 44, height: 44, borderRadius: 12,
    backgroundColor: colors.surfaceElevated, alignItems: 'center', justifyContent: 'center',
  },
  cardEmoji: { fontSize: 20 },
  cardMid: { flex: 1 },
  cardTitle: { fontSize: 14, fontWeight: '700', color: colors.text, marginBottom: 3 },
  cardAddr: { fontSize: 12, color: colors.textSecondary, marginBottom: 5 },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  statusText: { fontSize: 12, fontWeight: '600' },
  cardRight: { alignItems: 'flex-end', gap: 4 },
  cardPrice: { fontSize: 15, fontWeight: '700', color: colors.text },
});
