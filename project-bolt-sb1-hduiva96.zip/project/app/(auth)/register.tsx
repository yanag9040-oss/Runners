import { useState } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, TextInput,
  ScrollView, KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { ChevronLeft, User, Zap } from 'lucide-react-native';
import { colors } from '@/lib/colors';
import { signUp } from '@/lib/auth';
import type { UserType } from '@/types/database';

export default function RegisterScreen() {
  const [userType, setUserType] = useState<UserType>('customer');
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleRegister = async () => {
    if (!fullName.trim() || !email.trim() || !password.trim()) {
      setError('Please fill in all fields');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters');
      return;
    }
    setLoading(true);
    setError('');
    try {
      await signUp(email.trim(), password, fullName.trim(), userType);
    } catch (e: any) {
      setError(e.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <LinearGradient colors={['#080C14', '#0A1020']} style={StyleSheet.absoluteFillObject} />

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <TouchableOpacity style={styles.back} onPress={() => router.back()}>
          <ChevronLeft color={colors.textSecondary} size={24} />
        </TouchableOpacity>

        <Text style={styles.title}>Create account</Text>
        <Text style={styles.subtitle}>Join thousands of people using RunIt</Text>

        {/* User type selector */}
        <View style={styles.typeContainer}>
          <TouchableOpacity
            style={[styles.typeCard, userType === 'customer' && styles.typeCardActive]}
            onPress={() => setUserType('customer')}
            activeOpacity={0.85}
          >
            {userType === 'customer' && (
              <LinearGradient
                colors={[colors.primary + '20', colors.cyan + '10']}
                style={StyleSheet.absoluteFillObject}
              />
            )}
            <User
              color={userType === 'customer' ? colors.primary : colors.textMuted}
              size={28}
            />
            <Text style={[styles.typeLabel, userType === 'customer' && styles.typeLabelActive]}>
              Customer
            </Text>
            <Text style={styles.typeDesc}>Post errands & get help</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.typeCard, userType === 'runner' && styles.typeCardActive]}
            onPress={() => setUserType('runner')}
            activeOpacity={0.85}
          >
            {userType === 'runner' && (
              <LinearGradient
                colors={[colors.primary + '20', colors.cyan + '10']}
                style={StyleSheet.absoluteFillObject}
              />
            )}
            <Zap
              color={userType === 'runner' ? colors.primary : colors.textMuted}
              size={28}
            />
            <Text style={[styles.typeLabel, userType === 'runner' && styles.typeLabelActive]}>
              Runner
            </Text>
            <Text style={styles.typeDesc}>Earn money completing jobs</Text>
          </TouchableOpacity>
        </View>

        {/* Form */}
        <View style={styles.form}>
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Full Name</Text>
            <TextInput
              style={styles.input}
              placeholder="Jane Doe"
              placeholderTextColor={colors.textMuted}
              value={fullName}
              onChangeText={setFullName}
              autoCapitalize="words"
            />
          </View>
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Email Address</Text>
            <TextInput
              style={styles.input}
              placeholder="jane@example.com"
              placeholderTextColor={colors.textMuted}
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
            />
          </View>
          <View style={styles.inputGroup}>
            <Text style={styles.inputLabel}>Password</Text>
            <TextInput
              style={styles.input}
              placeholder="At least 6 characters"
              placeholderTextColor={colors.textMuted}
              value={password}
              onChangeText={setPassword}
              secureTextEntry
            />
          </View>

          {error ? <Text style={styles.error}>{error}</Text> : null}

          <TouchableOpacity
            style={styles.submitButton}
            onPress={handleRegister}
            disabled={loading}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={[colors.primary, colors.cyan]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.gradientButton}
            >
              {loading ? (
                <ActivityIndicator color={colors.background} />
              ) : (
                <Text style={styles.submitText}>Create Account</Text>
              )}
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => router.push('/(auth)/login')} style={styles.loginLink}>
            <Text style={styles.loginLinkText}>
              Already have an account?{' '}
              <Text style={styles.loginLinkBold}>Sign in</Text>
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background },
  scroll: { paddingHorizontal: 24, paddingTop: 60, paddingBottom: 40 },
  back: { marginBottom: 32, width: 40 },
  title: { fontSize: 32, fontWeight: '800', color: colors.text, marginBottom: 8, letterSpacing: -0.5 },
  subtitle: { fontSize: 15, color: colors.textSecondary, marginBottom: 32 },
  typeContainer: { flexDirection: 'row', gap: 12, marginBottom: 32 },
  typeCard: {
    flex: 1,
    backgroundColor: colors.surface,
    borderRadius: 16,
    padding: 20,
    alignItems: 'center',
    gap: 8,
    borderWidth: 1.5,
    borderColor: colors.border,
    overflow: 'hidden',
  },
  typeCardActive: { borderColor: colors.primary },
  typeLabel: { fontSize: 16, fontWeight: '700', color: colors.textSecondary },
  typeLabelActive: { color: colors.primary },
  typeDesc: { fontSize: 11, color: colors.textMuted, textAlign: 'center' },
  form: { gap: 16 },
  inputGroup: { gap: 6 },
  inputLabel: { fontSize: 13, color: colors.textSecondary, fontWeight: '600', marginLeft: 4 },
  input: {
    backgroundColor: colors.surface,
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 14,
    fontSize: 15,
    color: colors.text,
  },
  error: { color: colors.error, fontSize: 13, textAlign: 'center', marginTop: 4 },
  submitButton: { borderRadius: 14, overflow: 'hidden', marginTop: 8 },
  gradientButton: { paddingVertical: 18, alignItems: 'center' },
  submitText: { fontSize: 16, fontWeight: '700', color: colors.background },
  loginLink: { alignItems: 'center', paddingVertical: 8 },
  loginLinkText: { fontSize: 14, color: colors.textSecondary },
  loginLinkBold: { color: colors.primary, fontWeight: '700' },
});
