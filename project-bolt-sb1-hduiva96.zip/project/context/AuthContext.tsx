// This file is kept for compatibility but auth logic lives in hooks/useAuth.ts
export {};
