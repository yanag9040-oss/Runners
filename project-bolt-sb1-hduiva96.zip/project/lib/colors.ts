export const colors = {
  primary: '#00F5A0',
  cyan: '#00D4FF',
  background: '#080C14',
  surface: '#0F1623',
  surfaceElevated: '#162030',
  surfaceHigh: '#1C2A3E',
  border: '#1E2D42',
  borderLight: '#253650',
  text: '#FFFFFF',
  textSecondary: '#8A9BB5',
  textMuted: '#4A5A72',
  success: '#00F5A0',
  warning: '#FFB800',
  error: '#FF4444',
  surge1: '#FFD700',
  surge2: '#FF8C00',
  surge3: '#FF4444',
  badge: {
    newcomer: '#8A9BB5',
    reliable: '#00D4FF',
    pro: '#00F5A0',
    elite: '#FFB800',
    legend: '#FF4444',
  },
  plan: {
    free: '#4A5A72',
    plus: '#00D4FF',
    elite: '#FFB800',
  },
} as const;

export const gradients = {
  primary: ['#00F5A0', '#00D4FF'] as const,
  card: ['#0F1623', '#162030'] as const,
  surge: ['#FF4444', '#FF8C00'] as const,
  dark: ['#080C14', '#0F1623'] as const,
} as const;
