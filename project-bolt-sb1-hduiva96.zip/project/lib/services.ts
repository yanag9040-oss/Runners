export interface Service {
  id: string;
  label: string;
  icon: string;
  basePrice: number;
  estimatedMinutes: number;
  description: string;
  category: 'health' | 'home' | 'transport' | 'care' | 'misc';
}

export const SERVICES: Service[] = [
  { id: 'prescriptions', label: 'Prescriptions', icon: '💊', basePrice: 12, estimatedMinutes: 30, description: 'Pickup & deliver your medications', category: 'health' },
  { id: 'groceries', label: 'Groceries', icon: '🛒', basePrice: 18, estimatedMinutes: 45, description: 'Full grocery runs from any store', category: 'home' },
  { id: 'dog_walking', label: 'Dog Walking', icon: '🐕', basePrice: 20, estimatedMinutes: 60, description: '30-60 minute walks for your pup', category: 'care' },
  { id: 'pet_sitting', label: 'Pet Sitting', icon: '🐾', basePrice: 35, estimatedMinutes: 120, description: 'In-home pet care while you\'re out', category: 'care' },
  { id: 'car_care', label: 'Car Care', icon: '🚗', basePrice: 25, estimatedMinutes: 60, description: 'Gas, carwash, minor maintenance', category: 'transport' },
  { id: 'post_office', label: 'Post Office', icon: '📦', basePrice: 10, estimatedMinutes: 30, description: 'Shipping, returns, notary services', category: 'misc' },
  { id: 'catering', label: 'Catering', icon: '🍱', basePrice: 45, estimatedMinutes: 45, description: 'Food pickups for events & offices', category: 'home' },
  { id: 'handyman', label: 'Handyman', icon: '🔧', basePrice: 50, estimatedMinutes: 90, description: 'Small repairs & home jobs', category: 'home' },
  { id: 'laundry', label: 'Laundry', icon: '👕', basePrice: 30, estimatedMinutes: 180, description: 'Pickup, wash, fold & return', category: 'home' },
  { id: 'childcare', label: 'Child Care', icon: '👶', basePrice: 40, estimatedMinutes: 120, description: 'Vetted sitters & nannies', category: 'care' },
  { id: 'tutoring', label: 'Tutoring', icon: '📚', basePrice: 35, estimatedMinutes: 60, description: 'Academic help for all ages', category: 'care' },
  { id: 'flash_errand', label: 'Flash Errand', icon: '⚡', basePrice: 15, estimatedMinutes: 20, description: 'Anything else — you name it', category: 'misc' },
];

export function getService(id: string): Service | undefined {
  return SERVICES.find((s) => s.id === id);
}

export function calculateTotal(basePrice: number, tip: number, surgeMultiplier: number = 1.0) {
  const surgedBase = basePrice * surgeMultiplier;
  const serviceFee = surgedBase * 0.15;
  const total = surgedBase + serviceFee + tip;
  return { surgedBase, serviceFee, total };
}
