import { supabase } from './supabase';
import type { UserType } from '@/types/database';

export async function signUp(email: string, password: string, fullName: string, userType: UserType) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: { full_name: fullName, user_type: userType },
    },
  });
  if (error) throw error;
  if (!data.user) throw new Error('No user returned');

  // Upsert profile in case trigger already ran or needs update
  const { error: profileError } = await supabase.from('profiles').upsert({
    id: data.user.id,
    email,
    full_name: fullName,
    user_type: userType,
  }, { onConflict: 'id' });
  if (profileError) throw profileError;

  if (userType === 'runner') {
    await supabase.from('runner_stats').upsert({ runner_id: data.user.id }, { onConflict: 'runner_id' });
  }

  return data;
}

export async function signIn(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function getProfile(userId: string) {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();
  if (error) throw error;
  return data;
}
