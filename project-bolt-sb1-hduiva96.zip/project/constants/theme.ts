export const colors = {
  // Primary brand
  green: '#00F5A0',
  cyan: '#00D4FF',
  greenDim: '#00C580',
  cyanDim: '#00A8CC',

  // Backgrounds
  bg: '#080C12',
  bgCard: '#0F1520',
  bgCardLight: '#161F2E',
  bgInput: '#111827',
  bgModal: '#0C1422',

  // Borders
  border: '#1E2A3E',
  borderLight: '#253347',

  // Text
  textPrimary: '#F0F4FF',
  textSecondary: '#8A9BB8',
  textMuted: '#4A5568',
  textDark: '#080C12',

  // Status
  success: '#00F5A0',
  warning: '#FFB800',
  error: '#FF4757',
  info: '#00D4FF',

  // Surge
  surgeHot: '#FF4757',
  surgeWarm: '#FF6B35',
  surgeModerate: '#FFB800',

  // Overlays
  overlay: 'rgba(8,12,18,0.85)',
  overlayLight: 'rgba(8,12,18,0.5)',
};

export const gradients = {
  primary: ['#00F5A0', '#00D4FF'],
  dark: ['#080C12', '#0F1520'],
  card: ['#0F1520', '#161F2E'],
  surge: ['#FF4757', '#FF6B35'],
  gold: ['#FFB800', '#FF8C00'],
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 999,
};

export const typography = {
  h1: { fontSize: 32, fontWeight: '700' as const, letterSpacing: -0.5 },
  h2: { fontSize: 24, fontWeight: '700' as const, letterSpacing: -0.3 },
  h3: { fontSize: 20, fontWeight: '600' as const },
  h4: { fontSize: 17, fontWeight: '600' as const },
  body: { fontSize: 15, fontWeight: '400' as const },
  bodySmall: { fontSize: 13, fontWeight: '400' as const },
  caption: { fontSize: 11, fontWeight: '500' as const, letterSpacing: 0.3 },
  label: { fontSize: 12, fontWeight: '600' as const, letterSpacing: 0.8, textTransform: 'uppercase' as const },
};
