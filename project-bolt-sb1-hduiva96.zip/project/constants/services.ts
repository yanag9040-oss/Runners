export interface ServiceCategory {
  id: string;
  label: string;
  icon: string;
  basePrice: number;
  description: string;
  color: string;
}

export const SERVICE_CATEGORIES: ServiceCategory[] = [
  { id: 'prescriptions', label: 'Prescriptions', icon: '💊', basePrice: 12, description: 'Pickup & deliver prescriptions', color: '#FF6B9D' },
  { id: 'groceries', label: 'Groceries', icon: '🛒', basePrice: 15, description: 'Shop & deliver groceries', color: '#00F5A0' },
  { id: 'dog_walking', label: 'Dog Walking', icon: '🐕', basePrice: 18, description: '30-min neighborhood walk', color: '#FFB800' },
  { id: 'pet_sitting', label: 'Pet Sitting', icon: '🐾', basePrice: 25, description: 'In-home pet care', color: '#FF8C00' },
  { id: 'car_care', label: 'Car Care', icon: '🚗', basePrice: 20, description: 'Wash, fuel, minor tasks', color: '#00D4FF' },
  { id: 'post_office', label: 'Post Office', icon: '📦', basePrice: 10, description: 'Ship & mail packages', color: '#A855F7' },
  { id: 'catering', label: 'Catering', icon: '🍱', basePrice: 22, description: 'Food pickup & delivery', color: '#F97316' },
  { id: 'handyman', label: 'Handyman', icon: '🔧', basePrice: 35, description: 'Small repairs & installs', color: '#6366F1' },
  { id: 'laundry', label: 'Laundry', icon: '👕', basePrice: 20, description: 'Pickup, wash, fold & return', color: '#22D3EE' },
  { id: 'childcare', label: 'Child Care', icon: '👶', basePrice: 30, description: 'Vetted childcare helpers', color: '#EC4899' },
  { id: 'tutoring', label: 'Tutoring', icon: '📚', basePrice: 28, description: 'Academic tutoring sessions', color: '#8B5CF6' },
  { id: 'flash_errand', label: 'Flash Errand', icon: '⚡', basePrice: 8, description: 'Anything else — you name it', color: '#00F5A0' },
];

export const getService = (id: string) => SERVICE_CATEGORIES.find(s => s.id === id);
